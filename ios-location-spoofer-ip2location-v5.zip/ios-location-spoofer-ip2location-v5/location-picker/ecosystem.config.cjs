module.exports = {
  apps: [{
    name: 'location-picker',
    script: './server.js',
    cwd: __dirname,
    instances: 1,
    exec_mode: 'fork',
    autorestart: true,
    max_restarts: 10,
    restart_delay: 2000,
    time: true
  }]
};
