const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');

const root = path.resolve(__dirname, '..');
const envFile = path.join(root, '.env');
function parseEnv(text){
  const out={};
  for(let line of text.replace(/^\uFEFF/,'').split(/\r?\n/)){
    line=line.trim(); if(!line||line.startsWith('#'))continue;
    if(line.startsWith('export '))line=line.slice(7).trim();
    const i=line.indexOf('='); if(i<=0)continue;
    const k=line.slice(0,i).trim(); let v=line.slice(i+1).trim();
    if((v.startsWith('"')&&v.endsWith('"'))||(v.startsWith("'")&&v.endsWith("'")))v=v.slice(1,-1);
    out[k]=v;
  }
  return out;
}
function ok(t){console.log('✓ '+t)}
function warn(t){console.log('! '+t)}
function fail(t){console.error('✗ '+t);process.exitCode=1}

const major=Number(process.versions.node.split('.')[0]);
if(major>=20)ok('Node.js '+process.versions.node);else fail('Node.js 需要 >=20，当前 '+process.versions.node);
if(!fs.existsSync(envFile)){fail('缺少 .env，请复制 .env.example 为 .env');process.exit();}
ok('.env 存在：'+envFile);
const env=parseEnv(fs.readFileSync(envFile,'utf8'));
const token=String(env.TOKEN||'').trim();
if(!token)fail('TOKEN 未填写');else if(token.length<16)warn('TOKEN 少于 16 字符，建议 npm run token 重新生成');else ok('TOKEN 已填写（长度 '+token.length+'）');
const host=String(env.HOST||'127.0.0.1'); const port=Number(env.PORT||8080);
if(!Number.isInteger(port)||port<1||port>65535)fail('PORT 无效：'+env.PORT);else ok('监听配置 '+host+':'+port);
if(host==='127.0.0.1'||host==='::1')ok('仅本机监听，适合宝塔 Nginx 反代');else warn('当前 HOST='+host+'，Node 端口可能直接暴露公网');

const dataFile=env.DATA_FILE?path.resolve(env.DATA_FILE):path.join(root,'loc.json');
try{
  const dir=path.dirname(dataFile); fs.mkdirSync(dir,{recursive:true});
  const probe=path.join(dir,'.lp-write-test-'+process.pid); fs.writeFileSync(probe,'ok',{mode:0o600}); fs.unlinkSync(probe);
  ok('数据目录可写：'+dir);
}catch(e){fail('数据目录不可写：'+e.message)}

if(env.IP2LOCATION_API_KEY)ok('IP2LOCATION_API_KEY 已配置');else warn('IP2LOCATION_API_KEY 留空；IP 查询可能受免费接口限制，但地图手动定位不受影响');

if(Number.isInteger(port)&&port>0&&port<=65535){
  const s=net.createServer();
  s.once('error',e=>{if(e.code==='EADDRINUSE')warn('端口 '+port+' 已被占用；如果服务已经在运行这是正常的');else warn('端口检查：'+e.message)});
  s.once('listening',()=>{ok('端口 '+port+' 当前可监听');s.close();});
  s.listen(port,host);
}
