#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [ ! -f .env ]; then
  cp .env.example .env
  echo "已生成 .env，请先填写 TOKEN 后重新运行。"
  exit 1
fi
node scripts/doctor.js
exec node server.js
