# iOS Location Picker V5

V5 以“宝塔面板部署简单、外部 API 故障不影响手动地图定位、配置可回滚”为主要目标。

## 最简单启动

```bash
cd location-picker
cp .env.example .env   # 压缩包内已经附带一个 .env，可直接编辑
nano .env
node server.js
```

`.env` 最少只需要：

```env
TOKEN=你的随机TOKEN
HOST=127.0.0.1
PORT=8080
IP2LOCATION_API_KEY=
```

TOKEN 推荐生成：

```bash
npm run token
```

然后浏览器访问：

```text
https://你的域名/login
```

输入 `.env` 的 TOKEN 即可。也继续兼容旧方式：

```text
https://你的域名/?token=TOKEN
```

旧方式验证成功后会自动写入 HttpOnly 会话并跳转到干净的 `/`，避免地址栏长期保存 token。

远程配置接口仍保持：

```text
https://你的域名/loc.json?token=TOKEN
```

## V5 主要增强

- `.env` 自动读取，运行时零 npm 依赖。
- IP2Location 仍然只是快捷增强；API Key 错误、额度、429、5xx、DNS、超时等均不会禁用手动地图。
- 地址搜索和高程改为服务器端代理，浏览器只访问自己的服务器，统一缓存与错误处理。
- 地图点选/拖动/手输经纬度后可自动尝试反向地址；失败不会阻止保存。
- 每次配置变化自动保留一份 `loc.backup.json`，网页支持“撤销上次保存”。
- 新增 `/login` 会话登录、`/logout`、`/status`、`/rollback`。
- 默认不开放 `Access-Control-Allow-Origin: *`，降低浏览器跨站读取风险。
- 默认 `HOST=127.0.0.1`，适合宝塔 Nginx 反向代理，避免直接暴露 Node 8080。
- 原子写入增加 fsync，并对数据文件尽量保持 `0600` 权限。
- 支持优雅 SIGTERM/SIGINT 退出。
- 新增 `npm run doctor`、`npm run token`、PM2 配置、宝塔 Nginx 示例。

## IP2Location 故障时

不需要修改任何配置。网页会自动提示切回手动地图模式，以下功能仍可独立使用：

- 地址搜索（若地址搜索服务也不可用，可跳过）
- 地图点击
- 拖动图钉
- 手动填写 latitude / longitude
- 手动填写 address / altitude / accuracy
- 收藏点
- 保存 `/set`
- 读取 `/loc.json`
- 撤销上次保存

## 自检

```bash
npm run check
npm test
npm run doctor
```

`doctor` 会检查 Node 版本、`.env`、TOKEN、监听地址/端口、数据目录可写性以及 IP2Location Key 是否配置。

## 数据文件

默认：

```text
loc.json          当前配置
loc.meta.json     最近一次保存来源元数据
loc.backup.json   上一次配置，可从网页撤销恢复
```

建议不要把 `.env`、上述数据文件提交到公开仓库。
