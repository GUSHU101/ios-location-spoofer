# 宝塔面板部署 V5

## 1. 上传并解压

把整个 V5 ZIP 上传到例如：

```text
/www/wwwroot/ios-location-spoofer-ip2location-v5/
```

Node 项目目录是：

```text
/www/wwwroot/ios-location-spoofer-ip2location-v5/location-picker
```

## 2. 编辑 .env

直接在宝塔文件管理器打开：

```text
location-picker/.env
```

至少填写：

```env
TOKEN=你的TOKEN
HOST=127.0.0.1
PORT=8080
IP2LOCATION_API_KEY=
TRUST_PROXY=true
```

生成 TOKEN：

```bash
cd /www/wwwroot/ios-location-spoofer-ip2location-v5/location-picker
npm run token
```

没有 IP2Location API Key 时保持空即可，手动地图功能不受影响。

## 3. 自检

```bash
npm run doctor
npm test
```

## 4. 启动

宝塔 Node 项目管理器：

- 项目目录：`.../location-picker`
- 启动文件：`server.js`
- Node：20 或更高
- 启动命令：`node server.js`

也可以 PM2：

```bash
pm2 start ecosystem.config.cjs
pm2 save
```

## 5. 检查 8080

```bash
ss -lntp | grep :8080
curl http://127.0.0.1:8080/health
```

默认 `HOST=127.0.0.1`，所以 8080 只在服务器本机监听，这是推荐状态。

## 6. 宝塔创建域名并反向代理

创建站点，例如：

```text
loc.example.com
```

申请 SSL，然后反向代理：

```text
http://127.0.0.1:8080
```

可参考：

```text
location-picker/baota-nginx.conf.example
```

HTTPS 反代时建议 `.env`：

```env
TRUST_PROXY=true
COOKIE_SECURE=auto
```

## 7. 使用

管理登录：

```text
https://loc.example.com/login
```

配置接口：

```text
https://loc.example.com/loc.json?token=你的TOKEN
```

如果 IP2Location 失效，网页会自动继续提供地图手动定位，不需要重启 Node。
