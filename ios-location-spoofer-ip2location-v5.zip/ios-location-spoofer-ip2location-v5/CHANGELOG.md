# Changelog

## V5

- 新增 `/login` + HttpOnly/SameSite 会话，旧 `/?token=` 自动清理地址栏 token。
- 保留 `loc.json?token=` 兼容代理客户端读取。
- 默认移除 wildcard CORS；新增跨源写入阻止。
- 地址搜索改走服务器 `/geocode`，高程改走 `/elevation`，反向地址走 `/reverse-geocode`。
- 增加地理编码/高程缓存和上游限速；失败不影响地图点选/拖动/手输坐标。
- 增加 `loc.backup.json` 与 `/rollback`，网页支持撤销上次保存。
- 原子写入增加 fsync 与文件权限收紧。
- 增加 `HOST`，宝塔默认推荐 `127.0.0.1`；Docker 内部自动绑定 `0.0.0.0`。
- 增加优雅退出、服务状态栏、备份状态、退出登录。
- 增加 `npm run doctor`、`npm run token`、`start.sh`、PM2 配置、宝塔 Nginx 示例。
- 测试扩展到登录会话、回滚、服务端地址搜索/高程代理。

## V4

- `server.js` 自动读取同目录 `.env`。

## V3

- IP2Location 故障自动切换手动地图定位并增加熔断保护。
