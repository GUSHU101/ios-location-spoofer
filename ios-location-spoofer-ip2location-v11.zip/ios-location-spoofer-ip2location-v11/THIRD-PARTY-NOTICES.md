# Third-party notices

## Leaflet 1.9.4

V11 的可选地图 UI 使用 Leaflet 1.9.4。浏览器不直接从第三方 CDN 启动管理后台；服务器按需获取固定版本、校验固定 SHA-384，并缓存后通过 same-origin 端点提供。

Leaflet is distributed under the BSD 2-Clause license.

Copyright (c) 2010-2023, Vladimir Agafonkin
Copyright (c) 2010-2011, CloudMade

Project: https://leafletjs.com/
Repository: https://github.com/Leaflet/Leaflet
License: BSD-2-Clause

地图瓦片和地理编码服务具有各自的使用条款/署名要求；本通知不改变这些第三方服务的条款。
