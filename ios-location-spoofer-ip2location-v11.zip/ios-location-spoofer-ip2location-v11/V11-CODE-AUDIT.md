# V11 深度代码审计报告

## 结论

V11 重点解决的是“可选地图依赖能阻塞整个后台”这一架构缺陷，并继续对认证、反代、缓存、文件写入和第三方资产供应链做故障隔离。

当前自动回归：`51/51` 通过；真实临时 Nginx TLS → Node 反代烟测通过。

不能声称软件不存在任何未知 Bug；结论应理解为：在本报告列出的路径和自动测试范围内，没有发现仍未修复的已知阻断性问题。

## A. 前端启动链

已修复：

1. HTML 不再同步引用外部 Leaflet CDN。
2. app.css/watchdog.js/app.js 全部 same-origin。
3. watchdog 不等待 DOMContentLoaded，避免 `defer app.js Pending → DOMContentLoaded 也永远不来` 的逻辑死角。
4. app.js 启动后立即清除 watchdog timer。
5. 配置加载与地图加载并行隔离。
6. Leaflet 超时后移除迟到 script，避免降级完成后异步污染 `window.L`。
7. 地图失败时释放 map/listener。
8. 所有后台 API 请求默认 AbortController 超时，登出也有 5 秒上限。
9. 前端资源 URL 绑定实际内容指纹，静态文件继续 ETag + must-revalidate。

预期：地图/CDN/API 的失败最多影响对应增强功能，不允许让后台主控制停留在永久“加载中”。

## B. 管理/客户端令牌

- `TOKEN`：管理登录/Bearer/write/diagnostics。
- `CLIENT_TOKEN`：仅 GET `/loc.json` 和指定 `/profiles/*`。
- 默认不接受管理 TOKEN 作为客户端 query token。
- CLIENT_TOKEN 与 TOKEN 显式相同会拒绝启动。
- Session：HMAC 签名、HttpOnly、SameSite=Strict、HTTPS 反代时 Secure。
- 写操作做 Origin 校验。
- Nginx 对 `/loc.json`、`/profiles/`、旧根 query 登录关闭 access log。
- Node 异常日志只记录 pathname，不写 query。

## C. 8081 反向代理

V11 同时识别：

```text
Host
X-Forwarded-Host
X-Forwarded-Proto
X-Forwarded-Port
```

`TRUST_PROXY=true` 只在直接上游为 loopback 时信任这些头。

真实高端口 TLS Nginx smoke 已验证：

```text
HTTPS 非标准端口
→ 登录
→ 页面/静态资源
→ CLIENT_TOKEN loc/profile
→ 带 Origin 的 POST /set
```

均通过。

## D. 持久化

- 临时文件独占创建；
- fsync file；
- rename；
- fsync parent dir；
- backup/history；
- revision 冲突拒绝；
- JSON + 字段语义校验；
- 损坏文件隔离；
- 不可恢复时客户端返回 503，不发送“看似正常”的默认坐标。

## E. IP2Location / 外部 API

- IP2Location 可完全失败而不影响手工定位。
- GET 查询只预览；POST 才能 apply。
- IP 格式及私有/特殊地址校验。
- 单客户端限流、LRU/cache、in-flight 去重、熔断。
- 外部响应限制字节大小。
- 地址/ASN/地区文本长度限制。
- 前端外部文本使用 `textContent`，不拼接到 innerHTML。
- geocode/elevation 坐标边界校验。

## F. Leaflet 可选供应链

- 浏览器只访问 same-origin `/assets/vendor/leaflet/*`。
- 服务端可从两个固定镜像获取 Leaflet 1.9.4。
- 下载完成后必须匹配固定 SHA-384。
- 文件大小有限制。
- 缓存原子落盘。
- 失败冷却，避免不断外连。
- 浏览器端加载超时后进入手工模式。
- 跨主机 redirect 和 HTTPS→HTTP 降级被拒绝。

## G. 上游 location-spoofer.js

V11 不改 Apple WLOC / ARPC / protobuf 核心，锁定审计 commit 和 Git blob。

首次镜像：

```text
HTTP fetch
→ max bytes
→ Git blob SHA
→ expected size
→ atomic cache
→ self-hosted client URL
```

上游失败且本地缓存为空时，普通公共请求进入 `UPSTREAM_RETRY_COOLDOWN_MS`，避免公共端点成为重复外连放大器；管理员 force preload 可主动重试。

## H. 自动测试

最终集成测试：

```text
51 pass
0 fail
```

主 server.js coverage：

```text
line      82.99%
branch    60.87%
functions 88.71%
```

覆盖重点包括：

- `.env` 与系统环境优先级；
- TOKEN/CLIENT_TOKEN 隔离；
- 8081 Origin；
- forged forwarded headers；
- query 模块订阅；
- session login/logout；
- cross-origin write；
- malformed/oversized JSON；
- geocode/reverse/elevation；
- IP preview/apply/cache；
- revision 409；
- history/rollback/corruption；
- 上游 loc.json 契约；
- Shadowrocket/Loon/Surge/Stash 配置；
- 上游核心完整性/缓存/in-flight/cooldown；
- 前端 same-origin boot；
- watchdog；
- ETag/content fingerprint；
- Leaflet integrity/cache/fallback；
- asset redirect safety；
- 不可恢复配置返回 503。

## I. 浏览器烟测边界

项目包含 Chromium CDP 真浏览器烟测。当前构建环境存在组织策略，禁止自动化浏览器导航到本地 HTTP 地址，所以该项结果明确为 `SKIP`，没有把 SKIP 写成 PASS。

实际 Nginx HTTPS 反代烟测不受该策略影响并已 PASS。
