# V10 → V11 升级

V11 的核心变化是后台启动架构重构。建议直接替换程序文件，不要把 V10 的 `public/` 与 V11 混用。

## 1. 备份运行数据

先备份：

```text
.env
loc.json
loc.meta.json
loc.backup.json
history/
```

不要删除当前有效定位数据。

## 2. 替换程序

用 V11 的以下内容完整替换旧程序文件：

```text
server.js
package.json
public/
tools/
Dockerfile
docker-compose.yml
ecosystem.config.cjs
start.sh
location-picker.service.example
baota-nginx-8081.conf.example
```

不要覆盖你现有 `.env` 和 `loc*.json`。

## 3. `.env` 检查

V10 的推荐配置可以继续使用：

```env
TOKEN=管理TOKEN
CLIENT_TOKEN=独立只读TOKEN
HOST=127.0.0.1
PORT=8080
IP2LOCATION_API_KEY=
TRUST_PROXY=true
```

新增高级参数都有默认值，不需要主动填写：

```env
# LEAFLET_RETRY_COOLDOWN_MS=60000
# UPSTREAM_RETRY_COOLDOWN_MS=60000
```

## 4. Nginx

建议换成 V11 示例并重新：

```bash
nginx -t
systemctl reload nginx
```

仍然是：

```text
https://ios.caseora.cc:8081
       ↓
Nginx :8081
       ↓
127.0.0.1:8080
```

## 5. 重启 Node

PM2 示例：

```bash
pm2 restart ecosystem.config.cjs
pm2 save
```

检查：

```bash
curl http://127.0.0.1:8080/health
```

应看到：

```json
{"version":"11.0.0"}
```

并且 `frontendAssets.local.ready` 为 `true`。

## 6. 深度自检

```bash
npm run selfcheck
npm run smoke:nginx
npm run doctor
```

## 7. 浏览器缓存

V11 已把 app.css/watchdog.js/app.js 的 URL 与实际内容哈希绑定，同时使用 ETag 强制重新验证，所以通常不需要手工清缓存。

如果你之前正在打开 V10 页面，升级后建议直接关闭旧标签页，再重新打开：

```text
https://ios.caseora.cc:8081/login
```

## 8. 手机模块

如果 `CLIENT_TOKEN` 和域名没有变化，V10 模块原则上可以继续读取 `/loc.json`。

但建议在 V11 后台的“客户端配置”重新复制一次 Shadowrocket URL 并更新模块，以保证使用 V11 生成的当前 fallback 和版本化审计核心地址。
