const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const net = require('net');
const http = require('http');
const { spawn } = require('child_process');

function freePort() {
  return new Promise((resolve, reject) => {
    const s = net.createServer();
    s.on('error', reject);
    s.listen(0, '127.0.0.1', () => { const p=s.address().port; s.close(() => resolve(p)); });
  });
}
function getHealth(port) {
  return new Promise(resolve => {
    const req=http.get({hostname:'127.0.0.1',port,path:'/health',timeout:500},res=>{
      let t='';res.on('data',c=>t+=c);res.on('end',()=>{try{resolve(JSON.parse(t))}catch{resolve(null)}});
    });
    req.on('timeout',()=>req.destroy());req.on('error',()=>resolve(null));
  });
}

test('direct node server.js automatically loads sibling .env', { timeout:10000 }, async () => {
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'lp-v11-env-'));
  fs.copyFileSync(path.resolve(__dirname,'../server.js'),path.join(dir,'server.js'));
  const port=await freePort();
  fs.writeFileSync(path.join(dir,'.env'),[
    'TOKEN=abcdef0123456789abcdef0123456789abcdef0123456789',
    'HOST=127.0.0.1',
    'PORT='+port,
    'TRUST_PROXY=true',
    'UPSTREAM_PRELOAD=false',
    'LEAFLET_PRELOAD=false',
    'IP2LOCATION_API_KEY='
  ].join('\n')+'\n',{mode:0o600});

  const env={...process.env};
  delete env.TOKEN;delete env.PORT;delete env.HOST;delete env.TRUST_PROXY;delete env.ENV_FILE;
  const child=spawn(process.execPath,['server.js'],{cwd:dir,env,stdio:['ignore','pipe','pipe']});
  let stderr='';child.stderr.on('data',c=>stderr+=c);
  let health=null;
  for(let i=0;i<30&&!health;i++){await new Promise(r=>setTimeout(r,100));health=await getHealth(port);}
  try{
    assert.ok(health,'server did not start: '+stderr);
    assert.equal(health.version,'11.0.0');
    assert.equal(health.ok,true);
  } finally {
    child.kill('SIGTERM');
    await new Promise(r=>{const t=setTimeout(r,1500);child.once('exit',()=>{clearTimeout(t);r()});});
  }
});

test('explicit CLIENT_TOKEN identical to admin TOKEN is rejected at startup', { timeout:5000 }, async () => {
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'lp-v11-equal-token-'));
  fs.copyFileSync(path.resolve(__dirname,'../server.js'),path.join(dir,'server.js'));
  const token='abcdef0123456789abcdef0123456789';
  fs.writeFileSync(path.join(dir,'.env'),[
    'TOKEN='+token,
    'CLIENT_TOKEN='+token,
    'HOST=127.0.0.1',
    'PORT=18080',
    'UPSTREAM_PRELOAD=false'
  ].join('\n')+'\n',{mode:0o600});
  const env={...process.env};
  for(const k of ['TOKEN','CLIENT_TOKEN','PORT','HOST','ENV_FILE']) delete env[k];
  const child=spawn(process.execPath,['server.js'],{cwd:dir,env,stdio:['ignore','pipe','pipe']});
  let stderr='';child.stderr.on('data',c=>stderr+=c);
  const code=await new Promise(resolve=>{const t=setTimeout(()=>{child.kill('SIGKILL');resolve(null)},2500);child.once('exit',c=>{clearTimeout(t);resolve(c)});});
  assert.notEqual(code,0);
  assert.match(stderr,/CLIENT_TOKEN 不能与管理 TOKEN 相同/);
});

test('system environment overrides sibling .env values', { timeout:10000 }, async () => {
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'lp-v11-env-priority-'));
  fs.copyFileSync(path.resolve(__dirname,'../server.js'),path.join(dir,'server.js'));
  const port=await freePort();
  fs.writeFileSync(path.join(dir,'.env'),[
    'TOKEN=file-token-should-not-win-0123456789',
    'HOST=127.0.0.1',
    'PORT=1',
    'UPSTREAM_PRELOAD=true',
    'LEAFLET_PRELOAD=true'
  ].join('\n')+'\n',{mode:0o600});
  const env={...process.env,
    TOKEN:'system-token-abcdef0123456789abcdef0123456789',
    HOST:'127.0.0.1',PORT:String(port),UPSTREAM_PRELOAD:'false',LEAFLET_PRELOAD:'false'
  };
  delete env.CLIENT_TOKEN;delete env.ENV_FILE;
  const child=spawn(process.execPath,['server.js'],{cwd:dir,env,stdio:['ignore','pipe','pipe']});
  let stderr='';child.stderr.on('data',c=>stderr+=c);
  let health=null;
  for(let i=0;i<30&&!health;i++){await new Promise(r=>setTimeout(r,100));health=await getHealth(port);}
  try{
    assert.ok(health,'server did not honor system env: '+stderr);
    assert.equal(health.version,'11.0.0');
  } finally {
    child.kill('SIGTERM');
    await new Promise(r=>{const t=setTimeout(r,1500);child.once('exit',()=>{clearTimeout(t);r()});});
  }
});
