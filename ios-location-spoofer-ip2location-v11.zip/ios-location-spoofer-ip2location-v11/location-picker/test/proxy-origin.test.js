const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const http = require('http');

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'lp-v11-'));
let mod;
let upstream;
let upstreamPort;
let ipCalls = 0;
let upstreamCoreCalls = 0;
let upstreamQxCalls = 0;
let upstreamFailCore = false;
let leafletJsCalls = 0;
let leafletCssCalls = 0;
const mockCore = Buffer.from('/* audited mock core */\nconsole.log("core");\n');
const mockQx = Buffer.from('/* audited mock qx */\nconsole.log("qx");\n');
const mockLeafletJs = Buffer.from('window.L={mock:true};\n' + '/* leaflet mock padding */'.repeat(80));
const mockLeafletCss = Buffer.from('/* leaflet css mock */\n' + '.leaflet-mock{display:block;}\n'.repeat(80));
function gitBlobSha(buf) {
  return require('crypto').createHash('sha1')
    .update(Buffer.from('blob ' + buf.length + '\0'))
    .update(buf)
    .digest('hex');
}
function sha384(buf) {
  return require('crypto').createHash('sha384').update(buf).digest('base64');
}

function listen(server) {
  return new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
}

async function httpReq(serverPort, reqPath, method='GET', body=null, headers={}) {
  return new Promise((resolve, reject) => {
    const h = { ...headers };
    if (body != null && !Buffer.isBuffer(body)) body = Buffer.from(String(body));
    if (body != null) h['Content-Length'] = body.length;
    const req = http.request({ hostname:'127.0.0.1', port:serverPort, path:reqPath, method, headers:h }, res => {
      let text=''; res.setEncoding('utf8'); res.on('data', c => text += c);
      res.on('end', () => {
        let data=null; try { data = text ? JSON.parse(text) : null; } catch {}
        resolve({ status:res.statusCode, text, data, headers:res.headers });
      });
    });
    req.on('error', reject);
    if (body != null) req.write(body);
    req.end();
  });
}

test.before(async () => {
  upstream = http.createServer((req, res) => {
    const u = new URL(req.url, 'http://localhost');
    res.setHeader('Content-Type', 'application/json');
    if (u.pathname === '/upstream/location-spoofer.js') {
      upstreamCoreCalls += 1;
      if (upstreamFailCore) { res.statusCode=503; return res.end(JSON.stringify({error:'temporary upstream failure'})); }
      res.setHeader('Content-Type', 'application/javascript');
      return res.end(mockCore);
    }
    if (u.pathname === '/upstream/location-spoofer-qx.js') {
      upstreamQxCalls += 1;
      res.setHeader('Content-Type', 'application/javascript');
      return res.end(mockQx);
    }
    if (u.pathname === '/leaflet/leaflet.js') {
      leafletJsCalls += 1;
      res.setHeader('Content-Type', 'application/javascript');
      return res.end(mockLeafletJs);
    }
    if (u.pathname === '/leaflet/leaflet.css') {
      leafletCssCalls += 1;
      res.setHeader('Content-Type', 'text/css');
      return res.end(mockLeafletCss);
    }
    if (u.pathname === '/redirect-cross-host') {
      res.statusCode=302;res.setHeader('Location','http://localhost:'+upstreamPort+'/upstream/location-spoofer.js');return res.end();
    }
    if (u.pathname === '/ip2') {
      ipCalls += 1;
      return res.end(JSON.stringify({
        ip:u.searchParams.get('ip') || '8.8.8.8', country_code:'US', country_name:'United States of America',
        region_name:'California', city_name:'Mountain View', latitude:37.38605, longitude:-122.08385,
        zip_code:'94035', time_zone:'-07:00', asn:'15169', as:'Google LLC', is_proxy:false
      }));
    }
    if (u.pathname === '/elevation') return res.end(JSON.stringify({ elevation:[32] }));
    if (u.pathname === '/nominatim/search') return res.end(JSON.stringify([{ lat:'37.38605', lon:'-122.08385', display_name:'Mountain View' }]));
    if (u.pathname === '/nominatim/reverse') return res.end(JSON.stringify({ display_name:'Mountain View, California' }));
    res.statusCode = 404; res.end(JSON.stringify({ error:'not found' }));
  });
  await listen(upstream);
  upstreamPort = upstream.address().port;

  process.env.TOKEN = '0123456789abcdef0123456789abcdef';
  process.env.CLIENT_TOKEN = 'client0123456789abcdef0123456789';
  process.env.TRUST_PROXY = 'true';
  process.env.DATA_FILE = path.join(tmp, 'loc.json');
  process.env.META_FILE = path.join(tmp, 'loc.meta.json');
  process.env.BACKUP_FILE = path.join(tmp, 'loc.backup.json');
  process.env.HISTORY_DIR = path.join(tmp, 'history');
  process.env.HISTORY_MAX = '10';
  process.env.IP2LOCATION_BASE_URL = `http://127.0.0.1:${upstreamPort}/ip2`;
  process.env.NOMINATIM_BASE_URL = `http://127.0.0.1:${upstreamPort}/nominatim`;
  process.env.ELEVATION_BASE_URL = `http://127.0.0.1:${upstreamPort}/elevation`;
  process.env.IP2LOCATION_CACHE_TTL_MS = '60000';
  process.env.CLIENT_SCRIPT_SOURCE = 'self';
  process.env.UPSTREAM_PRELOAD = 'false';
  process.env.UPSTREAM_SOURCE_BASE = `http://127.0.0.1:${upstreamPort}/upstream`;
  process.env.UPSTREAM_CACHE_DIR = path.join(tmp, 'upstream-cache');
  process.env.UPSTREAM_CORE_BLOB_SHA = gitBlobSha(mockCore);
  process.env.UPSTREAM_CORE_SIZE = String(mockCore.length);
  process.env.UPSTREAM_QX_BLOB_SHA = gitBlobSha(mockQx);
  process.env.UPSTREAM_QX_SIZE = String(mockQx.length);
  process.env.UPSTREAM_RETRY_COOLDOWN_MS = '60000';
  process.env.LEAFLET_PRELOAD = 'false';
  process.env.LEAFLET_SOURCE_BASES = `http://127.0.0.1:${upstreamPort}/leaflet`;
  process.env.LEAFLET_CACHE_DIR = path.join(tmp, 'leaflet-cache');
  process.env.LEAFLET_JS_SHA384 = sha384(mockLeafletJs);
  process.env.LEAFLET_CSS_SHA384 = sha384(mockLeafletCss);

  mod = require('../server.js');
});

test.after(() => { try { upstream.close(); } catch {} });

function fakeReq(headers = {}, remoteAddress = '127.0.0.1') {
  return { headers, socket:{ remoteAddress, encrypted:false }, method:'GET' };
}

function authHeaders(extra={}) {
  return { Authorization:'Bearer ' + process.env.TOKEN, ...extra };
}

function proxyWriteHeaders(extra={}) {
  return authHeaders({
    Host:'ios.caseora.cc', Origin:'https://ios.caseora.cc:8081',
    'X-Forwarded-Host':'ios.caseora.cc', 'X-Forwarded-Proto':'https', 'X-Forwarded-Port':'8081',
    'X-Forwarded-For':'203.0.113.9', 'Content-Type':'application/json', ...extra
  });
}

test('non-standard HTTPS port reconstructed from forwarded headers', () => {
  const req = fakeReq({ host:'ios.caseora.cc', 'x-forwarded-host':'ios.caseora.cc', 'x-forwarded-proto':'https', 'x-forwarded-port':'8081', origin:'https://ios.caseora.cc:8081' });
  assert.equal(mod.canonicalExternalOrigin(req), 'https://ios.caseora.cc:8081');
  assert.equal(mod.originCheck(req).ok, true);
});

test('forwarded host with explicit port also works', () => {
  const req = fakeReq({ host:'ios.caseora.cc', 'x-forwarded-host':'ios.caseora.cc:8443', 'x-forwarded-proto':'https', 'x-forwarded-port':'8443', origin:'https://ios.caseora.cc:8443' });
  assert.equal(mod.canonicalExternalOrigin(req), 'https://ios.caseora.cc:8443');
  assert.equal(mod.originCheck(req).ok, true);
});

test('forged forwarded headers from non-loopback are not trusted', () => {
  const req = fakeReq({ host:'127.0.0.1:8080', 'x-forwarded-host':'evil.example:8081', 'x-forwarded-proto':'https', 'x-forwarded-port':'8081', origin:'https://evil.example:8081' }, '10.0.0.5');
  assert.equal(mod.proxyHeadersTrusted(req), false);
  assert.equal(mod.originCheck(req).ok, false);
});

test('client IP takes right-most X-Forwarded-For from trusted local proxy', () => {
  const req = fakeReq({ 'x-forwarded-for':'1.2.3.4, 198.51.100.25' });
  assert.equal(mod.clientIp(req), '198.51.100.25');
});

test('read-only CLIENT_TOKEN works for loc.json and URL-installed profiles but cannot access admin APIs', async () => {
  const app = http.createServer(mod.handler); await listen(app); const port=app.address().port;
  const client = encodeURIComponent(process.env.CLIENT_TOKEN);
  const loc = await httpReq(port, '/loc.json?token=' + client);
  assert.equal(loc.status, 200);

  // Critical V9 regression test: phone must be able to add the module directly by URL.
  const profile = await httpReq(port, '/profiles/shadowrocket.sgmodule?token=' + client);
  assert.equal(profile.status, 200);
  assert.ok(profile.text.includes('[Script]'));
  assert.match(String(profile.headers['content-disposition'] || ''), /^inline/);

  const status = await httpReq(port, '/status?token=' + client);
  assert.equal(status.status, 401);

  const writeWithClientBearer = await httpReq(
    port, '/set', 'POST', JSON.stringify({lat:10,lng:20}),
    {Authorization:'Bearer ' + process.env.CLIENT_TOKEN, 'Content-Type':'application/json'}
  );
  assert.equal(writeWithClientBearer.status, 403);

  // V11 security default: admin TOKEN is no longer accepted in read-only query strings.
  const oldLoc = await httpReq(port, '/loc.json?token=' + encodeURIComponent(process.env.TOKEN));
  assert.equal(oldLoc.status, 403);
  app.close();
});

test('admin login creates an HttpOnly session cookie that can access status, and logout clears it', async () => {
  const app = http.createServer(mod.handler); await listen(app); const port=app.address().port;
  const bad = await httpReq(port, '/login', 'POST', 'token=wrong-token', {'Content-Type':'application/x-www-form-urlencoded'});
  assert.equal(bad.status, 403);

  const body = 'token=' + encodeURIComponent(process.env.TOKEN);
  const good = await httpReq(port, '/login', 'POST', body, {'Content-Type':'application/x-www-form-urlencoded'});
  assert.equal(good.status, 303);
  const setCookie = Array.isArray(good.headers['set-cookie']) ? good.headers['set-cookie'][0] : String(good.headers['set-cookie'] || '');
  assert.match(setCookie, /lp_session=/);
  assert.match(setCookie, /HttpOnly/i);
  assert.match(setCookie, /SameSite=Strict/i);
  const cookie = setCookie.split(';')[0];

  const status = await httpReq(port, '/status', 'GET', null, {Cookie:cookie});
  assert.equal(status.status, 200);
  assert.equal(status.data.version, '11.0.0');

  const logout = await httpReq(port, '/logout', 'POST', '', {
    Cookie:cookie,
    Origin:`http://127.0.0.1:${port}`,
    'Content-Type':'application/x-www-form-urlencoded'
  });
  assert.equal(logout.status, 303);
  const cleared = Array.isArray(logout.headers['set-cookie']) ? logout.headers['set-cookie'][0] : String(logout.headers['set-cookie'] || '');
  assert.match(cleared, /Max-Age=0/i);
  app.close();
});

test('legacy root admin-token URL upgrades to a clean HttpOnly session redirect', async () => {
  const app = http.createServer(mod.handler); await listen(app); const port=app.address().port;
  const r = await httpReq(port, '/?token=' + encodeURIComponent(process.env.TOKEN));
  assert.equal(r.status, 303);
  assert.equal(r.headers.location, '/');
  const setCookie = Array.isArray(r.headers['set-cookie']) ? r.headers['set-cookie'][0] : String(r.headers['set-cookie'] || '');
  assert.match(setCookie, /lp_session=/);
  app.close();
});

test('cross-origin browser write is blocked before changing loc.json', async () => {
  const app = http.createServer(mod.handler); await listen(app); const port=app.address().port;
  const before = mod.readLoc();
  const r = await httpReq(port, '/set', 'POST', JSON.stringify({lat:12,lng:34}), authHeaders({
    Host:'ios.caseora.cc',
    Origin:'https://evil.example',
    'X-Forwarded-Host':'ios.caseora.cc',
    'X-Forwarded-Proto':'https',
    'X-Forwarded-Port':'8081',
    'Content-Type':'application/json'
  }));
  assert.equal(r.status, 403);
  assert.equal(r.data.code, 'ORIGIN_MISMATCH');
  assert.deepEqual(mod.readLoc(), before);
  app.close();
});

test('malformed JSON write returns HTTP 400 without changing saved location', async () => {
  const app = http.createServer(mod.handler); await listen(app); const port=app.address().port;
  const before = mod.readLoc();
  const r = await httpReq(port, '/set', 'POST', '{not-json', proxyWriteHeaders());
  assert.equal(r.status, 400);
  assert.deepEqual(mod.readLoc(), before);
  app.close();
});

test('server-side geocode, reverse-geocode, and elevation proxies return bounded data', async () => {
  const app = http.createServer(mod.handler); await listen(app); const port=app.address().port;
  const g = await httpReq(port, '/geocode?q=Mountain%20View', 'GET', null, authHeaders());
  assert.equal(g.status, 200);
  assert.equal(g.data.results[0].display_name, 'Mountain View');
  const g2 = await httpReq(port, '/geocode?q=Mountain%20View', 'GET', null, authHeaders());
  assert.equal(g2.status, 200);
  assert.equal(g2.data.results[0].lat, 37.38605);

  const rev = await httpReq(port, '/reverse-geocode?lat=37.38605&lng=-122.08385', 'GET', null, authHeaders());
  assert.equal(rev.status, 200);
  assert.equal(rev.data.result.display_name, 'Mountain View, California');

  const elev = await httpReq(port, '/elevation?lat=37.38605&lng=-122.08385', 'GET', null, authHeaders());
  assert.equal(elev.status, 200);
  assert.equal(elev.data.elevation, 32);
  app.close();
});

test('GET ip-lookup is preview-only even when apply=true', async () => {
  const app = http.createServer(mod.handler); await listen(app); const port=app.address().port;
  if (fs.existsSync(process.env.DATA_FILE)) fs.unlinkSync(process.env.DATA_FILE);
  const before = ipCalls;
  const r = await httpReq(port, '/ip-lookup?ip=8.8.8.8&apply=true', 'GET', null, authHeaders());
  assert.equal(r.status, 200);
  assert.equal(r.data.saved, false);
  assert.equal(r.data.previewOnly, true);
  assert.equal(fs.existsSync(process.env.DATA_FILE), false);
  assert.equal(ipCalls, before + 1);
  app.close();
});

test('POST ip-lookup can apply and cached lookup avoids second upstream call', async () => {
  const app = http.createServer(mod.handler); await listen(app); const port=app.address().port;
  const before = ipCalls;
  const body = JSON.stringify({ ip:'8.8.8.8', apply:true });
  const r = await httpReq(port, '/ip-lookup', 'POST', body, proxyWriteHeaders());
  assert.equal(r.status, 200);
  assert.equal(r.data.saved, true);
  assert.equal(r.data.location.latitude, 37.38605);
  // previous test populated cache, so no additional IP upstream request is needed.
  assert.equal(ipCalls, before);
  assert.equal(fs.existsSync(process.env.DATA_FILE), true);
  app.close();
});

test('oversized JSON body returns HTTP 413 instead of resetting the client connection', async () => {
  const app = http.createServer(mod.handler); await listen(app); const port=app.address().port;
  const huge = JSON.stringify({ lat:1, lng:2, padding:'x'.repeat(12000) });
  const r = await httpReq(port, '/set', 'POST', huge, proxyWriteHeaders());
  assert.equal(r.status, 413);
  assert.equal(r.data && r.data.error, 'payload too large');
  app.close();
});

test('manual save works behind Baota/Nginx on HTTPS 8081', async () => {
  const app = http.createServer(mod.handler); await listen(app); const port=app.address().port;
  const body = JSON.stringify({ lat:37.4, lng:-122.1, address:'Manual', altitude:20, horizontalAccuracy:39, verticalAccuracy:1000, failOpen:true, debug:false });
  const r = await httpReq(port, '/set', 'POST', body, proxyWriteHeaders());
  assert.equal(r.status, 200);
  assert.equal(r.data.latitude, 37.4);
  assert.ok(r.data._revision);
  app.close();
});

test('stale revision is rejected with HTTP 409 instead of overwriting newer config', async () => {
  const app = http.createServer(mod.handler); await listen(app); const port=app.address().port;
  const read = await httpReq(port, '/loc.json', 'GET', null, authHeaders());
  const rev = read.headers['x-config-revision'];
  const a = await httpReq(port, '/set', 'POST', JSON.stringify({ lat:1, lng:2, ifRevision:rev }), proxyWriteHeaders());
  assert.equal(a.status, 200);
  const b = await httpReq(port, '/set', 'POST', JSON.stringify({ lat:3, lng:4, ifRevision:rev }), proxyWriteHeaders());
  assert.equal(b.status, 409);
  assert.equal(b.data.code, 'REVISION_CONFLICT');
  assert.equal(mod.readLoc().latitude, 1);
  app.close();
});


test('authenticated runtime selfcheck reports manual fallback and proxy state', async () => {
  const app = http.createServer(mod.handler); await listen(app); const port=app.address().port;
  const r = await httpReq(port, '/diagnostics/selfcheck', 'GET', null, proxyWriteHeaders());
  assert.equal(r.status, 200);
  assert.equal(r.data.ok, true);
  assert.equal(r.data.version, '11.0.0');
  assert.ok(r.data.checks.some(c => c.name === '手动定位兜底' && c.ok === true));
  app.close();
});

test('history snapshots are created on subsequent saves', () => {
  mod.writeLoc({ latitude:10, longitude:20 });
  mod.writeLoc({ latitude:30, longitude:40 });
  assert.ok(mod.listHistory(10).length >= 1);
});

test('corrupt loc.json is quarantined and automatically recovered from valid backup', () => {
  fs.writeFileSync(process.env.BACKUP_FILE, JSON.stringify({ latitude:51.5, longitude:-0.12, altitude:15 }));
  fs.writeFileSync(process.env.DATA_FILE, '{broken json');
  const loc = mod.readLoc();
  assert.equal(loc.latitude, 51.5);
  assert.equal(loc.longitude, -0.12);
  assert.doesNotThrow(() => JSON.parse(fs.readFileSync(process.env.DATA_FILE, 'utf8')));
  const quarantined = fs.readdirSync(tmp).filter(n => n.startsWith('loc.corrupt-'));
  assert.ok(quarantined.length >= 1);
});

test('special/reserved IP detection covers IPv4-mapped IPv6', () => {
  assert.equal(mod.isSpecialIp('192.168.1.1'), true);
  assert.equal(mod.isSpecialIp('::ffff:192.168.1.1'), true);
  assert.equal(mod.isSpecialIp('8.8.8.8'), false);
});


test('upstream compatibility endpoint validates flat loc.json contract', async () => {
  const app = http.createServer(mod.handler); await listen(app); const port=app.address().port;
  const r = await httpReq(port, '/compat/upstream', 'GET', null, proxyWriteHeaders());
  assert.equal(r.status, 200);
  assert.equal(r.data.ok, true);
  assert.equal(r.data.upstream.auditedRepository, 'mekos2772/ios-location-spoofer');
  assert.equal(r.data.upstream.auditedCommit, 'b72d6f67efb2b457647ae05e3e20ae3f3f6f0262');
  assert.deepEqual(r.data.locJsonContract.missing, []);
  assert.equal(r.data.locJsonContract.numericOk, true);
  assert.equal(r.data.upstream.quantumultX.remotePicker, false);
  app.close();
});

test('generated Shadowrocket profile uses versioned audited core and read-only remote token on HTTPS 8081', async () => {
  const app = http.createServer(mod.handler); await listen(app); const port=app.address().port;
  const r = await httpReq(port, '/profiles/shadowrocket.sgmodule?download=1', 'GET', null, proxyWriteHeaders());
  assert.equal(r.status, 200);
  const version = gitBlobSha(mockCore).slice(0,12);
  assert.ok(r.text.includes('script-path=https://ios.caseora.cc:8081/client/location-spoofer.js?v=' + version));
  const expected = encodeURIComponent(`https://ios.caseora.cc:8081/loc.json?token=${process.env.CLIENT_TOKEN}`);
  assert.ok(r.text.includes('configUrl=' + expected));
  assert.equal(r.text.includes(process.env.TOKEN), false, 'admin TOKEN must never be embedded in generated profile');
  assert.ok(r.text.includes(process.env.CLIENT_TOKEN), 'read-only CLIENT_TOKEN must be embedded in configUrl');
  assert.match(String(r.headers['content-disposition'] || ''), /attachment/);
  app.close();
});

test('generated Loon profile pre-fills server origin and token while keeping upstream argument contract', async () => {
  const app = http.createServer(mod.handler); await listen(app); const port=app.address().port;
  const r = await httpReq(port, '/profiles/ios-location-spoofer.lnplugin', 'GET', null, proxyWriteHeaders());
  assert.equal(r.status, 200);
  assert.ok(r.text.includes('configHost = input,"https://ios.caseora.cc:8081"'));
  assert.ok(r.text.includes(`configToken = input,"${process.env.CLIENT_TOKEN}"`));
  assert.equal(r.text.includes(process.env.TOKEN), false);
  assert.ok(r.text.includes('argument=[{enabled},{latitude},{longitude},{altitude},{horizontalAccuracy},{verticalAccuracy},{address},{configHost},{configToken},{configUrl},{debug}]'));
  assert.ok(r.text.includes('gsp-ssl\\.ls\\.apple\\.com'));
  app.close();
});

test('loc.json output remains directly normalizable by audited upstream core defaults', async () => {
  const app = http.createServer(mod.handler); await listen(app); const port=app.address().port;
  const r = await httpReq(port, '/loc.json?token=' + encodeURIComponent(process.env.CLIENT_TOKEN));
  assert.equal(r.status, 200);
  const cfg = r.data;
  // Mirrors the input expectations in upstream normalizeConfig() at audited commit.
  assert.equal(typeof cfg.enabled, 'boolean');
  assert.ok(Number.isFinite(Number(cfg.latitude)) && Number(cfg.latitude) >= -90 && Number(cfg.latitude) <= 90);
  assert.ok(Number.isFinite(Number(cfg.longitude)) && Number(cfg.longitude) >= -180 && Number(cfg.longitude) <= 180);
  for (const k of ['horizontalAccuracy','verticalAccuracy','altitude']) assert.ok(Number.isFinite(Number(cfg[k])), k);
  assert.equal(typeof cfg.failOpen, 'boolean');
  assert.equal(typeof cfg.debug, 'boolean');
  assert.equal(Object.prototype.hasOwnProperty.call(cfg, '_revision'), false);
  app.close();
});

test('generated Surge and Stash profiles retain audited Apple hosts and remote config URL', async () => {
  const app = http.createServer(mod.handler); await listen(app); const port=app.address().port;
  for (const route of ['/profiles/surge.sgmodule','/profiles/ios-location-spoofer.stoverride']) {
    const r = await httpReq(port, route, 'GET', null, proxyWriteHeaders());
    assert.equal(r.status, 200, route);
    assert.ok(r.text.includes('https://ios.caseora.cc:8081/client/location-spoofer.js?v=' + gitBlobSha(mockCore).slice(0,12)), route);
    assert.ok(r.text.includes('gsp-ssl\\.ls\\.apple\\.com') || r.text.includes('gsp-ssl.ls.apple.com'), route);
    assert.ok(r.text.includes('configUrl='), route);
  }
  app.close();
});

test('profile catalog distinguishes upstream-documented and experimental remote picker support', async () => {
  const app = http.createServer(mod.handler); await listen(app); const port=app.address().port;
  const r = await httpReq(port, '/profiles', 'GET', null, proxyWriteHeaders());
  assert.equal(r.status, 200);
  const byId = Object.fromEntries(r.data.profiles.map(p => [p.id,p]));
  assert.equal(byId.shadowrocket.confidence, 'upstream-documented');
  assert.equal(byId.loon.confidence, 'upstream-native');
  assert.equal(byId.surge.confidence, 'shared-core-experimental');
  assert.equal(byId.stash.confidence, 'shared-core-experimental');
  assert.equal(r.data.quantumultX.remotePicker, false);
  app.close();
});


test('verified self-hosted upstream core is public, exact, cached, and immutable', async () => {
  const app = http.createServer(mod.handler); await listen(app); const port=app.address().port;
  const before = upstreamCoreCalls;
  const r1 = await httpReq(port, '/client/location-spoofer.js');
  assert.equal(r1.status, 200);
  assert.equal(r1.text, mockCore.toString('utf8'));
  assert.equal(r1.headers['x-upstream-git-blob'], gitBlobSha(mockCore));
  assert.match(String(r1.headers['cache-control'] || ''), /immutable/);
  assert.equal(upstreamCoreCalls, before + 1);

  const r2 = await httpReq(port, '/client/location-spoofer.js', 'GET', null, { 'If-None-Match':'"' + gitBlobSha(mockCore) + '"' });
  assert.equal(r2.status, 304);
  assert.equal(upstreamCoreCalls, before + 1);
  app.close();
});

test('upstream mirror integrity validator rejects tampered client code', () => {
  const good = mod.validateUpstreamAssetBuffer('core', mockCore);
  assert.equal(good.ok, true);
  const bad = mod.validateUpstreamAssetBuffer('core', Buffer.from(mockCore.toString('utf8') + '//tampered'));
  assert.equal(bad.ok, false);
  assert.match(bad.error, /mismatch/i);
});

test('verified disk cache keeps client script available when upstream refresh fails', async () => {
  await mod.ensureUpstreamAsset('core');
  const oldUrl = mod.UPSTREAM_ASSETS.core.sourceUrl;
  mod.UPSTREAM_ASSETS.core.sourceUrl = 'http://127.0.0.1:1/unavailable.js';
  try {
    const buf = await mod.ensureUpstreamAsset('core', { force:true });
    assert.equal(buf.toString('utf8'), mockCore.toString('utf8'));
    const st = mod.upstreamAssetsStatus();
    assert.equal(st.core.valid, true);
  } finally {
    mod.UPSTREAM_ASSETS.core.sourceUrl = oldUrl;
  }
});

test('client preload endpoint refreshes both audited assets behind Baota origin checks', async () => {
  const app = http.createServer(mod.handler); await listen(app); const port=app.address().port;
  const r = await httpReq(port, '/client/preload', 'POST', '{}', proxyWriteHeaders());
  assert.equal(r.status, 200);
  assert.equal(r.data.ok, true);
  assert.equal(r.data.result.core.blobSha, gitBlobSha(mockCore));
  assert.equal(r.data.result.qx.blobSha, gitBlobSha(mockQx));
  app.close();
});

test('client status reports audited self-hosted mirror state', async () => {
  const app = http.createServer(mod.handler); await listen(app); const port=app.address().port;
  await mod.ensureUpstreamAsset('core');
  const r = await httpReq(port, '/client/status', 'GET', null, proxyWriteHeaders());
  assert.equal(r.status, 200);
  assert.equal(r.data.sourceMode, 'self');
  assert.equal(r.data.auditedCommit, 'b72d6f67efb2b457647ae05e3e20ae3f3f6f0262');
  assert.equal(r.data.assets.core.valid, true);
  app.close();
});


test('direct-upstream fallback profile can be downloaded without changing server-wide client source', async () => {
  const app = http.createServer(mod.handler); await listen(app); const port=app.address().port;
  try {
    const r = await httpReq(port, '/profiles/shadowrocket.sgmodule?clientSource=github', 'GET', null, proxyWriteHeaders());
    assert.equal(r.status, 200);
    assert.ok(r.text.includes(`script-path=http://127.0.0.1:${upstreamPort}/upstream/location-spoofer.js`));
    assert.ok(r.text.includes('configUrl='));
    const normal = await httpReq(port, '/profiles/shadowrocket.sgmodule', 'GET', null, proxyWriteHeaders());
    assert.ok(normal.text.includes('script-path=https://ios.caseora.cc:8081/client/location-spoofer.js?v=' + gitBlobSha(mockCore).slice(0,12)));
  } finally {
    app.close();
  }
});

test('profile catalog exposes copyable phone install URL with CLIENT_TOKEN, not admin TOKEN', async () => {
  const app = http.createServer(mod.handler); await listen(app); const port=app.address().port;
  const r = await httpReq(port, '/profiles', 'GET', null, proxyWriteHeaders());
  assert.equal(r.status, 200);
  const sr = r.data.profiles.find(p => p.id === 'shadowrocket');
  assert.ok(sr);
  assert.ok(sr.installUrl.startsWith('https://ios.caseora.cc:8081/profiles/shadowrocket.sgmodule?'));
  const u = new URL(sr.installUrl);
  assert.equal(u.searchParams.get('token'), process.env.CLIENT_TOKEN);
  assert.equal(sr.installUrl.includes(process.env.TOKEN), false);
  app.close();
});

test('generated profile fallback follows current saved config instead of silently falling back to Apple Park', () => {
  const before = mod.readLoc();
  try {
    mod.writeLoc({
      enabled:false, latitude:12.345678, longitude:98.765432, altitude:88,
      horizontalAccuracy:17, verticalAccuracy:29, failOpen:false, debug:true
    }, { backup:false });
    const req = fakeReq({
      host:'ios.caseora.cc', 'x-forwarded-host':'ios.caseora.cc',
      'x-forwarded-proto':'https', 'x-forwarded-port':'8081'
    });
    const text = mod.buildShadowrocketProfile(req);
    assert.ok(text.includes('enabled=false'));
    assert.ok(text.includes('latitude=12.345678'));
    assert.ok(text.includes('longitude=98.765432'));
    assert.ok(text.includes('horizontalAccuracy=17'));
    assert.ok(text.includes('verticalAccuracy=29'));
    assert.ok(text.includes('altitude=88'));
    assert.ok(text.includes('failOpen=false'));
    assert.ok(text.includes('debug=true'));
  } finally {
    mod.writeLoc(before, { backup:false });
  }
});

test('invalid optional save fields are rejected instead of silently resetting persisted values', async () => {
  const app = http.createServer(mod.handler); await listen(app); const port=app.address().port;
  const before = mod.readLoc();
  const r = await httpReq(port, '/set', 'POST', JSON.stringify({
    lat:before.latitude, lng:before.longitude, altitude:'not-a-number'
  }), proxyWriteHeaders());
  assert.equal(r.status, 400);
  assert.equal(r.data.code, 'INVALID_FIELD');
  assert.equal(mod.readLoc().altitude, before.altitude);
  app.close();
});

test('enable endpoint parses string false strictly', async () => {
  const app = http.createServer(mod.handler); await listen(app); const port=app.address().port;
  const before = mod.readLoc();
  try {
    const r = await httpReq(port, '/enable', 'POST', JSON.stringify({enabled:'false'}), proxyWriteHeaders());
    assert.equal(r.status, 200);
    assert.equal(r.data.enabled, false);
    assert.equal(mod.readLoc().enabled, false);
  } finally {
    mod.writeLoc(before, { backup:false });
    app.close();
  }
});

test('semantic corruption in loc.json is detected and recovered instead of becoming default Apple Park', () => {
  const previous = mod.readLoc();
  const backup = { ...previous, latitude:48.8566, longitude:2.3522, altitude:35 };
  fs.writeFileSync(process.env.BACKUP_FILE, JSON.stringify(backup));
  fs.writeFileSync(process.env.DATA_FILE, JSON.stringify({
    enabled:true, latitude:'banana', longitude:2.3522, altitude:35,
    horizontalAccuracy:39, verticalAccuracy:1000, failOpen:true, debug:false
  }));
  const loc = mod.readLoc();
  assert.equal(loc.latitude, 48.8566);
  assert.equal(loc.longitude, 2.3522);
  assert.doesNotThrow(() => JSON.parse(fs.readFileSync(process.env.DATA_FILE, 'utf8')));
});

test('public health exposes only slim upstream mirror state', async () => {
  const app = http.createServer(mod.handler); await listen(app); const port=app.address().port;
  const r = await httpReq(port, '/health');
  assert.equal(r.status, 200);
  assert.equal(r.data.version, '11.0.0');
  assert.match(String(r.data.frontendAssets.local.buildId||''), /^11\.0\.0-[0-9a-f]{16}$/);
  assert.equal(r.data.frontendAssets.local.ready, true);
  assert.equal(Object.prototype.hasOwnProperty.call(r.data.upstreamMirror.core, 'sourceUrl'), false);
  assert.equal(Object.prototype.hasOwnProperty.call(r.data.upstreamMirror.core, 'runtime'), false);
  assert.deepEqual(Object.keys(r.data.upstreamMirror.core).sort(), ['cachedOnDisk','ready','valid']);
  app.close();
});

test('concurrent forced upstream mirror refresh is deduplicated', async () => {
  const before = upstreamCoreCalls;
  const [a,b] = await Promise.all([
    mod.ensureUpstreamAsset('core', {force:true}),
    mod.ensureUpstreamAsset('core', {force:true})
  ]);
  assert.equal(a.toString('utf8'), mockCore.toString('utf8'));
  assert.equal(b.toString('utf8'), mockCore.toString('utf8'));
  assert.equal(upstreamCoreCalls, before + 1);
});

test('self-hosted client script URL is versioned to make immutable caching upgrade-safe', () => {
  const req = fakeReq({
    host:'ios.caseora.cc', 'x-forwarded-host':'ios.caseora.cc',
    'x-forwarded-proto':'https', 'x-forwarded-port':'8081'
  });
  const u = new URL(mod.clientScriptUrl(req, 'core'));
  assert.equal(u.origin, 'https://ios.caseora.cc:8081');
  assert.equal(u.pathname, '/client/location-spoofer.js');
  assert.equal(u.searchParams.get('v'), gitBlobSha(mockCore));
});

test('admin page boot assets are local and no third-party script blocks core startup', async () => {
  const app = http.createServer(mod.handler); await listen(app); const port=app.address().port;
  const loginBody='token='+encodeURIComponent(process.env.TOKEN);
  const login=await httpReq(port,'/login','POST',loginBody,{'Content-Type':'application/x-www-form-urlencoded'});
  assert.equal(login.status,303);
  const setCookie=Array.isArray(login.headers['set-cookie'])?login.headers['set-cookie'][0]:String(login.headers['set-cookie']||'');
  const cookie=setCookie.split(';')[0];
  const page=await httpReq(port,'/','GET',null,{Cookie:cookie});
  assert.equal(page.status,200);
  assert.match(page.text,/\/assets\/watchdog\.js\?v=11\.0\.0-[0-9a-f]{16}/);
  assert.match(page.text,/\/assets\/app\.js\?v=11\.0\.0-[0-9a-f]{16}/);
  const buildMatch=page.text.match(/\/assets\/app\.js\?v=(11\.0\.0-[0-9a-f]{16})/);
  assert.ok(buildMatch);
  const buildId=buildMatch[1];
  assert.doesNotMatch(page.text,/<script[^>]+https?:\/\//i);
  assert.doesNotMatch(page.text,/unpkg\.com\/leaflet/i);
  assert.match(String(page.headers['content-security-policy']||''),/script-src 'self'/);
  assert.doesNotMatch(String(page.headers['content-security-policy']||''),/script-src[^;]*unsafe-inline/);

  for (const asset of ['/assets/app.css?v='+buildId,'/assets/watchdog.js?v='+buildId,'/assets/app.js?v='+buildId]) {
    const r=await httpReq(port,asset);
    assert.equal(r.status,200,asset);
    assert.match(String(r.headers['cache-control']||''),/must-revalidate/);
    assert.doesNotMatch(String(r.headers['cache-control']||''),/immutable/);
    const etag=String(r.headers.etag||'');
    assert.ok(etag);
    const revalidated=await httpReq(port,asset,'GET',null,{'If-None-Match':etag});
    assert.equal(revalidated.status,304,asset+' ETag revalidation');
  }
  const watchdog=await httpReq(port,'/assets/watchdog.js?v='+buildId);
  assert.match(watchdog.text,/__LP_WATCHDOG_TIMER=setTimeout/);
  assert.match(watchdog.text,/不能等待 DOMContentLoaded/);
  const appJs=await httpReq(port,'/assets/app.js?v='+buildId);
  assert.match(appJs.text,/window\.__LP_BOOT_OK=true/);
  assert.match(appJs.text,/clearTimeout\(window\.__LP_WATCHDOG_TIMER\)/);
  assert.match(appJs.text,/apiFetch\("\/logout"[\s\S]*timeoutMs:5000/);
  assert.match(appJs.text,/cleanupFailedScript/);
  assert.match(appJs.text,/script\.parentNode\.removeChild\(script\)/);
  assert.match(appJs.text,/typeof map\.remove==="function"/);
  app.close();
});

test('optional Leaflet is served through same-origin verified cache and never required by admin assets', async () => {
  const app = http.createServer(mod.handler); await listen(app); const port=app.address().port;
  const beforeJs=leafletJsCalls,beforeCss=leafletCssCalls;
  const [js,css]=await Promise.all([
    httpReq(port,'/assets/vendor/leaflet/leaflet.js?v=1.9.4'),
    httpReq(port,'/assets/vendor/leaflet/leaflet.css?v=1.9.4')
  ]);
  assert.equal(js.status,200);assert.equal(css.status,200);
  assert.equal(js.text,mockLeafletJs.toString('utf8'));
  assert.equal(css.text,mockLeafletCss.toString('utf8'));
  assert.match(String(js.headers.etag||''),/^"sha384-/);
  assert.equal(leafletJsCalls,beforeJs+1);assert.equal(leafletCssCalls,beforeCss+1);
  const js2=await httpReq(port,'/assets/vendor/leaflet/leaflet.js?v=1.9.4');
  assert.equal(js2.status,200);assert.equal(leafletJsCalls,beforeJs+1);
  app.close();
});

test('profile subscription can explicitly force self or github script source', () => {
  const reqSelf=fakeReq({host:'ios.caseora.cc','x-forwarded-host':'ios.caseora.cc','x-forwarded-proto':'https','x-forwarded-port':'8081'});
  reqSelf.url='/profiles/shadowrocket.sgmodule?clientSource=self';
  const cat=mod.profileCatalog(reqSelf);
  const shadow=cat.profiles.find(x=>x.id==='shadowrocket');
  assert.equal(new URL(shadow.installUrl).searchParams.get('clientSource'),'self');
  assert.equal(new URL(shadow.githubFallback).searchParams.get('clientSource'),'github');
});

test('Leaflet integrity validator rejects altered vendor data', () => {
  const good=mod.validateLeafletAssetBuffer('js',mockLeafletJs);
  assert.equal(good.ok,true);
  const bad=mod.validateLeafletAssetBuffer('js',Buffer.concat([mockLeafletJs,Buffer.from('x')]));
  assert.equal(bad.ok,false);
  assert.match(bad.error,/SHA-384|size/i);
});

test('asset fetcher blocks cross-host redirects before following them', async () => {
  await assert.rejects(
    () => mod.requestBuffer(`http://127.0.0.1:${upstreamPort}/redirect-cross-host`,{},1000,1024*1024),
    /cross-host upstream redirect blocked/
  );
});

test('failed public upstream client repair enters cooldown instead of repeatedly hammering the source', async () => {
  const cacheFile=path.join(process.env.UPSTREAM_CACHE_DIR,'location-spoofer.js');
  try{fs.unlinkSync(cacheFile);}catch{}
  upstreamFailCore=true;
  const before=upstreamCoreCalls;
  await assert.rejects(() => mod.ensureUpstreamAsset('core'), /upstream HTTP 503/);
  assert.equal(upstreamCoreCalls,before+1);
  await assert.rejects(() => mod.ensureUpstreamAsset('core'), e => e && e.code==='UPSTREAM_COOLDOWN');
  assert.equal(upstreamCoreCalls,before+1);
  upstreamFailCore=false;
  const repaired=await mod.ensureUpstreamAsset('core',{force:true});
  assert.equal(repaired.toString('utf8'),mockCore.toString('utf8'));
  assert.equal(upstreamCoreCalls,before+2);
});

test('rollback rejects semantically corrupt backup instead of normalizing it to defaults', () => {
  const current = mod.readLoc();
  fs.writeFileSync(process.env.BACKUP_FILE, JSON.stringify({
    enabled:true, latitude:'bad-latitude', longitude:0,
    horizontalAccuracy:39, verticalAccuracy:1000, altitude:0,
    failOpen:true, debug:false
  }));
  assert.throws(() => mod.rollbackLoc(), /latitude/);
  assert.deepEqual(mod.readLoc(), current);
  fs.writeFileSync(process.env.BACKUP_FILE, JSON.stringify(current));
});

test('history listing ignores semantically corrupt snapshots', () => {
  fs.mkdirSync(process.env.HISTORY_DIR, {recursive:true});
  const name='loc-20260812T101600.000Z-deadbe.json';
  fs.writeFileSync(path.join(process.env.HISTORY_DIR,name), JSON.stringify({latitude:'bad',longitude:0}));
  const items=mod.listHistory(50);
  assert.equal(items.some(it => it.id === name), false);
});

test('unrecoverable semantic config corruption never serves Apple Park defaults to CLIENT_TOKEN', async () => {
  const current = mod.readLoc();
  try {
    if (fs.existsSync(process.env.BACKUP_FILE)) fs.unlinkSync(process.env.BACKUP_FILE);
    if (fs.existsSync(process.env.HISTORY_DIR)) fs.rmSync(process.env.HISTORY_DIR,{recursive:true,force:true});
    fs.writeFileSync(process.env.DATA_FILE, JSON.stringify({latitude:'broken',longitude:0}));

    const app = http.createServer(mod.handler); await listen(app); const port=app.address().port;
    try {
      const client = await httpReq(port, '/loc.json?token=' + encodeURIComponent(process.env.CLIENT_TOKEN));
      assert.equal(client.status, 503);
      assert.match(client.text,/configuration unavailable/);
      assert.equal(client.headers['x-config-degraded'],'1');

      // Admin remains able to load the repair form/default state and save a valid location.
      const admin = await httpReq(port, '/loc.json', 'GET', null, authHeaders());
      assert.equal(admin.status, 200);
      assert.equal(admin.headers['x-config-degraded'],'1');

      const profile = await httpReq(port, '/profiles/shadowrocket.sgmodule?token=' + encodeURIComponent(process.env.CLIENT_TOKEN));
      assert.equal(profile.status, 503);
    } finally {
      app.close();
    }
  } finally {
    mod.writeLoc(current, {backup:false});
  }
});
