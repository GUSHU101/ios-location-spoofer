#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

if [[ ! -f .env ]]; then
  echo "启动失败：缺少 .env。先执行：cp .env.example .env，然后填写 TOKEN。" >&2
  exit 1
fi

exec node server.js
