#!/usr/bin/env node
'use strict';
const fs=require('fs');
const path=require('path');
const crypto=require('crypto');
const releaseRoot=path.resolve(__dirname,'..','..');
const manifest=path.join(releaseRoot,'RELEASE-MANIFEST.sha256');
if(!fs.existsSync(manifest)){console.error('VERIFY-RELEASE: FAIL (RELEASE-MANIFEST.sha256 missing)');process.exit(1);}
let failed=false,count=0;
for(const raw of fs.readFileSync(manifest,'utf8').split(/\r?\n/)){
  const line=raw.trim();if(!line||line.startsWith('#'))continue;
  const m=line.match(/^([0-9a-f]{64})\s{2}(.+)$/i);
  if(!m){console.error('✗ malformed manifest line: '+raw);failed=true;continue;}
  const expected=m[1].toLowerCase(),rel=m[2];
  if(path.isAbsolute(rel)||rel.split(/[\\/]/).includes('..')){console.error('✗ unsafe manifest path: '+rel);failed=true;continue;}
  const file=path.resolve(releaseRoot,rel);
  if(!file.startsWith(releaseRoot+path.sep)){console.error('✗ manifest path escapes release root: '+rel);failed=true;continue;}
  if(!fs.existsSync(file)||!fs.statSync(file).isFile()){console.error('✗ missing: '+rel);failed=true;continue;}
  const actual=crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
  count++;
  if(actual!==expected){console.error('✗ SHA256 mismatch: '+rel);failed=true;}
}
if(count===0){console.error('VERIFY-RELEASE: FAIL (manifest empty)');process.exit(1);}
console.log((failed?'VERIFY-RELEASE: FAILED':'VERIFY-RELEASE: PASS')+' ('+count+' files checked)');
if(failed)process.exitCode=1;
