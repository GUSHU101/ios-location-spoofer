#!/usr/bin/env node
'use strict';

const fs=require('fs');
const path=require('path');
const root=path.resolve(__dirname,'..');
const releaseRoot=path.resolve(root,'..');
let failed=false;
function ok(s){console.log('✓ '+s)}
function fail(s){failed=true;console.error('✗ '+s)}
function check(cond,good,bad){cond?ok(good):fail(bad||good)}
function text(f){return fs.readFileSync(path.join(root,f),'utf8')}

const pkg=JSON.parse(text('package.json'));
const server=text('server.js');
const app=text('public/app.js');
const watchdog=text('public/watchdog.js');
const css=text('public/app.css');
const env=text('.env.example');
const adv=text('.env.advanced.example');
const nginx=text('baota-nginx-8081.conf.example');
const service=text('location-picker.service.example');
const docker=text('Dockerfile');
const compose=text('docker-compose.yml');

check(pkg.version==='11.0.0'&&pkg.name==='ios-location-picker-v11','package 版本/名称为 V11');
check(pkg.scripts&&pkg.scripts['smoke:nginx']==='bash tools/nginx-smoke.sh','package 提供真实 Nginx TLS 专项 smoke 命令');
check(fs.existsSync(path.join(root,'tools','nginx-smoke.sh')),'发布包包含 Nginx TLS 烟测脚本');
check(/const APP_VERSION = "11\.0\.0";/.test(server),'server APP_VERSION=11.0.0');
check(/location picker v11 listening/.test(server),'启动日志版本为 V11');
check(/location-spoofer-location-picker\/11\.0/.test(server),'默认 User-Agent 已升级 V11');

check(/href="\/assets\/app\.css\?v=\$\{FRONTEND_BUILD_ID\}"/.test(server),'后台 CSS 为同源本地资源');
check(/src="\/assets\/watchdog\.js\?v=\$\{FRONTEND_BUILD_ID\}"/.test(server)&&/src="\/assets\/app\.js\?v=\$\{FRONTEND_BUILD_ID\}"/.test(server),'后台 JS/Watchdog 为同源本地资源');
check(/function computeFrontendBuildId/.test(server)&&/FRONTEND_BUILD_ID = computeFrontendBuildId\(\)/.test(server),'后台静态资源 URL 绑定内容指纹，热修不会复用旧 URL');
const pageStart=server.indexOf('const PAGE = `');
const pageEnd=server.indexOf('`;',pageStart+20);
const page=pageStart>=0&&pageEnd>pageStart?server.slice(pageStart,pageEnd):'';
check(!/<script[^>]+src="https?:\/\//i.test(page),'PAGE 不含第三方阻塞脚本');
check(!/unpkg\.com\/leaflet|cdn\.jsdelivr\.net\/npm\/leaflet/i.test(page),'PAGE 不直接依赖 Leaflet CDN');
check(/"script-src 'self'"/.test(server)&&!/script-src[^\n]*unsafe-inline/.test(server),'主后台 CSP 禁止 inline/第三方脚本');
check(/function staticAssetDefinition/.test(server)&&/\/assets\/app\.js/.test(server),'服务器只读提供本地前端静态文件');
check(/no-cache, max-age=0, must-revalidate/.test(server)&&/sha256-/.test(server),'后台本地资源使用 ETag 强制重新验证，避免跨补丁版本陈旧缓存');
check(/function localFrontendAssetsStatus/.test(server)&&/frontendAssets:\{ local:localFrontendAssetsStatus\(\)/.test(server),'health 动态检查本地前端资源，不硬编码 ready');

check(/AbortController/.test(app)&&/timeoutMs\|\|8000/.test(app),'所有后台 API fetch 有默认超时/AbortController');
check(/apiFetch\("\/logout"[\s\S]*timeoutMs:5000/.test(app),'登出请求也有超时保护，不会因反代/网络异常永久等待');
check(/function startOptionalMapEngine/.test(app)&&/loadSavedConfig\(\)\.catch/.test(app)&&/startOptionalMapEngine\(\)/.test(app),'配置加载与地图加载完全解耦并行启动');
check(/\/assets\/vendor\/leaflet\/leaflet\.js/.test(app)&&!/https?:\/\/unpkg\.com\/leaflet/.test(app),'浏览器仅从同源 Leaflet 端点加载可选地图组件');
check(/window\.__LP_BOOT_OK=true/.test(app)&&/window\.__LP_APP_VERSION="11\.0\.0"/.test(app),'app.js 提供明确启动信号/版本');
check(/__LP_BOOT_OK/.test(watchdog)&&/setTimeout/.test(watchdog)&&/6 秒内启动/.test(watchdog),'独立 Watchdog 能发现 app.js 未启动');
check(/不能等待 DOMContentLoaded/.test(watchdog)&&/window\.__LP_WATCHDOG_TIMER=setTimeout/.test(watchdog),'Watchdog 计时不依赖 DOMContentLoaded，能识别 defer app.js 长时间 Pending');
check(/地图属于可选增强/.test(server)&&/纯手工经纬度/.test(app),'地图故障不阻塞手工坐标兜底');
check(/\.lp-pin/.test(css)&&/L\.divIcon/.test(app),'地图图钉不依赖 Leaflet 外部 marker 图片');
check(/cleanupFailedScript/.test(app)&&/removeChild\(script\)/.test(app),'Leaflet 加载超时会移除迟到脚本，避免降级后异步污染全局状态');
check(/typeof map\.remove==="function"/.test(app),'地图初始化失败/降级前释放 Leaflet 实例与事件');

check(/LEAFLET_SOURCE_BASES/.test(server)&&/unpkg\.com\/leaflet@1\.9\.4/.test(server)&&/cdn\.jsdelivr\.net\/npm\/leaflet@1\.9\.4/.test(server),'Leaflet 服务端缓存具备双源回退');
check(/LEAFLET_JS_SHA384/.test(server)&&/cxOPjt7s7Iz04uaHJceBmS\+qpjv2JkIHNVcuOrM\+YHwZOmJGBXI00mdUXEq65HTH/.test(server),'Leaflet JS SHA-384 完整性锁定');
check(/LEAFLET_CSS_SHA384/.test(server)&&/sHL9NAb7lN7rfvG5lfHpm643Xkcjzp4jFvuavGOndn6pjVqS6ny56CAt3nsEVT4H/.test(server),'Leaflet CSS SHA-384 完整性锁定');
check(/function validateLeafletAssetBuffer/.test(server)&&/sha384Base64/.test(server),'Leaflet 缓存落盘前做 SHA-384 校验');
check(/LEAFLET_RETRY_COOLDOWN_MS/.test(server)&&/LEAFLET_COOLDOWN/.test(server),'Leaflet 外部源失败后有冷却窗口，避免刷新页面反复触发阻塞外连');
check(/LEAFLET_RETRY_COOLDOWN_MS=60000/.test(adv),'高级模板暴露 Leaflet 失败重试冷却参数');

check(/UPSTREAM_RETRY_COOLDOWN_MS/.test(server)&&/UPSTREAM_COOLDOWN/.test(server),'上游客户端核心故障后有冷却窗口，公共端点不会反复触发外连');
check(/UPSTREAM_RETRY_COOLDOWN_MS=60000/.test(adv),'高级模板暴露上游核心失败重试冷却参数');

check(/cross-host upstream redirect blocked/.test(server)&&/protocol downgrade blocked/.test(server),'第三方资产下载禁止跨主机重定向和 HTTPS→HTTP 降级，收紧 SSRF/供应链边界');

check(/ALLOW_LEGACY_ADMIN_QUERY_TOKEN \|\| "false"/.test(server),'旧管理 TOKEN query 兼容默认关闭');
check(/safeEqual\(q, CLIENT_TOKEN\) \|\| \(ALLOW_LEGACY_ADMIN_QUERY_TOKEN && safeEqual\(q, TOKEN\)\)/.test(server),'只读 URL 默认仅接受 CLIENT_TOKEN');
check(/clientSource === "github" \|\| clientSource === "self"/.test(server),'模块 URL 可显式固定 self/github 脚本来源');
check(/return String\(spec\.expectedBlobSha \|\| UPSTREAM_AUDITED_COMMIT\);/.test(server),'客户端 immutable URL 使用完整 40 位 blob 版本，不截断');
check(/function optionalNumberField/.test(server)&&/function optionalBooleanField/.test(server),'写入字段继续严格类型校验');
check(/function validateStoredLocInput/.test(server)&&/CONFIG_DEGRADED/.test(server),'持久化损坏检测/降级保护继续存在');
check(/function requestTargetForLog/.test(server),'Node 异常日志继续去除 query token');

check(/^TOKEN=\s*$/m.test(env),'.env.example 未内置管理 TOKEN');
check(!/^CLIENT_TOKEN=[^#\s]/m.test(env),'.env.example 未内置 CLIENT_TOKEN');
check(!/^\s*(CERT|KEY)=/m.test(env),'.env.example 不要求 Node TLS CERT/KEY');
check(/ALLOW_LEGACY_ADMIN_QUERY_TOKEN=false/.test(adv),'高级模板明确旧管理 TOKEN query 默认关闭');

check(/listen 8081 ssl;/.test(nginx),'Nginx 公网 HTTPS 使用 8081');
check(!/listen\s+443(?:\s|;)/.test(nginx),'Nginx 示例不监听 443');
check(/proxy_pass http:\/\/127\.0\.0\.1:8080;/.test(nginx),'Nginx 反代 Node 127.0.0.1:8080');
check(/proxy_set_header Host \$http_host;/.test(nginx),'Nginx 保留非标准端口 Host');
check(/location\s*=\s*\/loc\.json[\s\S]*?access_log\s+off\s*;/.test(nginx),'loc.json 关闭 access_log');
check(/location\s+\^~\s+\/profiles\/[\s\S]*?access_log\s+off\s*;/.test(nginx),'profiles URL 关闭 access_log');
check(/location\s*=\s*\/[\s\S]*?access_log\s+off\s*;/.test(nginx),'根路径关闭 access_log，兼容旧 admin query 登录时不落 token');

check(/COPY public \.\/public/.test(docker),'Docker 镜像包含 V11 本地前端资源');
check(/LEAFLET_CACHE_DIR=\/data\/vendor-cache\/leaflet-1\.9\.4/.test(docker),'Docker Leaflet 缓存落到可写 /data');
check(/LEAFLET_CACHE_DIR: \/data\/vendor-cache\/leaflet-1\.9\.4/.test(compose),'Docker Compose 持久化 Leaflet 缓存路径');
check(/location_picker_data:\/data/.test(compose)&&/volumes:\s*\n\s*location_picker_data:/.test(compose),'Docker Compose 使用 named volume');
check(/Description=iOS Location Picker V11/.test(service)&&/ios-location-spoofer-ip2location-v11/.test(service),'systemd 示例升级 V11');
const doctor=text('tools/doctor.js');
check(/startsWith\('11\.'\)/.test(doctor)&&/前端资源存在/.test(doctor),'doctor 识别 V11 并检查本地前端文件');
check(/管理 TOKEN query 隔离/.test(doctor)&&/LEAFLET_RETRY_COOLDOWN_MS/.test(doctor)&&/UPSTREAM_RETRY_COOLDOWN_MS/.test(doctor),'doctor 检查 token 隔离、Leaflet 与上游核心故障冷却配置');

const forbidden=[];
function walk(dir){
  for(const name of fs.readdirSync(dir)){
    const p=path.join(dir,name),st=fs.statSync(p);
    if(st.isDirectory()){
      if(['upstream-cache','vendor-cache','history'].includes(name))forbidden.push(path.relative(releaseRoot,p)+'/');
      else walk(p);
    }else if(name==='.env'||/^loc(?:\.meta|\.backup)?\.json$/.test(name)||/^loc\.corrupt-/.test(name))forbidden.push(path.relative(releaseRoot,p));
  }
}
walk(releaseRoot);
check(forbidden.length===0,'发布目录不含 .env/loc.json/history/cache 运行数据','发布目录含运行数据: '+forbidden.join(', '));

for(const f of ['server.js','public/app.js','.env.example','baota-nginx-8081.conf.example','package.json']){
  const t=text(f);
  // server.js 中 KDF label ios-location-picker-client-v10 被有意冻结，以避免升级改变派生 CLIENT_TOKEN。
  const scrub=f==='server.js'?t.replace(/ios-location-picker-client-v10/g,''):t;
  check(!/Location Picker V10|定位选点 V10|location picker v10|ios-location-picker-v10/.test(scrub),f+' 不残留 V10 运行版本标识');
}

console.log('\nRELEASE-AUDIT: '+(failed?'FAILED':'PASS'));
if(failed)process.exitCode=1;
