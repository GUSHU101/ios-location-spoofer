#!/usr/bin/env node
'use strict';

(async () => {
  const mod = require('../server.js');
  let failed = false;
  for (const kind of ['core', 'qx']) {
    try {
      const buf = await mod.ensureUpstreamAsset(kind, { force: true });
      const check = mod.validateUpstreamAssetBuffer(kind, buf);
      console.log(`✓ ${kind}: ${buf.length} bytes, git-blob=${check.actualSha}`);
    } catch (e) {
      failed = true;
      console.error(`✗ ${kind}: ${e && e.message || e}`);
    }
  }
  const status = mod.upstreamAssetsStatus();
  console.log(JSON.stringify(status, null, 2));
  if (failed) process.exitCode = 1;
})().catch(e => {
  console.error(e && e.stack || e);
  process.exitCode = 1;
});
