#!/usr/bin/env node
'use strict';

const fs=require('fs');
const path=require('path');
const {spawnSync}=require('child_process');

const root=path.resolve(__dirname,'..');
let failed=false;
function run(label,cmd,args,opts={}){
  process.stdout.write('\n== '+label+' ==\n');
  const r=spawnSync(cmd,args,{cwd:root,stdio:'inherit',...opts});
  if(r.status!==0){failed=true;console.error('✗ '+label+' failed');}
  else console.log('✓ '+label);
}

function jsFiles(dir){
  const out=[];
  for(const name of fs.readdirSync(dir)){
    const p=path.join(dir,name);const st=fs.statSync(p);
    if(st.isDirectory()){
      if(['upstream-cache','vendor-cache','history','node_modules'].includes(name))continue;
      out.push(...jsFiles(p));
    }else if(/\.(?:js|cjs|mjs)$/.test(name))out.push(p);
  }
  return out;
}

process.stdout.write('iOS Location Picker V11 deep self-check\n');
for(const file of jsFiles(root)){
  const rel=path.relative(root,file);
  run('syntax '+rel,process.execPath,['--check',rel]);
}
for(const file of fs.readdirSync(path.join(root,'tools')).filter(n=>n.endsWith('.sh')).map(n=>path.join(root,'tools',n))){
  const rel=path.relative(root,file);
  run('shell syntax '+rel,'bash',['-n',rel]);
}
if(fs.existsSync(path.join(root,'start.sh')))run('shell syntax start.sh','bash',['-n','start.sh']);
run('automated integration tests',process.execPath,['--test','test/*.test.js'],{shell:true});
run('release audit',process.execPath,['tools/release-audit.js']);

// 真浏览器烟测不依赖 npm。若当前环境没有 Chromium 或组织策略禁止本地导航，脚本会明确 SKIP；
// 设置 REQUIRE_BROWSER_SMOKE=1 可把这种情况提升为必须通过。
run('browser smoke (when environment permits)',process.execPath,['tools/browser-smoke.js']);

// 宝塔/Nginx 部署专项：若机器上存在 nginx+openssl+curl，启动临时高端口 TLS 反代做真正 HTTPS 写入/Origin/日志泄漏回归；
// 不存在依赖时脚本明确 SKIP，不影响非 Nginx 部署。
run('real Nginx TLS reverse-proxy smoke (when available)','bash',['tools/nginx-smoke.sh']);

if(fs.existsSync(path.join(root,'.env')))run('deployment doctor',process.execPath,['tools/doctor.js']);
else console.log('\n! 未发现 .env，跳过部署环境 doctor（发布包自检属于正常情况）');

console.log('\nSELF-CHECK: '+(failed?'FAILED':'PASS'));
if(failed)process.exitCode=1;
