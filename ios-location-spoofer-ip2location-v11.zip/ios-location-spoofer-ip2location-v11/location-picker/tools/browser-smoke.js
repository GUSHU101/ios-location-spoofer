#!/usr/bin/env node
'use strict';

const fs=require('fs');
const os=require('os');
const path=require('path');
const net=require('net');
const http=require('http');
const {spawn}=require('child_process');

const root=path.resolve(__dirname,'..');
function findChromium(){
  const candidates=[process.env.CHROMIUM_BIN,'/usr/bin/chromium','/usr/bin/chromium-browser','/usr/bin/google-chrome','/usr/bin/google-chrome-stable'].filter(Boolean);
  return candidates.find(p=>fs.existsSync(p))||'';
}
function freePort(){return new Promise((resolve,reject)=>{const s=net.createServer();s.on('error',reject);s.listen(0,'127.0.0.1',()=>{const p=s.address().port;s.close(()=>resolve(p));});});}
function sleep(ms){return new Promise(r=>setTimeout(r,ms));}
function requestJson(port,pathname){return new Promise(resolve=>{const req=http.get({hostname:'127.0.0.1',port,path:pathname,timeout:600},res=>{let t='';res.on('data',c=>t+=c);res.on('end',()=>{try{resolve(JSON.parse(t))}catch{resolve(null)}})});req.on('timeout',()=>req.destroy());req.on('error',()=>resolve(null));});}
function health(port){return requestJson(port,'/health');}
async function waitFor(fn,timeoutMs,step=100){const end=Date.now()+timeoutMs;while(Date.now()<end){const v=await fn();if(v)return v;await sleep(step);}return null;}

class CDP {
  constructor(url){this.url=url;this.ws=null;this.nextId=1;this.pending=new Map();this.exceptions=[];}
  async connect(){
    this.ws=new WebSocket(this.url);
    await new Promise((resolve,reject)=>{const t=setTimeout(()=>reject(new Error('CDP websocket timeout')),3000);this.ws.addEventListener('open',()=>{clearTimeout(t);resolve();},{once:true});this.ws.addEventListener('error',()=>{clearTimeout(t);reject(new Error('CDP websocket error'));},{once:true});});
    this.ws.addEventListener('message',ev=>{
      let m;try{m=JSON.parse(String(ev.data));}catch{return;}
      if(m.id&&this.pending.has(m.id)){const p=this.pending.get(m.id);this.pending.delete(m.id);m.error?p.reject(new Error(m.error.message||'CDP error')):p.resolve(m.result);return;}
      if(m.method==='Runtime.exceptionThrown'){const d=m.params&&m.params.exceptionDetails||{};this.exceptions.push(String(d.text||d.exception&&d.exception.description||'exception').slice(0,500));}
      if(m.method==='Log.entryAdded'){const e=m.params&&m.params.entry;if(e&&e.level==='error')this.exceptions.push(String(e.text||'log error').slice(0,500));}
    });
  }
  send(method,params={}){const id=this.nextId++;return new Promise((resolve,reject)=>{this.pending.set(id,{resolve,reject});this.ws.send(JSON.stringify({id,method,params}));setTimeout(()=>{if(this.pending.has(id)){this.pending.delete(id);reject(new Error('CDP command timeout: '+method));}},4000);});}
  async eval(expression){const r=await this.send('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});return r&&r.result?r.result.value:undefined;}
  close(){try{this.ws&&this.ws.close();}catch{}}
}

async function main(){
  const chrome=findChromium();
  if(!chrome){console.log('BROWSER-SMOKE: SKIP (Chromium not installed)');return;}
  const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'lp-v11-browser-'));
  const appPort=await freePort();
  const debugPort=await freePort();
  const token='browser-smoke-admin-0123456789abcdef0123456789';
  const client='browser-smoke-client-0123456789abcdef';
  const env={...process.env,
    TOKEN:token,CLIENT_TOKEN:client,HOST:'127.0.0.1',PORT:String(appPort),TRUST_PROXY:'false',
    DATA_FILE:path.join(tmp,'loc.json'),META_FILE:path.join(tmp,'loc.meta.json'),BACKUP_FILE:path.join(tmp,'loc.backup.json'),HISTORY_DIR:path.join(tmp,'history'),
    UPSTREAM_PRELOAD:'false',LEAFLET_PRELOAD:'false',LEAFLET_FETCH_TIMEOUT_MS:'1000',
    LEAFLET_SOURCE_BASES:'http://127.0.0.1:9/unavailable',UPSTREAM_CACHE_DIR:path.join(tmp,'upstream-cache'),LEAFLET_CACHE_DIR:path.join(tmp,'leaflet-cache')
  };
  const app=spawn(process.execPath,['server.js'],{cwd:root,env,stdio:['ignore','pipe','pipe']});
  let appErr='';app.stderr.on('data',c=>appErr+=c);
  let chromeProc=null,cdp=null;
  try{
    const h=await waitFor(async()=>{const x=await health(appPort);return x&&x.ok?x:null;},5000,80);
    if(!h)throw new Error('server did not start: '+appErr.slice(0,800));
    const profile=path.join(tmp,'chrome-profile');
    const smokeHost='lp-smoke.test';
    const url='http://'+smokeHost+':'+appPort+'/?token='+encodeURIComponent(token);
    chromeProc=spawn(chrome,[
      '--headless=new','--no-sandbox','--no-proxy-server','--proxy-bypass-list=*','--disable-gpu','--disable-dev-shm-usage','--disable-background-networking','--disable-component-update',
      '--no-first-run','--no-default-browser-check','--host-resolver-rules=MAP lp-smoke.test 127.0.0.1','--remote-debugging-address=127.0.0.1','--remote-debugging-port='+debugPort,
      '--user-data-dir='+profile,url
    ],{stdio:['ignore','ignore','pipe'],env:{...process.env,TERM:process.env.TERM||'dumb'}});
    let chromeErr='';chromeProc.stderr.on('data',c=>{if(chromeErr.length<8000)chromeErr+=c});

    const page=await waitFor(async()=>{const list=await requestJson(debugPort,'/json/list');return Array.isArray(list)&&(list.find(x=>x.type==='page'&&x.webSocketDebuggerUrl&&String(x.url||'').includes('lp-smoke.test:'+appPort))||list.find(x=>x.type==='page'&&x.webSocketDebuggerUrl))||null;},6000,100);
    if(!page)throw new Error('Chromium DevTools did not become ready: '+chromeErr.slice(0,1200));
    cdp=new CDP(page.webSocketDebuggerUrl);await cdp.connect();
    await cdp.send('Runtime.enable');await cdp.send('Log.enable');

    const state=await waitFor(async()=>{
      try{
        const v=await cdp.eval(`(()=>({title:document.title,status:document.getElementById('statusline')?.textContent||'',mode:document.getElementById('modetext')?.textContent||'',info:document.getElementById('info')?.textContent||'',map:document.getElementById('map')?.textContent||'',boot:window.__LP_BOOT_OK===true,app:window.__LP_APP_VERSION||''}))()`);
        if(v&&v.boot&&v.app==='11.0.0'&&!/前端启动中|正在检查服务状态/.test(v.status)&&!/等待前端主程序启动/.test(v.mode)&&!/等待配置读取|正在读取已保存配置/.test(v.info))return v;
      }catch{}
      return null;
    },10000,180);
    if(!state){let last={};try{last=await cdp.eval(`(()=>({url:location.href,title:document.title,status:document.getElementById('statusline')?.textContent||'',mode:document.getElementById('modetext')?.textContent||'',info:document.getElementById('info')?.textContent||'',boot:window.__LP_BOOT_OK,app:window.__LP_APP_VERSION,body:(document.body&&document.body.innerText||'').slice(0,600)}))()`);}catch{} if(/is blocked|organization.*allow/i.test(String(last.body||''))&&!/^(1|true|yes)$/i.test(process.env.REQUIRE_BROWSER_SMOKE||'')){console.log('BROWSER-SMOKE: SKIP (local HTTP navigation blocked by Chromium organization policy in this environment)');return;} throw new Error('page remained in loading/boot state: '+JSON.stringify(last)+' exceptions='+cdp.exceptions.join(' | '));}
    if(state.title!=='定位选点 V11')throw new Error('unexpected title: '+state.title);
    if(!/V11\.0\.0/.test(state.status))throw new Error('status did not reach V11 runtime: '+state.status);
    if(cdp.exceptions.length)throw new Error('browser runtime errors: '+cdp.exceptions.join(' | '));
    // Leaflet source is intentionally unreachable: this proves optional map failure cannot block core UI.
    if(!/地图|手工|定位/.test(state.mode))throw new Error('manual/map fallback state not visible: '+state.mode);
    console.log('✓ Real Chromium executed watchdog.js + app.js with no uncaught runtime exceptions');
    console.log('✓ Optional Leaflet source was intentionally unavailable, but admin core still completed boot');
    console.log('✓ status: '+state.status.slice(0,240));
    console.log('✓ mode: '+state.mode.slice(0,240));
    console.log('BROWSER-SMOKE: PASS');
  } finally {
    if(cdp)cdp.close();
    if(chromeProc){try{chromeProc.kill('SIGTERM')}catch{};setTimeout(()=>{try{chromeProc.kill('SIGKILL')}catch{}},500).unref();}
    try{app.kill('SIGTERM')}catch{};
    await sleep(250);
    try{fs.rmSync(tmp,{recursive:true,force:true});}catch{}
  }
}
main().catch(e=>{console.error('BROWSER-SMOKE: FAIL\n'+(e.stack||e));process.exitCode=1;});
