#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
NGINX_BIN="$(command -v nginx || true)"
if [[ -z "$NGINX_BIN" && -x /www/server/nginx/sbin/nginx ]]; then NGINX_BIN=/www/server/nginx/sbin/nginx; fi
for cmd in node openssl curl; do
  if ! command -v "$cmd" >/dev/null 2>&1; then
    echo "NGINX-SMOKE: SKIP ($cmd not installed)"
    exit 0
  fi
done
if [[ -z "$NGINX_BIN" ]]; then
  echo "NGINX-SMOKE: SKIP (nginx not installed)"
  exit 0
fi
free_port(){ node -e 'const n=require("net"),s=n.createServer();s.listen(0,"127.0.0.1",()=>{console.log(s.address().port);s.close()});'; }
NODE_PORT="$(free_port)"
TLS_PORT="$(free_port)"
TMP="$(mktemp -d "${TMPDIR:-/tmp}/lp-v11-nginx-smoke-XXXXXX")"
ADMIN="nginx-smoke-admin-0123456789abcdef0123456789"
CLIENT="nginx-smoke-client-0123456789abcdef0123456789"
mkdir -p "$TMP/data" "$TMP/upstream" "$TMP/vendor" "$TMP/nginx/conf" "$TMP/nginx/logs"

TOKEN="$ADMIN" CLIENT_TOKEN="$CLIENT" HOST=127.0.0.1 PORT="$NODE_PORT" TRUST_PROXY=true \
DATA_FILE="$TMP/data/loc.json" META_FILE="$TMP/data/loc.meta.json" BACKUP_FILE="$TMP/data/loc.backup.json" HISTORY_DIR="$TMP/data/history" \
UPSTREAM_CACHE_DIR="$TMP/upstream" LEAFLET_CACHE_DIR="$TMP/vendor" UPSTREAM_PRELOAD=false LEAFLET_PRELOAD=false \
node "$ROOT/server.js" >"$TMP/node.log" 2>&1 &
NODE_PID=$!
cleanup(){
  kill "$NODE_PID" 2>/dev/null || true
  if [[ -f "$TMP/nginx/logs/nginx.pid" ]]; then
    NGINX_PID="$(cat "$TMP/nginx/logs/nginx.pid" 2>/dev/null || true)"
    if [[ "$NGINX_PID" =~ ^[0-9]+$ ]]; then
      kill -QUIT "$NGINX_PID" 2>/dev/null || true
      for _ in $(seq 1 20); do kill -0 "$NGINX_PID" 2>/dev/null || break; sleep .05; done
    fi
  fi
  rm -rf "$TMP"
}
trap cleanup EXIT
for _ in $(seq 1 60); do
  if curl --noproxy '*' -fsS "http://127.0.0.1:$NODE_PORT/health" >/dev/null 2>&1; then break; fi
  sleep .1
done
curl --noproxy '*' -fsS "http://127.0.0.1:$NODE_PORT/health" >/dev/null || { cat "$TMP/node.log" >&2; echo 'NGINX-SMOKE: FAIL (Node did not start)' >&2; exit 1; }

openssl req -x509 -newkey rsa:2048 -nodes -days 1 -subj '/CN=ios.caseora.cc' -keyout "$TMP/key.pem" -out "$TMP/cert.pem" >/dev/null 2>&1
cat > "$TMP/nginx/conf/nginx.conf" <<NGINX
worker_processes 1;
pid logs/nginx.pid;
events { worker_connections 256; }
http {
  server {
    listen $TLS_PORT ssl;
    http2 on;
    server_name ios.caseora.cc;
    ssl_certificate $TMP/cert.pem;
    ssl_certificate_key $TMP/key.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers 'HIGH:!aNULL:!MD5:!3DES';
    location = /loc.json { access_log off; proxy_pass http://127.0.0.1:$NODE_PORT; proxy_http_version 1.1; proxy_set_header Host \$http_host; proxy_set_header X-Real-IP \$remote_addr; proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for; proxy_set_header X-Forwarded-Proto https; proxy_set_header X-Forwarded-Host \$http_host; proxy_set_header X-Forwarded-Port $TLS_PORT; proxy_set_header Connection ""; }
    location ^~ /profiles/ { access_log off; proxy_pass http://127.0.0.1:$NODE_PORT; proxy_http_version 1.1; proxy_set_header Host \$http_host; proxy_set_header X-Real-IP \$remote_addr; proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for; proxy_set_header X-Forwarded-Proto https; proxy_set_header X-Forwarded-Host \$http_host; proxy_set_header X-Forwarded-Port $TLS_PORT; proxy_set_header Connection ""; }
    location = / { access_log off; proxy_pass http://127.0.0.1:$NODE_PORT; proxy_http_version 1.1; proxy_set_header Host \$http_host; proxy_set_header X-Real-IP \$remote_addr; proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for; proxy_set_header X-Forwarded-Proto https; proxy_set_header X-Forwarded-Host \$http_host; proxy_set_header X-Forwarded-Port $TLS_PORT; proxy_set_header Connection ""; }
    location / { proxy_pass http://127.0.0.1:$NODE_PORT; proxy_http_version 1.1; proxy_set_header Host \$http_host; proxy_set_header X-Real-IP \$remote_addr; proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for; proxy_set_header X-Forwarded-Proto https; proxy_set_header X-Forwarded-Host \$http_host; proxy_set_header X-Forwarded-Port $TLS_PORT; proxy_set_header Connection ""; client_max_body_size 32k; proxy_buffering off; proxy_cache off; }
    access_log $TMP/nginx/access.log;
    error_log $TMP/nginx/error.log notice;
  }
}
NGINX
"$NGINX_BIN" -p "$TMP/nginx/" -c conf/nginx.conf -t >/dev/null
"$NGINX_BIN" -p "$TMP/nginx/" -c conf/nginx.conf
base="https://ios.caseora.cc:$TLS_PORT"
curlx(){ curl --noproxy '*' -skS --resolve "ios.caseora.cc:$TLS_PORT:127.0.0.1" "$@"; }
status(){ curlx -o "$2" -w '%{http_code}' "$1"; }

[[ "$(status "$base/health" "$TMP/health.json")" == 200 ]]
grep -q '"version":"11.0.0"' "$TMP/health.json"
[[ "$(status "$base/loc.json?token=$CLIENT" "$TMP/loc.json")" == 200 ]]
[[ "$(status "$base/profiles/shadowrocket.sgmodule?token=$CLIENT&clientSource=self" "$TMP/profile.txt")" == 200 ]]
grep -q 'iOS Location Spoofer' "$TMP/profile.txt"
login_code="$(curlx -c "$TMP/cookies" -o "$TMP/login.out" -w '%{http_code}' -H 'Content-Type: application/x-www-form-urlencoded' --data-urlencode "token=$ADMIN" "$base/login")"
[[ "$login_code" == 303 || "$login_code" == 302 ]]
[[ "$(curlx -b "$TMP/cookies" -o "$TMP/page.html" -w '%{http_code}' "$base/")" == 200 ]]
grep -q '/assets/app.js?v=11.0.0-' "$TMP/page.html"
[[ "$(curlx -b "$TMP/cookies" -D "$TMP/app.headers" -o "$TMP/app.js" -w '%{http_code}' "$base/assets/app.js")" == 200 ]]
grep -qi 'Cache-Control: no-cache, max-age=0, must-revalidate' "$TMP/app.headers"
set_code="$(curlx -b "$TMP/cookies" -o "$TMP/set.out" -w '%{http_code}' -H "Origin: $base" -H 'Content-Type: application/json' --data '{"lat":40.7128,"lng":-74.006,"horizontalAccuracy":39,"verticalAccuracy":1000,"altitude":10}' "$base/set")"
[[ "$set_code" == 200 ]]
if grep -Fq "$CLIENT" "$TMP/nginx/access.log" 2>/dev/null; then echo 'NGINX-SMOKE: FAIL (CLIENT_TOKEN leaked into access log)' >&2; exit 1; fi

echo "✓ real Nginx TLS reverse proxy -> Node passed on temporary ports $TLS_PORT -> $NODE_PORT"
echo "✓ HTTPS Origin reconstruction and protected POST /set passed"
echo "✓ CLIENT_TOKEN loc/profile URLs did not enter Nginx access log"
echo "NGINX-SMOKE: PASS"
