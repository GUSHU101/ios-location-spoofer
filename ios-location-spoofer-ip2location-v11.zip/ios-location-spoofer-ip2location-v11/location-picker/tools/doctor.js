const fs = require('fs');
const path = require('path');
const net = require('net');
const http = require('http');
const dns = require('dns').promises;
const crypto = require('crypto');

const root = path.resolve(__dirname, '..');
const envFile = path.join(root, '.env');
let failed = false;
let warned = false;
function ok(msg) { console.log('✓ ' + msg); }
function warn(msg) { warned = true; console.log('! ' + msg); }
function fail(msg) { failed = true; console.error('✗ ' + msg); }

function parseEnv(file) {
  const out = {};
  const duplicates = [];
  const invalid = [];
  if (!fs.existsSync(file)) return { out, duplicates, invalid };
  for (const [idx, raw] of fs.readFileSync(file, 'utf8').replace(/^\uFEFF/, '').split(/\r?\n/).entries()) {
    let line = raw.trim();
    if (!line || line.startsWith('#')) continue;
    if (line.startsWith('export ')) line = line.slice(7).trim();
    const i = line.indexOf('=');
    if (i <= 0) { invalid.push(idx + 1); continue; }
    const k = line.slice(0, i).trim();
    if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(k)) { invalid.push(idx + 1); continue; }
    let v = line.slice(i + 1).trim();
    if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) v = v.slice(1, -1);
    else v = v.replace(/\s+#.*$/, '').trim();
    if (Object.prototype.hasOwnProperty.call(out, k)) duplicates.push(k);
    out[k] = v;
  }
  return { out, duplicates, invalid };
}

function validHttpUrl(name, value) {
  if (!value) return;
  try {
    const u = new URL(value);
    if (!['http:', 'https:'].includes(u.protocol)) return fail(name + ' 只允许 http/https');
    if (u.username || u.password) return fail(name + ' 不应在 URL 中包含账号密码');
    ok(name + '=' + u.origin);
  } catch { fail(name + ' 不是有效 URL'); }
}

function requestHealth(host, port) {
  return new Promise(resolve => {
    const req = http.get({ host, port, path:'/health', timeout:1800 }, res => {
      let text=''; res.setEncoding('utf8'); res.on('data', c => text += c);
      res.on('end', () => {
        try { resolve({ ok:res.statusCode===200, status:res.statusCode, data:JSON.parse(text) }); }
        catch { resolve({ ok:false, status:res.statusCode, data:null }); }
      });
    });
    req.on('timeout', () => req.destroy());
    req.on('error', () => resolve(null));
  });
}

function requestPath(host, port, reqPath, options={}) {
  return new Promise(resolve => {
    const req = http.request({ host, port, path:reqPath, method:options.method || 'GET', timeout:2200, headers:options.headers || {} }, res => {
      let text=''; res.setEncoding('utf8'); res.on('data', c => text += c);
      res.on('end', () => resolve({ status:res.statusCode, text, headers:res.headers }));
    });
    req.on('timeout', () => req.destroy());
    req.on('error', () => resolve(null));
    if (options.body) req.write(options.body);
    req.end();
  });
}

function deriveClientToken(adminToken) {
  // KDF label 有意冻结为 v10：升级 V10→V11 时，未显式配置 CLIENT_TOKEN 的手机订阅 URL 不会突然失效。
  return crypto.createHmac('sha256', adminToken).update('ios-location-picker-client-v10','utf8').digest('hex').slice(0,32);
}

async function portState(host, port) {
  return new Promise(resolve => {
    const server = net.createServer();
    server.once('error', e => resolve(e.code === 'EADDRINUSE' ? 'in-use' : 'error:' + e.message));
    server.once('listening', () => server.close(() => resolve('free')));
    server.listen(port, host);
  });
}

function checkJsonFile(label, file) {
  if (!fs.existsSync(file)) { warn(label + ' 不存在：' + file); return false; }
  try {
    const d = JSON.parse(fs.readFileSync(file, 'utf8'));
    if (!d || typeof d !== 'object' || Array.isArray(d)) throw new Error('根节点必须是 object');
    const lat = Number(d.latitude), lng = Number(d.longitude);
    if (!Number.isFinite(lat) || lat < -90 || lat > 90) throw new Error('latitude 无效或超出 -90..90');
    if (!Number.isFinite(lng) || lng < -180 || lng > 180) throw new Error('longitude 无效或超出 -180..180');
    for (const [key,min,max] of [['horizontalAccuracy',0,1000000],['verticalAccuracy',0,1000000],['altitude',-12000,100000]]) {
      if (!(key in d) || d[key] === null || d[key] === '') continue;
      const n = Number(d[key]);
      if (!Number.isFinite(n) || n < min || n > max) throw new Error(key + ' 无效');
    }
    for (const key of ['enabled','failOpen','debug']) {
      if (!(key in d)) continue;
      const v = d[key];
      const good = v === true || v === false || v === 0 || v === 1 ||
        (typeof v === 'string' && /^(?:0|1|true|false|yes|no|on|off)$/i.test(v.trim()));
      if (!good) throw new Error(key + ' 不是可识别的布尔值');
    }
    ok(label + ' JSON 语法与字段语义正常：' + file);
    return true;
  } catch (e) {
    fail(label + ' 损坏：' + file + ' | ' + e.message);
    return false;
  }
}

function checkFrontendFiles() {
  const files = [
    ['app.css', path.join(root,'public','app.css')],
    ['watchdog.js', path.join(root,'public','watchdog.js')],
    ['app.js', path.join(root,'public','app.js')]
  ];
  for (const [name,file] of files) {
    try {
      const st=fs.statSync(file);
      if (!st.isFile() || st.size < 100) fail('前端资源异常：' + file);
      else ok('前端资源存在：' + name + ' (' + st.size + ' bytes)');
    } catch (e) { fail('前端资源缺失：' + file + ' | ' + e.message); }
  }
}

function inspectBaota(port) {
  const dir = '/www/server/panel/vhost/nginx';
  if (!fs.existsSync(dir)) return;
  let found = [];
  try {
    for (const name of fs.readdirSync(dir).filter(n => n.endsWith('.conf'))) {
      const file = path.join(dir, name);
      let text=''; try { text = fs.readFileSync(file, 'utf8'); } catch { continue; }
      if (text.includes('proxy_pass http://127.0.0.1:' + port)) found.push({ name, text });
    }
  } catch { return; }
  if (!found.length) return warn('检测到宝塔，但未找到反代到 127.0.0.1:' + port + ' 的 Nginx 站点');
  for (const it of found) {
    ok('宝塔反代匹配：' + it.name + ' → 127.0.0.1:' + port);
    if (/proxy_set_header\s+Host\s+\$http_host\s*;/.test(it.text)) ok(it.name + ' 保留外部 Host/端口 ($http_host)');
    else warn(it.name + ' 建议使用：proxy_set_header Host $http_host;');
    if (/X-Forwarded-Proto/.test(it.text) && /X-Forwarded-Port/.test(it.text)) ok(it.name + ' 已转发 Proto/Port');
    else warn(it.name + ' 缺少 X-Forwarded-Proto 或 X-Forwarded-Port，非标准 HTTPS 端口可能 Origin 校验失败');
    if (/location\s*=\s*\/loc\.json[\s\S]*?access_log\s+off\s*;/.test(it.text)) ok(it.name + ' loc.json 已关闭 access_log，避免 CLIENT_TOKEN 进入访问日志');
    else warn(it.name + ' 建议对 location = /loc.json 设置 access_log off;');
    if (/location\s+\^~\s+\/profiles\/[\s\S]*?access_log\s+off\s*;/.test(it.text)) ok(it.name + ' profiles URL 已关闭 access_log');
    else warn(it.name + ' 建议对 /profiles/ 设置 access_log off;');
    if (/location\s*=\s*\/[\s\S]*?access_log\s+off\s*;/.test(it.text)) ok(it.name + ' 根路径已关闭 access_log，旧 admin query 登录不会落访问日志');
    else warn(it.name + ' 建议对 location = / 设置 access_log off;，避免旧 /?token= 管理链接落日志');
  }
}

async function networkChecks(env) {
  const urls = [
    env.IP2LOCATION_BASE_URL || 'https://api.ip2location.io/',
    env.NOMINATIM_BASE_URL || 'https://nominatim.openstreetmap.org',
    env.ELEVATION_BASE_URL || 'https://api.open-meteo.com/v1/elevation',
    env.UPSTREAM_SOURCE_BASE || 'https://raw.githubusercontent.com/mekos2772/ios-location-spoofer/b72d6f67efb2b457647ae05e3e20ae3f3f6f0262',
    ...String(env.LEAFLET_SOURCE_BASES || 'https://unpkg.com/leaflet@1.9.4/dist,https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist').split(',').map(s=>s.trim()).filter(Boolean)
  ];
  for (const raw of urls) {
    try {
      const u = new URL(raw);
      const hit = await dns.lookup(u.hostname);
      ok('DNS ' + u.hostname + ' → ' + hit.address);
    } catch (e) { warn('DNS/网络解析失败：' + raw + ' | ' + e.message); }
  }
}

async function main() {
  const [major, minor] = process.versions.node.split('.').map(Number);
  if (major > 20 || (major === 20 && minor >= 12)) ok('Node.js ' + process.versions.node);
  else fail('Node.js 版本过低，需要 >=20.12；推荐 22 LTS');

  if (!fs.existsSync(envFile)) {
    fail('.env 不存在：cp .env.example .env');
    process.exitCode = 1; return;
  }
  ok('.env 已存在');
  if (process.platform !== 'win32') {
    try {
      const mode = fs.statSync(envFile).mode & 0o777;
      if ((mode & 0o077) === 0) ok('.env 权限安全：0' + mode.toString(8));
      else warn('.env 建议 chmod 600，目前为 0' + mode.toString(8));
    } catch {}
  }

  const parsed = parseEnv(envFile);
  if (parsed.invalid.length) fail('.env 存在无法解析的行：' + parsed.invalid.join(', '));
  if (parsed.duplicates.length) warn('.env 有重复变量（后值覆盖前值）：' + [...new Set(parsed.duplicates)].join(', '));
  const env = { ...parsed.out, ...process.env };

  const token = String(env.TOKEN || '').trim();
  if (token.length > 128) warn('TOKEN 长度 ' + token.length + '，部分代理客户端/配置 UI 可能兼容性较差；推荐 32–64 个安全 ASCII 字符');
  else if (token.length >= 32) ok('TOKEN 已配置，长度 ' + token.length);
  else if (token.length >= 16) warn('TOKEN 可用但偏短，推荐 openssl rand -hex 24');
  else fail('TOKEN 未配置或长度不足 16');

  const explicitClientToken = String(env.CLIENT_TOKEN || '').trim();
  const clientToken = explicitClientToken || (token ? deriveClientToken(token) : '');
  if (!explicitClientToken) ok('CLIENT_TOKEN 未显式设置：将从 TOKEN 单向派生只读客户端令牌');
  else if (explicitClientToken === token) fail('CLIENT_TOKEN 不应与 TOKEN 相同；否则客户端令牌将拥有可复用的管理秘密');
  else if (explicitClientToken.length < 16) fail('CLIENT_TOKEN 过短，至少 16 字符');
  else ok('CLIENT_TOKEN 已独立配置，长度 ' + explicitClientToken.length);

  if ('CERT' in parsed.out || 'KEY' in parsed.out) warn('V11 宝塔版不需要 CERT/KEY；SSL 只在 Nginx 配置');

  const host = String(env.HOST || '127.0.0.1');
  const port = Number(env.PORT || 8080);
  if (!Number.isInteger(port) || port < 1 || port > 65535) fail('PORT 无效：' + env.PORT);
  if (host === '127.0.0.1' || host === '::1') ok('HOST=' + host + '（宝塔反代推荐）');
  else warn('HOST=' + host + ' 会让 Node 直接监听非回环地址，请确认防火墙');

  const trust = String(env.TRUST_PROXY || 'false').toLowerCase();
  if (trust === 'true' && (host === '127.0.0.1' || host === '::1')) ok('TRUST_PROXY=true，仅同机回环反代可伪造转发头');
  else if (trust === 'all') warn('TRUST_PROXY=all 风险较高，仅适合受控独立反代网络');
  else warn('宝塔同机 Nginx 推荐 TRUST_PROXY=true');

  const legacyAdminQuery = /^(?:1|true|yes|on)$/i.test(String(env.ALLOW_LEGACY_ADMIN_QUERY_TOKEN || 'false'));
  if (legacyAdminQuery) warn('ALLOW_LEGACY_ADMIN_QUERY_TOKEN=true：仅迁移旧 V9/V10 模块时临时使用，完成后应关闭');
  else ok('管理 TOKEN 默认禁止作为客户端 query token 使用');

  checkFrontendFiles();
  const leafletCacheDir = env.LEAFLET_CACHE_DIR || path.join(root,'vendor-cache','leaflet-1.9.4');
  try {
    fs.mkdirSync(leafletCacheDir,{recursive:true});
    fs.accessSync(leafletCacheDir,fs.constants.W_OK);
    ok('Leaflet 可选组件缓存目录可写：' + leafletCacheDir);
  } catch (e) { fail('Leaflet 可选组件缓存目录不可写：' + e.message); }
  const leafletCooldown = Number(env.LEAFLET_RETRY_COOLDOWN_MS || 60000);
  if (!Number.isFinite(leafletCooldown) || leafletCooldown < 0 || leafletCooldown > 1800000) fail('LEAFLET_RETRY_COOLDOWN_MS 无效');
  else ok('Leaflet 失败重试冷却=' + leafletCooldown + 'ms，地图故障不会反复阻塞外连');

  const upstreamCooldown = Number(env.UPSTREAM_RETRY_COOLDOWN_MS || 60000);
  if (!Number.isFinite(upstreamCooldown) || upstreamCooldown < 0 || upstreamCooldown > 1800000) fail('UPSTREAM_RETRY_COOLDOWN_MS 无效');
  else ok('上游核心失败重试冷却=' + upstreamCooldown + 'ms，公共脚本端点故障时不会反复外连');

  const upstreamRef = String(env.UPSTREAM_REF || '').trim();
  if (!upstreamRef) ok('UPSTREAM_REF 未设置：使用 V11 内置已审计提交锁定');
  else if (upstreamRef === 'main') warn('UPSTREAM_REF=main 会跟随上游变化，失去可复现性；稳定部署建议删除该变量');
  else if (/^[0-9a-f]{40}$/i.test(upstreamRef)) ok('UPSTREAM_REF 固定提交：' + upstreamRef.slice(0,12));
  else fail('UPSTREAM_REF 必须是 main 或 40 位 Git commit SHA');

  const clientScriptSource = String(env.CLIENT_SCRIPT_SOURCE || 'self').toLowerCase();
  if (clientScriptSource === 'self') ok('CLIENT_SCRIPT_SOURCE=self：手机客户端使用本机校验镜像');
  else if (clientScriptSource === 'github') warn('CLIENT_SCRIPT_SOURCE=github：手机客户端将直接依赖 GitHub Raw');
  else fail('CLIENT_SCRIPT_SOURCE 只允许 self 或 github');

  const upstreamSourceBase = env.UPSTREAM_SOURCE_BASE || 'https://raw.githubusercontent.com/mekos2772/ios-location-spoofer/b72d6f67efb2b457647ae05e3e20ae3f3f6f0262';
  validHttpUrl('UPSTREAM_SOURCE_BASE', upstreamSourceBase);

  for (const [name, def] of [
    ['UPSTREAM_CORE_BLOB_SHA','51fa0c2527c60ee4ba460bc898d1c28c0abfdb08'],
    ['UPSTREAM_QX_BLOB_SHA','4caa1f306836d4c8a32a426c9c0d1149936f41ad']
  ]) {
    const v = String(env[name] || def);
    if (/^[0-9a-f]{40}$/i.test(v)) ok(name + '=' + v.slice(0,12) + '…');
    else fail(name + ' 必须是 40 位 Git blob SHA');
  }

  const upstreamCacheDir = env.UPSTREAM_CACHE_DIR || path.join(root, 'upstream-cache');
  try {
    fs.mkdirSync(upstreamCacheDir, { recursive:true });
    fs.accessSync(upstreamCacheDir, fs.constants.W_OK);
    ok('上游脚本缓存目录可写：' + upstreamCacheDir);
  } catch (e) { fail('上游脚本缓存目录不可写：' + e.message); }

  if (clientScriptSource === 'self' && upstreamRef === 'main' && !env.UPSTREAM_CORE_BLOB_SHA) {
    warn('CLIENT_SCRIPT_SOURCE=self + UPSTREAM_REF=main 仍使用旧审计 blob SHA，更新上游后完整性校验会拒绝；生产建议锁定 commit');
  }

  validHttpUrl('PUBLIC_ORIGIN', env.PUBLIC_ORIGIN);
  validHttpUrl('IP2LOCATION_BASE_URL', env.IP2LOCATION_BASE_URL || 'https://api.ip2location.io/');
  validHttpUrl('NOMINATIM_BASE_URL', env.NOMINATIM_BASE_URL || 'https://nominatim.openstreetmap.org');
  validHttpUrl('ELEVATION_BASE_URL', env.ELEVATION_BASE_URL || 'https://api.open-meteo.com/v1/elevation');

  const dataFile = env.DATA_FILE || path.join(root, 'loc.json');
  const backupFile = env.BACKUP_FILE || path.join(path.dirname(dataFile), 'loc.backup.json');
  const historyDir = env.HISTORY_DIR || path.join(path.dirname(dataFile), 'history');
  try {
    fs.mkdirSync(path.dirname(dataFile), { recursive:true });
    fs.accessSync(path.dirname(dataFile), fs.constants.W_OK);
    ok('数据目录可写：' + path.dirname(dataFile));
  } catch (e) { fail('数据目录不可写：' + e.message); }

  if (fs.existsSync(dataFile)) checkJsonFile('loc.json', dataFile); else ok('loc.json 尚未创建（首次运行正常）');
  if (fs.existsSync(backupFile)) checkJsonFile('loc.backup.json', backupFile);
  if (fs.existsSync(historyDir)) {
    const count = fs.readdirSync(historyDir).filter(n => /^loc-.*\.json$/.test(n)).length;
    ok('历史目录存在，共 ' + count + ' 个版本');
  }

  if (Number.isInteger(port) && port > 0 && port <= 65535) {
    const ps = await portState(host, port);
    if (ps === 'free') ok('端口 ' + port + ' 当前空闲，可启动服务');
    else if (ps === 'in-use') {
      const health = await requestHealth(host, port);
      if (health && health.ok && health.data && String(health.data.version || '').startsWith('11.')) {
        ok('端口 ' + port + ' 已被 Location Picker V11 正常监听，/health 正常');
        const localHealth = health.data.frontendAssets && health.data.frontendAssets.local;
        if (localHealth && localHealth.ready) ok('运行中的本地后台资源 app.js/watchdog/app.css 完整');
        else fail('运行中的 /health 报告本地后台资源不完整');
        for (const asset of ['/assets/app.css','/assets/watchdog.js','/assets/app.js']) {
          const ar = await requestPath(host, port, asset);
          if (ar && ar.status === 200 && /must-revalidate/.test(String(ar.headers['cache-control']||''))) ok(asset + ' HTTP 200 且启用 ETag 重新验证');
          else fail(asset + ' 前端资源检查失败，状态=' + (ar && ar.status));
        }
        const clientLoc = await requestPath(host, port, '/loc.json?token=' + encodeURIComponent(clientToken));
        if (clientLoc && clientLoc.status === 200) ok('CLIENT_TOKEN 可只读访问 /loc.json');
        else fail('CLIENT_TOKEN 无法读取 /loc.json，状态=' + (clientLoc && clientLoc.status));
        const profile = await requestPath(host, port, '/profiles/shadowrocket.sgmodule?token=' + encodeURIComponent(clientToken));
        if (profile && profile.status === 200 && /\[Script\]/.test(profile.text)) ok('Shadowrocket 模块 URL 可直接订阅');
        else fail('Shadowrocket 模块 URL 订阅检查失败，状态=' + (profile && profile.status));
        const adminByClientQuery = await requestPath(host, port, '/status?token=' + encodeURIComponent(clientToken));
        if (adminByClientQuery && adminByClientQuery.status === 401) ok('CLIENT_TOKEN 查询参数不能访问管理接口');
        else warn('CLIENT_TOKEN 管理接口隔离检查异常，/status 状态=' + (adminByClientQuery && adminByClientQuery.status));
        const adminQuery = await requestPath(host, port, '/loc.json?token=' + encodeURIComponent(token));
        const expectedAdminQueryStatus = legacyAdminQuery ? 200 : 403;
        if (adminQuery && adminQuery.status === expectedAdminQueryStatus) ok('管理 TOKEN query 隔离符合 ALLOW_LEGACY_ADMIN_QUERY_TOKEN=' + legacyAdminQuery);
        else fail('管理 TOKEN query 隔离异常，/loc.json 状态=' + (adminQuery && adminQuery.status) + '，期望 ' + expectedAdminQueryStatus);
      } else warn('端口 ' + port + ' 已被占用，但未确认是当前 V11 服务');
    } else fail('端口检查失败：' + ps);
  }

  inspectBaota(port);
  if (process.argv.includes('--network')) await networkChecks(env);

  console.log('\n结果：' + (failed ? '存在必须修复的问题' : (warned ? '核心检查通过，但有警告' : '全部检查通过')));
  if (failed) process.exitCode = 1;
}

main().catch(e => { console.error(e.stack || e); process.exitCode = 1; });
