// 定位选点服务 —— Node 自托管增强版 v11
// 核心目标：IP2Location.io 作为“快捷定位增强”，而不是单点依赖。
// 即使 IP2Location API Key、额度、网络或服务端异常，原始地图搜索 / 点图 / 拖图钉 / 手动经纬度 / 保存定位仍始终可用。
// 仅使用 Node.js 内置模块，无 npm 运行时依赖。
// v11：在 V10 基础上重构前端启动链路、静态资源与可选地图依赖，并继续保持上游核心兼容锁定：
/// - 不改写上游 Apple WLOC/protobuf 核心算法，动态客户端配置固定到已审计提交；
/// - 对 /loc.json 做上游 normalizeConfig 契约检查，并明确平台远程配置能力边界；
/// - 宝塔/Nginx 非标准 HTTPS 端口反代兼容与可信代理识别；
/// - GET 只读、POST 才允许写入，避免“带 token 的链接”误触发状态修改；
/// - 多标签页乐观并发控制（revision），避免旧页面覆盖新配置；
/// - loc.json 损坏自动隔离并尝试从 backup/history 恢复；
/// - IP/登录限流改为按客户端+有界缓存，避免单一来源拖垮全局；
/// - Nominatim 请求严格串行，满足公共服务 1 req/s 限制并防止并发穿透；
/// - 地图/CDN失效时仍可纯手工经纬度保存；
/// - 前端反向地址/海拔请求加防抖与时序保护，避免旧响应覆盖新位置；
/// - 统一异常兜底与更完整的 doctor/selfcheck。
//
// 仍保持零 npm 运行时依赖。

const http = require("http");
const https = require("https");
const crypto = require("crypto");
const fs = require("fs");
const path = require("path");
const net = require("net");

// ---------- .env 自动加载（零依赖） ----------
// 默认读取 server.js 同目录的 .env。若系统已显式设置同名环境变量，则系统环境变量优先，
// 避免宝塔 / systemd / Docker 已注入的值被文件意外覆盖。
// 可选：通过系统环境变量 ENV_FILE=/absolute/path/custom.env 指定其它配置文件。
function loadDotEnv() {
  const envFile = process.env.ENV_FILE
    ? path.resolve(String(process.env.ENV_FILE))
    : path.join(__dirname, ".env");

  if (!fs.existsSync(envFile)) {
    return { loaded: false, file: envFile, method: "none" };
  }

  try {
    // Node 20.12+/22：优先使用官方 dotenv 解析器。
    if (typeof process.loadEnvFile === "function") {
      process.loadEnvFile(envFile);
      try {
        if (process.platform !== "win32") fs.chmodSync(envFile, 0o600);
      } catch {}
      return { loaded: true, file: envFile, method: "node" };
    }

    // 兼容较早 Node 20：实现一个最小 .env 解析器，不引入 dotenv npm 包。
    const text = fs.readFileSync(envFile, "utf8").replace(/^\uFEFF/, "");
    const lines = text.split(/\r?\n/);
    for (let line of lines) {
      line = line.trim();
      if (!line || line.startsWith("#")) continue;
      if (line.startsWith("export ")) line = line.slice(7).trim();
      const eq = line.indexOf("=");
      if (eq <= 0) continue;
      const key = line.slice(0, eq).trim();
      if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(key)) continue;
      if (Object.prototype.hasOwnProperty.call(process.env, key)) continue;

      let value = line.slice(eq + 1).trim();
      if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
        const quote = value[0];
        value = value.slice(1, -1);
        if (quote === '"') {
          value = value
            .replace(/\\n/g, "\n")
            .replace(/\\r/g, "\r")
            .replace(/\\t/g, "\t")
            .replace(/\\"/g, '"')
            .replace(/\\\\/g, "\\");
        }
      } else {
        // 未加引号时，空白后的 # 视为注释；URL/Token 中的 # 建议使用引号。
        value = value.replace(/\s+#.*$/, "").trim();
      }
      process.env[key] = value;
    }
    try {
      if (process.platform !== "win32") fs.chmodSync(envFile, 0o600);
    } catch {}
    return { loaded: true, file: envFile, method: "fallback" };
  } catch (e) {
    console.error("启动失败：无法读取 .env：" + envFile + " | " + e.message);
    process.exit(1);
  }
}

const ENV_STATE = loadDotEnv();

function intEnv(name, fallback, min, max) {
  const n = Number(process.env[name]);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, Math.round(n)));
}

const APP_VERSION = "11.0.0";
const PORT = intEnv("PORT", 8080, 1, 65535);
const HOST = String(process.env.HOST || "127.0.0.1").trim() || "127.0.0.1";
const TOKEN = String(process.env.TOKEN || "").trim();
const TOKEN_PLACEHOLDERS = new Set([
  "replace-with-a-long-random-token",
  "your-token-here",
  "change-me",
  "changeme"
]);
if (!TOKEN || TOKEN_PLACEHOLDERS.has(TOKEN.toLowerCase())) {
  const envHint = path.join(__dirname, ".env");
  console.error(`启动失败：TOKEN 未填写。
现在无需 export/source 环境变量，只需要编辑：
  ${envHint}
至少填写：
  TOKEN=你的随机TOKEN
可生成：openssl rand -hex 24
保存后直接运行：node server.js`);
  process.exit(1);
}
if (TOKEN.length < 16) {
  console.warn("安全提示：当前 TOKEN 少于 16 个字符，建议使用 `openssl rand -hex 24` 生成更强 TOKEN。");
}

// 客户端读取令牌与管理 TOKEN 分权：
// - TOKEN：后台登录、写入、诊断等管理权限；
// - CLIENT_TOKEN：仅用于手机客户端读取 loc.json 与安装只读模块 URL。
// 未显式设置 CLIENT_TOKEN 时，从 TOKEN 单向派生稳定的 32 位十六进制令牌，
// 避免把管理 TOKEN 暴露在模块 URL / loc.json 查询参数 / 代理访问日志中。
const CLIENT_TOKEN_EXPLICIT = String(process.env.CLIENT_TOKEN || "").trim();
const CLIENT_TOKEN = CLIENT_TOKEN_EXPLICIT || crypto.createHmac("sha256", TOKEN)
  .update("ios-location-picker-client-v10", "utf8")
  .digest("hex")
  .slice(0, 32);
if (CLIENT_TOKEN_EXPLICIT && CLIENT_TOKEN_EXPLICIT.length < 16) {
  console.warn("安全提示：CLIENT_TOKEN 少于 16 个字符，建议删除该变量使用自动派生值，或设置 32–64 个安全 ASCII 字符。");
}
if (CLIENT_TOKEN_EXPLICIT && CLIENT_TOKEN_EXPLICIT === TOKEN) {
  console.error("启动失败：CLIENT_TOKEN 不能与管理 TOKEN 相同，否则手机端泄漏的只读令牌可被复用为管理 Bearer Token。删除 CLIENT_TOKEN 让 V11 自动派生，或设置另一个独立随机值。");
  process.exit(1);
}
// V11 默认不再接受管理 TOKEN 出现在只读 query string 中。旧版迁移确有需要时可临时开启，
// 完成客户端重新订阅后应立即关闭，避免管理秘密长期存在于模块 URL。
const ALLOW_LEGACY_ADMIN_QUERY_TOKEN = /^(1|true|yes|on)$/i.test(process.env.ALLOW_LEGACY_ADMIN_QUERY_TOKEN || "false");

const DATA_FILE = process.env.DATA_FILE || path.join(__dirname, "loc.json");
const META_FILE = process.env.META_FILE || path.join(path.dirname(DATA_FILE), "loc.meta.json");
const BACKUP_FILE = process.env.BACKUP_FILE || path.join(path.dirname(DATA_FILE), "loc.backup.json");
const HISTORY_DIR = process.env.HISTORY_DIR || path.join(path.dirname(DATA_FILE), "history");
const HISTORY_MAX = intEnv("HISTORY_MAX", 20, 0, 200);
const CORS_ORIGIN = String(process.env.CORS_ORIGIN || "").trim();
// TRUST_PROXY:
//   false     = 完全不信任 X-Forwarded-*
//   true      = 仅当直接上游来自本机回环地址时信任（宝塔/Nginx 同机反代推荐）
//   all       = 信任任意直接上游提供的 X-Forwarded-*（仅在你明确控制网络边界时使用）
const TRUST_PROXY_MODE_RAW = String(process.env.TRUST_PROXY || "false").trim().toLowerCase();
const TRUST_PROXY = /^(1|true|yes|on|loopback|all)$/i.test(TRUST_PROXY_MODE_RAW);
const TRUST_PROXY_ALL = TRUST_PROXY_MODE_RAW === "all";
const PUBLIC_ORIGIN = String(process.env.PUBLIC_ORIGIN || "").trim().replace(/\/+$/, "");
const COOKIE_SECURE = String(process.env.COOKIE_SECURE || "auto").trim().toLowerCase();
const SESSION_TTL_HOURS = intEnv("SESSION_TTL_HOURS", 12, 1, 168);
const SESSION_COOKIE = "lp_session";
const IP2LOCATION_API_KEY = process.env.IP2LOCATION_API_KEY || "";
const IP2LOCATION_BASE_URL = process.env.IP2LOCATION_BASE_URL || "https://api.ip2location.io/";
const IP2LOCATION_TIMEOUT_MS = intEnv("IP2LOCATION_TIMEOUT_MS", 6500, 1000, 30000);
const IP2LOCATION_CACHE_TTL_MS = intEnv("IP2LOCATION_CACHE_TTL_MS", 6 * 3600 * 1000, 0, 7 * 24 * 3600 * 1000);
const IP2LOCATION_CACHE_MAX = intEnv("IP2LOCATION_CACHE_MAX", 512, 8, 5000);
const IP_LOOKUP_RATE_LIMIT = intEnv("IP_LOOKUP_RATE_LIMIT", 60, 1, 10000); // 每客户端每分钟
const LOGIN_RATE_LIMIT = intEnv("LOGIN_RATE_LIMIT", 10, 3, 100);
const RATE_LIMIT_CLIENTS_MAX = intEnv("RATE_LIMIT_CLIENTS_MAX", 1024, 64, 10000);
const IP_LOOKUP_ALLOW_SPECIAL = /^(1|true|yes|on)$/i.test(process.env.IP_LOOKUP_ALLOW_SPECIAL || "false");
const IP2LOCATION_FAILURE_THRESHOLD = intEnv("IP2LOCATION_FAILURE_THRESHOLD", 3, 1, 100);
const IP2LOCATION_COOLDOWN_MS = intEnv("IP2LOCATION_COOLDOWN_MS", 60000, 5000, 30 * 60 * 1000);
const NOMINATIM_BASE_URL = String(process.env.NOMINATIM_BASE_URL || "https://nominatim.openstreetmap.org").replace(/\/+$/, "");
const ELEVATION_BASE_URL = String(process.env.ELEVATION_BASE_URL || "https://api.open-meteo.com/v1/elevation");
const GEO_CACHE_TTL_MS = intEnv("GEO_CACHE_TTL_MS", 15 * 60 * 1000, 0, 24 * 3600 * 1000);
const GEO_CACHE_MAX = intEnv("GEO_CACHE_MAX", 256, 8, 2000);
const GEO_RATE_LIMIT = intEnv("GEO_RATE_LIMIT", 60, 1, 1000);
const AUTO_REVERSE_GEOCODE = /^(1|true|yes|on)$/i.test(process.env.AUTO_REVERSE_GEOCODE || "true");
const USER_AGENT = String(process.env.USER_AGENT || "ios-location-spoofer-location-picker/11.0 (+https://github.com/mekos2772/ios-location-spoofer)").slice(0, 200);

// ---------- V11 前端与可选地图依赖 ----------
// 管理后台本体（HTML/CSS/app.js/watchdog.js）全部由本机同源提供。
// Leaflet 仅是可选增强：浏览器只请求本机 /assets/vendor/leaflet/*，服务器后台按需缓存并校验固定 SHA-384。
// 即使两个 CDN 都不可用，后台基础配置/手工经纬度保存也会先启动，不再被第三方脚本阻塞。
const PUBLIC_DIR = path.join(__dirname, "public");
function computeFrontendBuildId() {
  // 版本号之外再绑定实际静态文件内容。即使只热修 app.js/watchdog.css 而未改 APP_VERSION，
  // 新 HTML 也会生成全新的资源 URL，避免中间缓存/浏览器持有旧前端。
  try {
    const h = crypto.createHash("sha256");
    for (const name of ["app.css","watchdog.js","app.js"]) {
      const buf = fs.readFileSync(path.join(PUBLIC_DIR, name));
      h.update(name, "utf8"); h.update("\0", "binary"); h.update(buf);
    }
    return APP_VERSION + "-" + h.digest("hex").slice(0,16);
  } catch {
    return APP_VERSION + "-assets-missing";
  }
}
const FRONTEND_BUILD_ID = computeFrontendBuildId();
const LEAFLET_VERSION = "1.9.4";
const LEAFLET_PRELOAD = /^(1|true|yes|on)$/i.test(process.env.LEAFLET_PRELOAD || "true");
const LEAFLET_FETCH_TIMEOUT_MS = intEnv("LEAFLET_FETCH_TIMEOUT_MS", 3500, 1000, 15000);
const LEAFLET_FETCH_MAX_BYTES = intEnv("LEAFLET_FETCH_MAX_BYTES", 1024 * 1024, 64 * 1024, 4 * 1024 * 1024);
// 当所有 Leaflet 源都不可达时，短时间内直接返回降级结果，避免每次刷新页面都重复阻塞服务端外连。
const LEAFLET_RETRY_COOLDOWN_MS = intEnv("LEAFLET_RETRY_COOLDOWN_MS", 60000, 0, 30 * 60 * 1000);
const LEAFLET_CACHE_DIR = process.env.LEAFLET_CACHE_DIR || path.join(__dirname, "vendor-cache", "leaflet-" + LEAFLET_VERSION);
const LEAFLET_SOURCE_BASES = String(process.env.LEAFLET_SOURCE_BASES ||
  "https://unpkg.com/leaflet@1.9.4/dist,https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist")
  .split(",").map(v => v.trim().replace(/\/+$/, "")).filter(Boolean).slice(0, 4);
const LEAFLET_ASSETS = {
  js: { id:"js", filename:"leaflet.js", contentType:"application/javascript; charset=utf-8", expectedSha384:String(process.env.LEAFLET_JS_SHA384 || "cxOPjt7s7Iz04uaHJceBmS+qpjv2JkIHNVcuOrM+YHwZOmJGBXI00mdUXEq65HTH").trim() },
  css:{ id:"css", filename:"leaflet.css", contentType:"text/css; charset=utf-8", expectedSha384:String(process.env.LEAFLET_CSS_SHA384 || "sHL9NAb7lN7rfvG5lfHpm643Xkcjzp4jFvuavGOndn6pjVqS6ny56CAt3nsEVT4H").trim() }
};
const leafletAssetState = {
  js:{ ready:false, source:"", lastSuccessAt:0, lastAttemptAt:0, lastError:"" },
  css:{ ready:false, source:"", lastSuccessAt:0, lastAttemptAt:0, lastError:"" }
};
const leafletAssetInFlight = new Map();

// 与上游原项目做兼容性锁定：默认固定到本次已审计的 main 提交，避免上游未来改动静默改变客户端行为。
const UPSTREAM_REPO = "mekos2772/ios-location-spoofer";
const UPSTREAM_AUDITED_COMMIT = "b72d6f67efb2b457647ae05e3e20ae3f3f6f0262";
const UPSTREAM_REF_RAW = String(process.env.UPSTREAM_REF || UPSTREAM_AUDITED_COMMIT).trim();
const UPSTREAM_REF = /^(?:main|[0-9a-f]{40})$/i.test(UPSTREAM_REF_RAW) ? UPSTREAM_REF_RAW : UPSTREAM_AUDITED_COMMIT;

// V11 默认把已审计上游脚本镜像到自己的服务器，再让 iOS 代理客户端从同一域名拉取。
// 手机端因此不再强依赖 raw.githubusercontent.com；服务端首次拉取后会校验 Git blob SHA 并落盘缓存。
const CLIENT_SCRIPT_SOURCE_RAW = String(process.env.CLIENT_SCRIPT_SOURCE || "self").trim().toLowerCase();
const CLIENT_SCRIPT_SOURCE = CLIENT_SCRIPT_SOURCE_RAW === "github" ? "github" : "self";
const UPSTREAM_SOURCE_BASE = String(
  process.env.UPSTREAM_SOURCE_BASE ||
  ("https://raw.githubusercontent.com/" + UPSTREAM_REPO + "/" + UPSTREAM_REF)
).trim().replace(/\/+$/, "");
const UPSTREAM_CORE_SCRIPT_SOURCE = UPSTREAM_SOURCE_BASE + "/location-spoofer.js";
const UPSTREAM_QX_SCRIPT_SOURCE = UPSTREAM_SOURCE_BASE + "/location-spoofer-qx.js";
const UPSTREAM_CACHE_DIR = process.env.UPSTREAM_CACHE_DIR || path.join(__dirname, "upstream-cache");
const UPSTREAM_FETCH_TIMEOUT_MS = intEnv("UPSTREAM_FETCH_TIMEOUT_MS", 8000, 1000, 30000);
const UPSTREAM_FETCH_MAX_BYTES = intEnv("UPSTREAM_FETCH_MAX_BYTES", 2 * 1024 * 1024, 64 * 1024, 8 * 1024 * 1024);
// 公共 /client/*.js 在缓存为空且 GitHub 故障时，不能让任意刷新反复触发外连。
// 普通客户端请求进入冷却；管理员显式 force preload 仍可立即重试。
const UPSTREAM_RETRY_COOLDOWN_MS = intEnv("UPSTREAM_RETRY_COOLDOWN_MS", 60000, 0, 30 * 60 * 1000);
const UPSTREAM_PRELOAD = /^(1|true|yes|on)$/i.test(process.env.UPSTREAM_PRELOAD || "true");

// GitHub Contents API 对本次审计提交返回的 blob SHA / size。
// 高级用户可显式覆盖这些值来审计自己的 fork；默认值对应上游审计版本。
const UPSTREAM_CORE_BLOB_SHA = String(process.env.UPSTREAM_CORE_BLOB_SHA || "51fa0c2527c60ee4ba460bc898d1c28c0abfdb08").trim().toLowerCase();
const UPSTREAM_QX_BLOB_SHA = String(process.env.UPSTREAM_QX_BLOB_SHA || "4caa1f306836d4c8a32a426c9c0d1149936f41ad").trim().toLowerCase();
const UPSTREAM_CORE_SIZE = intEnv("UPSTREAM_CORE_SIZE", 62368, 1, 8 * 1024 * 1024);
const UPSTREAM_QX_SIZE = intEnv("UPSTREAM_QX_SIZE", 19647, 1, 8 * 1024 * 1024);

const UPSTREAM_ASSETS = {
  core: {
    id: "core",
    filename: "location-spoofer.js",
    sourceUrl: UPSTREAM_CORE_SCRIPT_SOURCE,
    expectedBlobSha: UPSTREAM_CORE_BLOB_SHA,
    expectedSize: UPSTREAM_CORE_SIZE
  },
  qx: {
    id: "qx",
    filename: "location-spoofer-qx.js",
    sourceUrl: UPSTREAM_QX_SCRIPT_SOURCE,
    expectedBlobSha: UPSTREAM_QX_BLOB_SHA,
    expectedSize: UPSTREAM_QX_SIZE
  }
};
const upstreamAssetState = {
  core: { ready:false, source:"", lastSuccessAt:0, lastAttemptAt:0, lastError:"" },
  qx: { ready:false, source:"", lastSuccessAt:0, lastAttemptAt:0, lastError:"" }
};
const upstreamAssetInFlight = new Map();

function validateServiceUrl(name, value) {
  let u;
  try { u = new URL(value); }
  catch { throw new Error(name + " 不是有效 URL: " + value); }
  if (u.protocol !== "https:" && u.protocol !== "http:") {
    throw new Error(name + " 只允许 http/https: " + value);
  }
  if (u.username || u.password) throw new Error(name + " 不允许在 URL 中包含用户名/密码");
  return u.toString();
}

try {
  validateServiceUrl("IP2LOCATION_BASE_URL", IP2LOCATION_BASE_URL);
  validateServiceUrl("NOMINATIM_BASE_URL", NOMINATIM_BASE_URL);
  validateServiceUrl("ELEVATION_BASE_URL", ELEVATION_BASE_URL);
  validateServiceUrl("UPSTREAM_SOURCE_BASE", UPSTREAM_SOURCE_BASE);
  if (!LEAFLET_SOURCE_BASES.length) throw new Error("LEAFLET_SOURCE_BASES 至少需要一个 http/https 地址");
  for (const base of LEAFLET_SOURCE_BASES) validateServiceUrl("LEAFLET_SOURCE_BASES", base + "/leaflet.js");
  for (const spec of Object.values(LEAFLET_ASSETS)) {
    // SHA-384 的 Base64 输出固定为 64 个字符（384 bit = 48 bytes = 64 Base64 chars，无 padding）。
    if (!/^[A-Za-z0-9+/]{64}$/.test(spec.expectedSha384)) {
      throw new Error("Leaflet " + spec.id + " SHA-384 配置格式错误");
    }
  }
  if (PUBLIC_ORIGIN) {
    const po = new URL(PUBLIC_ORIGIN);
    if (po.protocol !== "https:" && po.protocol !== "http:") throw new Error("PUBLIC_ORIGIN 只允许 http/https");
  }
} catch (e) {
  console.error("启动失败：.env URL 配置错误：" + e.message);
  process.exit(1);
}

const DEFAULT = {
  enabled: true,
  latitude: 37.3349,
  longitude: -122.00902,
  address: "",
  horizontalAccuracy: 39,
  verticalAccuracy: 1000,
  altitude: 530,
  failOpen: true,
  debug: false
};

const stats = {
  startedAt: Date.now(), upstreamCalls: 0, cacheHits: 0, cacheMisses: 0,
  rateLimited: 0, lookupErrors: 0, manualSaves: 0, ipFallbacks: 0,
  geocodeCalls: 0, geocodeCacheHits: 0, geocodeErrors: 0, elevationCalls: 0,
  loginsOk: 0, loginsFailed: 0, rollbacks: 0, originBlocked: 0,
  writeOps: 0, historyWrites: 0, historyRestores: 0,
  configRecoveries: 0, revisionConflicts: 0, unexpectedErrors: 0,
  staleDerivedResponses: 0, upstreamAssetFetches: 0, upstreamAssetCacheHits: 0,
  upstreamAssetFailures: 0
};
const configRecoveryStatus = {
  degraded: false,
  lastCorruptFile: "",
  lastError: "",
  recoveredFrom: ""
};
const ipUpstream = {
  consecutiveFailures: 0,
  circuitOpenUntil: 0,
  lastSuccessAt: 0,
  lastFailureAt: 0,
  lastError: ""
};
const lookupCache = new Map();
const inFlight = new Map();
const geoCache = new Map();
const loginAttempts = new Map();
const ipRateClients = new Map();
let geoRateWindowStart = Date.now();
let geoRateWindowCount = 0;
let lastNominatimCallAt = 0;
let nominatimQueue = Promise.resolve();
let writeQueue = Promise.resolve();

function withWriteLock(fn) {
  const run = writeQueue.then(() => fn(), () => fn());
  writeQueue = run.catch(() => {});
  return run;
}

function safeEqual(a, b) {
  // 先哈希成固定长度，再做 timingSafeEqual；连输入长度差异也不通过早退暴露。
  const ah = crypto.createHash("sha256").update(String(a)).digest();
  const bh = crypto.createHash("sha256").update(String(b)).digest();
  return crypto.timingSafeEqual(ah, bh);
}

function parseBool(value, fallback) {
  if (value === true || value === false) return value;
  if (typeof value === "number") return value !== 0;
  if (typeof value === "string") {
    const v = value.trim().toLowerCase();
    if (["1", "true", "yes", "on"].includes(v)) return true;
    if (["0", "false", "no", "off"].includes(v)) return false;
  }
  return fallback;
}

function finiteNumber(value, fallback) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

function clampInt(value, fallback, min, max) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.round(Math.min(max, Math.max(min, n)));
}

function badField(name, message) {
  const e = new Error(message || (name + " 无效"));
  e.statusCode = 400;
  e.code = "INVALID_FIELD";
  e.field = name;
  return e;
}

function optionalNumberField(obj, key, min, max, integer) {
  if (!obj || !Object.prototype.hasOwnProperty.call(obj, key)) return undefined;
  const raw = obj[key];
  if (raw === null || raw === "") return undefined;
  const n = Number(raw);
  if (!Number.isFinite(n)) throw badField(key, key + " 必须是有效数字");
  if (n < min || n > max) throw badField(key, key + " 超出允许范围 " + min + ".." + max);
  return integer ? Math.round(n) : n;
}

function optionalBooleanField(obj, key) {
  if (!obj || !Object.prototype.hasOwnProperty.call(obj, key)) return undefined;
  const raw = obj[key];
  if (raw === true || raw === false) return raw;
  if (typeof raw === "number" && (raw === 0 || raw === 1)) return raw === 1;
  if (typeof raw === "string") {
    const v = raw.trim().toLowerCase();
    if (["1","true","yes","on"].includes(v)) return true;
    if (["0","false","no","off"].includes(v)) return false;
  }
  throw badField(key, key + " 必须是 true/false");
}

function validateStoredLocInput(input) {
  if (!input || typeof input !== "object" || Array.isArray(input)) {
    throw badField("loc.json", "loc.json 根对象必须是 JSON object");
  }
  // 兼容旧版：允许字段缺失、数字字符串和常见布尔字符串；但字段一旦存在就不能悄悄
  // 把非法值回退到 Apple Park。这样手工改坏 loc.json 时会进入 backup/history 恢复路径。
  if (Object.prototype.hasOwnProperty.call(input, "latitude")) {
    const n = Number(input.latitude);
    if (!Number.isFinite(n) || n < -90 || n > 90) throw badField("latitude", "loc.json latitude 无效");
  }
  if (Object.prototype.hasOwnProperty.call(input, "longitude")) {
    const n = Number(input.longitude);
    if (!Number.isFinite(n) || n < -180 || n > 180) throw badField("longitude", "loc.json longitude 无效");
  }
  for (const [key,min,max] of [
    ["horizontalAccuracy",0,1000000],
    ["verticalAccuracy",0,1000000],
    ["altitude",-12000,100000]
  ]) {
    if (!Object.prototype.hasOwnProperty.call(input, key)) continue;
    if (input[key] === null || input[key] === "") continue;
    const n = Number(input[key]);
    if (!Number.isFinite(n) || n < min || n > max) throw badField(key, "loc.json " + key + " 无效");
  }
  for (const key of ["enabled","failOpen","debug"]) {
    if (!Object.prototype.hasOwnProperty.call(input, key)) continue;
    optionalBooleanField(input, key);
  }
  return input;
}

function normalizeLoc(input) {
  const x = input && typeof input === "object" ? input : {};
  const out = { ...DEFAULT };
  out.enabled = parseBool(x.enabled, DEFAULT.enabled);
  out.latitude = finiteNumber(x.latitude, DEFAULT.latitude);
  out.longitude = finiteNumber(x.longitude, DEFAULT.longitude);
  if (out.latitude < -90 || out.latitude > 90) out.latitude = DEFAULT.latitude;
  if (out.longitude < -180 || out.longitude > 180) out.longitude = DEFAULT.longitude;
  out.address = String(x.address == null ? DEFAULT.address : x.address).trim().slice(0, 512);
  out.horizontalAccuracy = clampInt(x.horizontalAccuracy, DEFAULT.horizontalAccuracy, 0, 1000000);
  out.verticalAccuracy = clampInt(x.verticalAccuracy, DEFAULT.verticalAccuracy, 0, 1000000);
  out.altitude = clampInt(x.altitude, DEFAULT.altitude, -12000, 100000);
  out.failOpen = parseBool(x.failOpen, DEFAULT.failOpen);
  out.debug = parseBool(x.debug, DEFAULT.debug);
  return out;
}

function revisionOfLoc(loc) {
  const normalized = normalizeLoc(loc);
  return crypto.createHash("sha256").update(JSON.stringify(normalized)).digest("hex").slice(0, 16);
}

function readLocState() {
  if (!fs.existsSync(DATA_FILE)) {
    const loc = { ...DEFAULT };
    return { exists:false, valid:true, loc, revision:revisionOfLoc(loc), source:"default" };
  }
  try {
    const parsed = JSON.parse(fs.readFileSync(DATA_FILE, "utf8"));
    validateStoredLocInput(parsed);
    const loc = normalizeLoc(parsed);
    return { exists:true, valid:true, loc, revision:revisionOfLoc(loc), source:"data" };
  } catch (error) {
    return { exists:true, valid:false, loc:null, revision:null, source:"data", error:String(error && error.message || error) };
  }
}

function readValidLocFile(file) {
  try {
    if (!file || !fs.existsSync(file)) return null;
    const parsed = JSON.parse(fs.readFileSync(file, "utf8"));
    validateStoredLocInput(parsed);
    return normalizeLoc(parsed);
  } catch {
    return null;
  }
}

function recoverCorruptLoc() {
  const state = readLocState();
  if (state.valid) return state;

  // 先隔离损坏文件，避免后续误覆盖而丢失排查证据。
  const stamp = new Date().toISOString().replace(/[-:]/g, "");
  const quarantine = path.join(path.dirname(DATA_FILE), "loc.corrupt-" + stamp + "-" + crypto.randomBytes(3).toString("hex") + ".json");
  try {
    fs.renameSync(DATA_FILE, quarantine);
  } catch {
    try { fs.copyFileSync(DATA_FILE, quarantine); fs.unlinkSync(DATA_FILE); } catch {}
  }
  configRecoveryStatus.lastCorruptFile = path.basename(quarantine);
  configRecoveryStatus.lastError = state.error || "";

  let recovered = readValidLocFile(BACKUP_FILE);
  let source = "backup";
  if (!recovered) {
    for (const name of historyFiles()) {
      recovered = readValidLocFile(path.join(HISTORY_DIR, name));
      if (recovered) { source = "history:" + name; break; }
    }
  }

  if (recovered) {
    atomicWriteJson(DATA_FILE, recovered);
    stats.configRecoveries += 1;
    configRecoveryStatus.degraded = false;
    configRecoveryStatus.recoveredFrom = source;
    writeMeta({
      source:"auto-recovery",
      recoveredFrom:source,
      quarantined:path.basename(quarantine),
      appliedAt:new Date().toISOString(),
      parseError:state.error
    });
    console.error("config recovery: loc.json 损坏，已从 " + source + " 恢复；损坏副本：" + quarantine);
    return { exists:true, valid:true, loc:recovered, revision:revisionOfLoc(recovered), source:"recovered:" + source };
  }

  // 无任何可恢复版本时不覆盖损坏文件。返回默认值仅用于服务继续启动/允许用户手动修复，
  // 并在状态接口明确标记 degraded，避免把“默认 Apple Park”误认为真实已保存配置。
  console.error("config warning: loc.json 无法解析且无 backup/history 可恢复；损坏文件已隔离，将以默认值进入降级模式，等待手动保存。");
  configRecoveryStatus.degraded = true;
  configRecoveryStatus.recoveredFrom = "";
  const loc = { ...DEFAULT };
  return { exists:false, valid:false, loc, revision:revisionOfLoc(loc), source:"degraded-default", error:state.error };
}

function readLoc() {
  const state = readLocState();
  if (state.valid) return state.loc;
  return recoverCorruptLoc().loc;
}

function currentRevision() {
  const state = readLocState();
  if (state.valid) return state.revision;
  return revisionOfLoc(recoverCorruptLoc().loc);
}

function assertRevision(expected, currentLoc) {
  const wanted = String(expected || "").trim();
  if (!wanted) return;
  const actual = revisionOfLoc(currentLoc);
  if (!safeEqual(wanted, actual)) {
    stats.revisionConflicts += 1;
    const e = new Error("配置已被另一个页面更新，请刷新后重试");
    e.statusCode = 409;
    e.code = "REVISION_CONFLICT";
    e.expectedRevision = wanted;
    e.currentRevision = actual;
    throw e;
  }
}

function ensureParent(file) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
}

function atomicWriteJson(file, obj) {
  ensureParent(file);
  const tmp = file + ".tmp-" + process.pid + "-" + crypto.randomBytes(4).toString("hex");
  let fd = null;
  try {
    fd = fs.openSync(tmp, "wx", 0o600);
    fs.writeFileSync(fd, JSON.stringify(obj, null, 2) + "\n", "utf8");
    try { fs.fsyncSync(fd); } catch {}
    fs.closeSync(fd); fd = null;
    fs.renameSync(tmp, file);
    try { if (process.platform !== "win32") fs.chmodSync(file, 0o600); } catch {}
    // Linux/Unix 上同步父目录，降低 rename 后突然掉电导致目录项未落盘的概率。
    try {
      if (process.platform !== "win32") {
        const dfd = fs.openSync(path.dirname(file), "r");
        try { fs.fsyncSync(dfd); } finally { fs.closeSync(dfd); }
      }
    } catch {}
  } catch (e) {
    if (fd !== null) { try { fs.closeSync(fd); } catch {} }
    try { if (fs.existsSync(tmp)) fs.unlinkSync(tmp); } catch {}
    throw e;
  }
}

function historyFiles() {
  if (!HISTORY_MAX || !fs.existsSync(HISTORY_DIR)) return [];
  try {
    return fs.readdirSync(HISTORY_DIR)
      .filter(n => /^loc-\d{8}T\d{6}\.\d{3}Z-[0-9a-f]{6}\.json$/.test(n))
      .sort()
      .reverse();
  } catch { return []; }
}

function writeHistorySnapshot(obj) {
  if (!HISTORY_MAX) return;
  ensureParent(path.join(HISTORY_DIR, "x"));
  const stamp = new Date().toISOString().replace(/[-:]/g, "");
  const name = "loc-" + stamp + "-" + crypto.randomBytes(3).toString("hex") + ".json";
  atomicWriteJson(path.join(HISTORY_DIR, name), normalizeLoc(obj));
  stats.historyWrites += 1;
  const files = historyFiles();
  for (const oldName of files.slice(HISTORY_MAX)) {
    try { fs.unlinkSync(path.join(HISTORY_DIR, oldName)); } catch {}
  }
}

function writeLoc(obj, options) {
  options = options || {};
  const normalized = normalizeLoc(obj);
  const current = readLoc();
  assertRevision(options.expectedRevision, current);

  if (options.backup !== false && fs.existsSync(DATA_FILE)) {
    if (JSON.stringify(current) !== JSON.stringify(normalized)) {
      try {
        // 上一版本备份属于关键保护；备份失败时不继续覆盖主配置。
        atomicWriteJson(BACKUP_FILE, current);
      } catch (e) {
        e.message = "backup write failed: " + e.message;
        throw e;
      }
      try {
        // history 是增强能力；历史目录异常不应让核心定位保存完全不可用。
        writeHistorySnapshot(current);
      } catch (e) {
        console.error("history snapshot failed (continuing with backup): " + e.message);
      }
    }
  }
  atomicWriteJson(DATA_FILE, normalized);
  configRecoveryStatus.degraded = false;
  configRecoveryStatus.recoveredFrom = "manual-write";
  stats.writeOps += 1;
  return normalized;
}

function rollbackLoc(expectedRevision) {
  if (!fs.existsSync(BACKUP_FILE)) {
    const e = new Error("没有可回滚的上一次保存");
    e.statusCode = 404;
    throw e;
  }
  const backupRaw = JSON.parse(fs.readFileSync(BACKUP_FILE, "utf8"));
  validateStoredLocInput(backupRaw);
  const previous = normalizeLoc(backupRaw);
  const current = fs.existsSync(DATA_FILE) ? readLoc() : null;
  if (current) assertRevision(expectedRevision, current);
  if (current) {
    try { writeHistorySnapshot(current); } catch (e) { console.error("rollback history snapshot failed: " + e.message); }
  }
  atomicWriteJson(DATA_FILE, previous);
  if (current) atomicWriteJson(BACKUP_FILE, current);
  stats.rollbacks += 1;
  writeMeta({ source:"rollback", appliedAt:new Date().toISOString() });
  return previous;
}

function listHistory(limit) {
  const n = Math.max(1, Math.min(50, Number(limit) || 20));
  return historyFiles().slice(0, n).map(name => {
    const file = path.join(HISTORY_DIR, name);
    let loc = null;
    try {
      const raw = JSON.parse(fs.readFileSync(file, "utf8"));
      validateStoredLocInput(raw);
      loc = normalizeLoc(raw);
    } catch {}
    let st = null;
    try { st = fs.statSync(file); } catch {}
    return { id:name, time:st ? st.mtime.toISOString() : null, location:loc };
  }).filter(x => x.location);
}

function restoreHistory(id, expectedRevision) {
  const name = path.basename(String(id || ""));
  if (!/^loc-\d{8}T\d{6}\.\d{3}Z-[0-9a-f]{6}\.json$/.test(name)) {
    const e = new Error("invalid history id"); e.statusCode = 400; throw e;
  }
  const file = path.join(HISTORY_DIR, name);
  if (!fs.existsSync(file)) { const e = new Error("history item not found"); e.statusCode = 404; throw e; }
  const historyRaw = JSON.parse(fs.readFileSync(file, "utf8"));
  validateStoredLocInput(historyRaw);
  const previous = normalizeLoc(historyRaw);
  const current = fs.existsSync(DATA_FILE) ? readLoc() : null;
  if (current) {
    assertRevision(expectedRevision, current);
    atomicWriteJson(BACKUP_FILE, current);
    try { writeHistorySnapshot(current); } catch (e) { console.error("restore history snapshot failed: " + e.message); }
  }
  atomicWriteJson(DATA_FILE, previous);
  stats.historyRestores += 1;
  writeMeta({ source:"history-restore", historyId:name, appliedAt:new Date().toISOString() });
  return previous;
}

function writeMeta(meta) {
  try { atomicWriteJson(META_FILE, meta); } catch (e) { console.error("meta write failed: " + e.message); }
}

const BASE_HEADERS = {
  ...(CORS_ORIGIN ? { "Access-Control-Allow-Origin": CORS_ORIGIN } : {}),
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Cache-Control": "no-store",
  "X-Content-Type-Options": "nosniff",
  "Referrer-Policy": "no-referrer",
  "X-Frame-Options": "DENY",
  "Permissions-Policy": "geolocation=(self), camera=(), microphone=()",
  "Cross-Origin-Opener-Policy": "same-origin"
};

const PAGE_CSP = [
  "default-src 'none'",
  "script-src 'self'",
  // Leaflet 运行时会写元素 style 属性；脚本本身仍严格限定为同源。
  "style-src 'self' 'unsafe-inline'",
  "img-src 'self' https: data: blob:",
  "connect-src 'self'",
  "base-uri 'none'",
  "form-action 'self'",
  "object-src 'none'",
  "frame-ancestors 'none'"
].join("; ");

function send(res, code, type, body, extra) {
  res.writeHead(code, { ...BASE_HEADERS, "Content-Type": type, ...(extra || {}) });
  res.end(body);
}
function sendJson(res, code, obj) { return send(res, code, "application/json; charset=utf-8", JSON.stringify(obj)); }

function parseCookies(req) {
  const out = {};
  const raw = String(req.headers.cookie || "");
  for (const part of raw.split(";")) {
    const eq = part.indexOf("=");
    if (eq <= 0) continue;
    const k = part.slice(0, eq).trim();
    const v = part.slice(eq + 1).trim();
    try { out[k] = decodeURIComponent(v); } catch { out[k] = v; }
  }
  return out;
}

function b64url(input) { return Buffer.from(String(input)).toString("base64url"); }
function signSession(payload) { return crypto.createHmac("sha256", TOKEN).update(payload).digest("base64url"); }
function sessionValue() {
  const payload = b64url(JSON.stringify({ exp: Date.now() + SESSION_TTL_HOURS * 3600 * 1000, v: 1 }));
  return payload + "." + signSession(payload);
}
function verifySession(req) {
  const raw = parseCookies(req)[SESSION_COOKIE] || "";
  const dot = raw.lastIndexOf(".");
  if (dot <= 0) return false;
  const payload = raw.slice(0, dot), sig = raw.slice(dot + 1);
  if (!safeEqual(signSession(payload), sig)) return false;
  try {
    const data = JSON.parse(Buffer.from(payload, "base64url").toString("utf8"));
    return Number(data.exp) > Date.now() && data.v === 1;
  } catch { return false; }
}
function firstHeaderValue(value) {
  return String(value || "").split(",")[0].trim();
}
function lastHeaderValue(value) {
  const parts = String(value || "").split(",").map(v => v.trim()).filter(Boolean);
  return parts.length ? parts[parts.length - 1] : "";
}

function normalizeRemoteAddress(value) {
  let s = String(value || "").trim();
  if (s.startsWith("::ffff:")) s = s.slice(7);
  if (s.startsWith("[") && s.endsWith("]")) s = s.slice(1, -1);
  return s;
}

function isLoopbackAddress(value) {
  const s = normalizeRemoteAddress(value);
  return s === "127.0.0.1" || s === "::1" || s.startsWith("127.");
}

function proxyHeadersTrusted(req) {
  if (!TRUST_PROXY) return false;
  if (TRUST_PROXY_ALL) return true;
  return isLoopbackAddress(req.socket && req.socket.remoteAddress);
}

function requestExternalProto(req) {
  if (req.socket && req.socket.encrypted) return "https";
  if (proxyHeadersTrusted(req)) {
    const xf = firstHeaderValue(req.headers["x-forwarded-proto"]).toLowerCase();
    if (xf === "https" || xf === "http") return xf;
  }
  return "http";
}

function requestExternalHost(req) {
  if (proxyHeadersTrusted(req)) {
    const xfHost = firstHeaderValue(req.headers["x-forwarded-host"]);
    if (xfHost) return xfHost;
  }
  return firstHeaderValue(req.headers.host) || "localhost";
}

function requestExternalPort(req) {
  if (proxyHeadersTrusted(req)) {
    const xfPort = firstHeaderValue(req.headers["x-forwarded-port"]);
    if (/^\d{1,5}$/.test(xfPort)) return xfPort;
  }
  return "";
}

function canonicalExternalOrigin(req) {
  if (PUBLIC_ORIGIN) {
    try { return new URL(PUBLIC_ORIGIN).origin; } catch {}
  }
  const proto = requestExternalProto(req);
  let host = requestExternalHost(req);
  const forwardedPort = requestExternalPort(req);
  try {
    let u = new URL(proto + "://" + host);
    // X-Forwarded-Host 可能来自 `$host` 而没有非标准端口；用 X-Forwarded-Port 补齐。
    if (!u.port && forwardedPort) {
      const p = Number(forwardedPort);
      const isDefault = (proto === "https" && p === 443) || (proto === "http" && p === 80);
      if (!isDefault && p > 0 && p <= 65535) u.port = String(p);
    }
    return u.origin;
  } catch {
    return proto + "://" + host;
  }
}

function remoteConfigUrl(req) {
  return canonicalExternalOrigin(req) + "/loc.json?token=" + encodeURIComponent(CLIENT_TOKEN);
}

function clientAssetVersion(kind) {
  const spec = kind === "qx" ? UPSTREAM_ASSETS.qx : UPSTREAM_ASSETS.core;
  return String(spec.expectedBlobSha || UPSTREAM_AUDITED_COMMIT);
}

function selfHostedClientScriptUrl(req, kind) {
  const pathName = kind === "qx" ? "/client/location-spoofer-qx.js" : "/client/location-spoofer.js";
  // immutable 缓存必须使用版本化 URL；升级审计 blob 后查询串随之变化，避免客户端继续使用旧脚本。
  return canonicalExternalOrigin(req) + pathName + "?v=" + encodeURIComponent(clientAssetVersion(kind));
}

function effectiveClientScriptSource(req) {
  try {
    const u = new URL(req.url || "/", "http://" + (req.headers && req.headers.host || "localhost"));
    const override = String(u.searchParams.get("clientSource") || "").trim().toLowerCase();
    if (override === "github" || override === "self") return override;
  } catch {}
  return CLIENT_SCRIPT_SOURCE;
}

function clientScriptUrl(req, kind) {
  if (effectiveClientScriptSource(req) === "github") {
    return kind === "qx" ? UPSTREAM_QX_SCRIPT_SOURCE : UPSTREAM_CORE_SCRIPT_SOURCE;
  }
  return selfHostedClientScriptUrl(req, kind);
}

function escapeProfileQuoted(value) {
  return String(value).replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/[\r\n]/g, "");
}

function profileFallbackConfig() {
  const loc = readLoc();
  if (configRecoveryStatus.degraded) {
    const e = new Error("当前 loc.json 处于降级恢复状态，请先登录后台重新保存一个有效位置，再生成客户端模块");
    e.statusCode = 503;
    e.code = "CONFIG_DEGRADED";
    throw e;
  }
  return {
    enabled: loc.enabled !== false,
    latitude: Number(loc.latitude),
    longitude: Number(loc.longitude),
    altitude: Number(loc.altitude),
    horizontalAccuracy: Number(loc.horizontalAccuracy),
    verticalAccuracy: Number(loc.verticalAccuracy),
    failOpen: loc.failOpen !== false,
    debug: loc.debug === true
  };
}

function profileArgBool(v) { return v ? "true" : "false"; }
function profileArgNum(v, fallback) {
  const n = Number(v);
  return Number.isFinite(n) ? String(n) : String(fallback);
}

function profileSubscriptionUrl(req, pathname, clientSource) {
  const u = new URL(canonicalExternalOrigin(req) + pathname);
  u.searchParams.set("token", CLIENT_TOKEN);
  if (clientSource === "github" || clientSource === "self") u.searchParams.set("clientSource", clientSource);
  return u.toString();
}

function buildShadowrocketProfile(req) {
  const cfg = encodeURIComponent(remoteConfigUrl(req));
  const f = profileFallbackConfig();
  return [
    "#!name=iOS Location Spoofer Remote (Audited V11)",
    "#!desc=上游 mekos2772 原核心 + V11 远程网页选点配置。",
    "#!homepage=https://github.com/mekos2772/ios-location-spoofer",
    "",
    "[Script]",
    "iOS Location Spoofer = type=http-response,pattern=^https?:\\/\\/(?:gs-loc(?:-cn)?\\.apple\\.com|gsp-ssl\\.ls\\.apple\\.com|bluedot\\.is\\.autonavi\\.com(?:\\.gds\\.alibabadns\\.com)?)\\/clls\\/wloc(?:\\?.*)?$,requires-body=1,binary-body-mode=1,max-size=1048576,timeout=12,script-path=" + clientScriptUrl(req, "core") + ",argument=mode=response&enabled=" + profileArgBool(f.enabled) + "&latitude=" + profileArgNum(f.latitude,37.3349) + "&longitude=" + profileArgNum(f.longitude,-122.00902) + "&horizontalAccuracy=" + profileArgNum(f.horizontalAccuracy,39) + "&verticalAccuracy=" + profileArgNum(f.verticalAccuracy,1000) + "&altitude=" + profileArgNum(f.altitude,530) + "&failOpen=" + profileArgBool(f.failOpen) + "&configUrl=" + cfg + "&debug=" + profileArgBool(f.debug),
    "",
    "[MITM]",
    "hostname = %APPEND% gs-loc.apple.com, gs-loc-cn.apple.com, gsp-ssl.ls.apple.com, bluedot.is.autonavi.com, bluedot.is.autonavi.com.gds.alibabadns.com",
    ""
  ].join("\n");
}

function buildSurgeProfile(req) {
  const cfg = encodeURIComponent(remoteConfigUrl(req));
  const f = profileFallbackConfig();
  return [
    "#!name=iOS Location Spoofer Remote (Audited V11)",
    "#!desc=上游 mekos2772 原核心 + V11 远程网页选点配置。",
    "#!homepage=https://github.com/mekos2772/ios-location-spoofer",
    "",
    "[Script]",
    "iOS Location Spoofer = type=http-response,pattern=^https?:\\/\\/(?:gs-loc(?:-cn)?\\.apple\\.com|gsp-ssl\\.ls\\.apple\\.com|bluedot\\.is\\.autonavi\\.com(?:\\.gds\\.alibabadns\\.com)?)\\/clls\\/wloc(?:\\?.*)?$,requires-body=1,binary-body-mode=1,max-size=1048576,timeout=12,script-path=" + clientScriptUrl(req, "core") + ",argument=mode=response&enabled=" + profileArgBool(f.enabled) + "&latitude=" + profileArgNum(f.latitude,37.3349) + "&longitude=" + profileArgNum(f.longitude,-122.00902) + "&horizontalAccuracy=" + profileArgNum(f.horizontalAccuracy,39) + "&verticalAccuracy=" + profileArgNum(f.verticalAccuracy,1000) + "&altitude=" + profileArgNum(f.altitude,530) + "&failOpen=" + profileArgBool(f.failOpen) + "&configUrl=" + cfg + "&debug=" + profileArgBool(f.debug),
    "",
    "[MITM]",
    "hostname = %APPEND% gs-loc.apple.com, gs-loc-cn.apple.com, gsp-ssl.ls.apple.com, bluedot.is.autonavi.com, bluedot.is.autonavi.com.gds.alibabadns.com",
    ""
  ].join("\n");
}

function buildLoonProfile(req) {
  const origin = escapeProfileQuoted(canonicalExternalOrigin(req));
  const token = escapeProfileQuoted(CLIENT_TOKEN);
  const f = profileFallbackConfig();
  return [
    "#!name=iOS Location Spoofer Remote (Audited V11)",
    "#!desc=上游 mekos2772 原核心 + V11 远程网页选点配置（Loon）",
    "#!homepage=https://github.com/mekos2772/ios-location-spoofer",
    "",
    "[Argument]",
    "enabled = switch," + profileArgBool(f.enabled) + ",tag=启用定位修改,desc=关闭后脚本直接放行原始定位数据",
    "latitude = input,\"" + profileArgNum(f.latitude,37.3349) + "\",tag=纬度(备用),desc=远程配置不可用时使用",
    "longitude = input,\"" + profileArgNum(f.longitude,-122.00902) + "\",tag=经度(备用),desc=远程配置不可用时使用",
    "altitude = input,\"" + profileArgNum(f.altitude,530) + "\",tag=海拔(米),desc=目标海拔",
    "horizontalAccuracy = input,\"" + profileArgNum(f.horizontalAccuracy,39) + "\",tag=水平精度(米),desc=网页选点时以 loc.json 为准",
    "verticalAccuracy = input,\"" + profileArgNum(f.verticalAccuracy,1000) + "\",tag=垂直精度(米),desc=网页选点时以 loc.json 为准",
    "address = input,\"\",tag=地址搜索,desc=留空即可；网页端负责选点",
    "configHost = input,\"" + origin + "\",tag=配置服务器,desc=V11 网页选点服务器",
    "configToken = input,\"" + token + "\",tag=配置Token,desc=只读 CLIENT_TOKEN，不具备后台写权限",
    "configUrl = input,\"\",tag=远程配置URL,desc=留空，使用 configHost + configToken",
    "debug = switch," + profileArgBool(f.debug) + ",tag=调试日志,desc=排查时打开",
    "",
    "[Script]",
    "http-request ^https?:\\/\\/(?:gs-loc(?:-cn)?\\.apple\\.com|gsp-ssl\\.ls\\.apple\\.com|bluedot\\.is\\.autonavi\\.com(?:\\.gds\\.alibabadns\\.com)?)\\/clls\\/wloc(?:\\?.*)?$ script-path=" + clientScriptUrl(req, "core") + ", requires-body=false, timeout=3, tag=iOS Location Spoofer Prepare, argument=[{debug}]",
    "http-response ^https?:\\/\\/(?:gs-loc(?:-cn)?\\.apple\\.com|gsp-ssl\\.ls\\.apple\\.com|bluedot\\.is\\.autonavi\\.com(?:\\.gds\\.alibabadns\\.com)?)\\/clls\\/wloc(?:\\?.*)?$ script-path=" + clientScriptUrl(req, "core") + ", requires-body=true, binary-body-mode=true, max-size=1048576, timeout=12, tag=iOS Location Spoofer, argument=[{enabled},{latitude},{longitude},{altitude},{horizontalAccuracy},{verticalAccuracy},{address},{configHost},{configToken},{configUrl},{debug}]",
    "cron \"*/15 * * * *\" script-path=" + clientScriptUrl(req, "core") + ", timeout=30, tag=iOS Location Spoofer Sync, argument=[{address},{configHost},{configToken},{configUrl},{debug}]",
    "",
    "[mitm]",
    "hostname = gs-loc.apple.com, gs-loc-cn.apple.com, gsp-ssl.ls.apple.com, bluedot.is.autonavi.com, bluedot.is.autonavi.com.gds.alibabadns.com",
    ""
  ].join("\n");
}

function buildStashProfile(req) {
  const cfg = encodeURIComponent(remoteConfigUrl(req));
  const f = profileFallbackConfig();
  return [
    "name: iOS Location Spoofer Remote (Audited V11)",
    "desc: 上游 mekos2772 原核心 + V11 远程网页选点配置。",
    "homepage: https://github.com/mekos2772/ios-location-spoofer",
    "http:",
    "  script:",
    "    - match: ^https?:\\/\\/(?:gs-loc(?:-cn)?\\.apple\\.com|gsp-ssl\\.ls\\.apple\\.com|bluedot\\.is\\.autonavi\\.com(?:\\.gds\\.alibabadns\\.com)?)\\/clls\\/wloc(?:\\?.*)?$",
    "      name: ios-location-spoofer",
    "      type: response",
    "      require-body: true",
    "      binary-mode: true",
    "      max-size: 1048576",
    "      timeout: 12",
    "      argument: mode=response&enabled=" + profileArgBool(f.enabled) + "&latitude=" + profileArgNum(f.latitude,37.3349) + "&longitude=" + profileArgNum(f.longitude,-122.00902) + "&horizontalAccuracy=" + profileArgNum(f.horizontalAccuracy,39) + "&verticalAccuracy=" + profileArgNum(f.verticalAccuracy,1000) + "&altitude=" + profileArgNum(f.altitude,530) + "&failOpen=" + profileArgBool(f.failOpen) + "&configUrl=" + cfg + "&debug=" + profileArgBool(f.debug),
    "  mitm:",
    "    - gs-loc.apple.com",
    "    - gs-loc-cn.apple.com",
    "    - gsp-ssl.ls.apple.com",
    "    - bluedot.is.autonavi.com",
    "    - bluedot.is.autonavi.com.gds.alibabadns.com",
    "script-providers:",
    "  ios-location-spoofer:",
    "    url: " + clientScriptUrl(req, "core"),
    "    interval: 86400",
    ""
  ].join("\n");
}

function profileContentDisposition(url, filename) {
  const mode = String(url.searchParams.get("download") || "");
  const safeName = String(filename || "profile.txt").replace(/[^A-Za-z0-9._-]/g, "_");
  return (mode === "1" ? "attachment" : "inline") + '; filename="' + safeName + '"';
}

function sendGeneratedProfile(res, url, filename, builder, req) {
  try {
    return send(res, 200, "text/plain; charset=utf-8", builder(req), {
      "Content-Disposition": profileContentDisposition(url, filename)
    });
  } catch (err) {
    if (err && err.code === "CONFIG_DEGRADED") {
      return send(
        res,
        503,
        "text/plain; charset=utf-8",
        "location configuration unavailable; sign in to the admin UI and save a valid location before generating a client profile\n",
        { "Cache-Control": "no-store" }
      );
    }
    throw err;
  }
}

function profileCatalog(req) {
  const configUrl = remoteConfigUrl(req);
  const defs = [
    { id:"shadowrocket", name:"Shadowrocket", path:"/profiles/shadowrocket.sgmodule", confidence:"upstream-documented" },
    { id:"surge", name:"Surge", path:"/profiles/surge.sgmodule", confidence:"shared-core-experimental" },
    { id:"loon", name:"Loon", path:"/profiles/ios-location-spoofer.lnplugin", confidence:"upstream-native" },
    { id:"stash", name:"Stash", path:"/profiles/ios-location-spoofer.stoverride", confidence:"shared-core-experimental" }
  ];
  return {
    auditedRepository:UPSTREAM_REPO,
    auditedCommit:UPSTREAM_AUDITED_COMMIT,
    clientScriptRef:UPSTREAM_REF,
    clientScriptSource:effectiveClientScriptSource(req),
    configuredClientScriptSource:CLIENT_SCRIPT_SOURCE,
    coreScript:clientScriptUrl(req, "core"),
    upstreamCoreSource:UPSTREAM_CORE_SCRIPT_SOURCE,
    mirrorStatus:upstreamAssetsStatus(),
    configUrl,
    clientTokenMode:CLIENT_TOKEN_EXPLICIT ? "explicit" : "derived",
    expectedRemoteFields:["enabled","latitude","longitude","horizontalAccuracy","verticalAccuracy","altitude","failOpen","debug"],
    profiles:defs.map(it => ({
      id:it.id, name:it.name, remotePicker:true, confidence:it.confidence,
      download:it.path + "?download=1",
      installUrl:profileSubscriptionUrl(req, it.path, "self"),
      githubFallback:profileSubscriptionUrl(req, it.path, "github")
    })),
    quantumultX:{ remotePicker:false, script:clientScriptUrl(req, "qx"), reason:"上游 location-spoofer-qx.js 的 loadConfig() 只使用内置 DEFAULT_CONFIG，不读取 configUrl；V11 不伪装成已支持。" }
  };
}

function requestIsSecure(req) {
  return requestExternalProto(req) === "https";
}
function secureCookieFor(req) {
  if (COOKIE_SECURE === "true" || COOKIE_SECURE === "1") return true;
  if (COOKIE_SECURE === "false" || COOKIE_SECURE === "0") return false;
  return requestIsSecure(req);
}
function sessionCookie(req, clear) {
  const parts = [SESSION_COOKIE + "=" + (clear ? "" : sessionValue()), "Path=/", "HttpOnly", "SameSite=Strict"];
  if (clear) parts.push("Max-Age=0"); else parts.push("Max-Age=" + (SESSION_TTL_HOURS * 3600));
  if (secureCookieFor(req)) parts.push("Secure");
  return parts.join("; ");
}

function clientQueryTokenAllowed(req, url) {
  if (req.method !== "GET") return false;
  if (url.pathname === "/loc.json") return true;
  return [
    "/profiles/shadowrocket.sgmodule",
    "/profiles/surge.sgmodule",
    "/profiles/ios-location-spoofer.lnplugin",
    "/profiles/ios-location-spoofer.stoverride"
  ].includes(url.pathname);
}

function bearerTokenFromRequest(req) {
  const auth = String(req.headers.authorization || "");
  return auth.toLowerCase().startsWith("bearer ") ? auth.slice(7).trim() : "";
}

function clientQueryTokenFromRequest(req, url) {
  if (!clientQueryTokenAllowed(req, url)) return "";
  return String(url.searchParams.get("token") || "").trim();
}

function isAdminAuthenticated(req) {
  const bearer = bearerTokenFromRequest(req);
  if (bearer && safeEqual(bearer, TOKEN)) return true;
  return verifySession(req);
}

function isClientReadAuthenticated(req, url) {
  if (isAdminAuthenticated(req)) return true;
  const q = clientQueryTokenFromRequest(req, url);
  if (!q) return false;
  // V11 默认只接受 CLIENT_TOKEN。若显式开启迁移开关，才临时兼容旧版把管理 TOKEN 放在 query 的模块。
  return safeEqual(q, CLIENT_TOKEN) || (ALLOW_LEGACY_ADMIN_QUERY_TOKEN && safeEqual(q, TOKEN));
}

function checkAdmin(req, url, res) {
  if (isAdminAuthenticated(req)) return true;
  const bearer = bearerTokenFromRequest(req);
  if (!bearer && !verifySession(req)) {
    sendJson(res, 401, { error:"missing admin authentication", login:"/login" });
    return false;
  }
  sendJson(res, 403, { error:"bad admin token" });
  return false;
}

function checkClientRead(req, url, res) {
  if (isClientReadAuthenticated(req, url)) return true;
  const q = clientQueryTokenFromRequest(req, url);
  if (!q && !isAdminAuthenticated(req)) {
    sendJson(res, 401, { error:"missing client token", hint:"use the generated module/install URL or admin login" });
    return false;
  }
  sendJson(res, 403, { error:"bad client token" });
  return false;
}

function clientIp(req) {
  if (proxyHeadersTrusted(req)) {
    // 宝塔常用 `$proxy_add_x_forwarded_for` 会把真实客户端地址追加在最右侧。
    // 取最右值，避免客户端预先伪造 X-Forwarded-For 绕过登录/IP 查询限流。
    const xff = lastHeaderValue(req.headers["x-forwarded-for"]);
    if (xff) return normalizeRemoteAddress(xff);
    const xr = firstHeaderValue(req.headers["x-real-ip"]);
    if (xr) return normalizeRemoteAddress(xr);
  }
  return normalizeRemoteAddress(req.socket && req.socket.remoteAddress || "unknown");
}

function originCheck(req) {
  const received = String(req.headers.origin || "").trim();
  if (!received) return { ok:true, nonBrowser:true, received:"", expected:canonicalExternalOrigin(req) };
  let normalizedReceived = "";
  try { normalizedReceived = new URL(received).origin; }
  catch { return { ok:false, code:"BAD_ORIGIN", received, expected:canonicalExternalOrigin(req) }; }
  const expected = canonicalExternalOrigin(req);
  return {
    ok: normalizedReceived === expected,
    code: normalizedReceived === expected ? "OK" : "ORIGIN_MISMATCH",
    received: normalizedReceived,
    expected,
    proxyTrusted: proxyHeadersTrusted(req),
    externalProto: requestExternalProto(req),
    externalHost: requestExternalHost(req),
    externalPort: requestExternalPort(req)
  };
}

function sameOriginOrNonBrowser(req) {
  return originCheck(req).ok;
}

function enforceSameOrigin(req, res) {
  const c = originCheck(req);
  if (c.ok) return true;
  stats.originBlocked += 1;
  sendJson(res, 403, {
    error:"cross-origin write blocked",
    code:c.code || "ORIGIN_MISMATCH",
    message:"浏览器 Origin 与服务器识别到的外部地址不一致。",
    receivedOrigin:c.received,
    expectedOrigin:c.expected,
    proxyTrusted:!!c.proxyTrusted,
    hint:"宝塔/Nginx 非标准 HTTPS 端口请转发 X-Forwarded-Proto、X-Forwarded-Host、X-Forwarded-Port；V11 可自动识别 :8081/:8443 等端口。"
  });
  return false;
}

function readTextBody(req, maxBytes = 10000) {
  return new Promise((resolve, reject) => {
    let body = "", rejected = false;
    req.setEncoding("utf8");
    req.on("data", chunk => {
      if (rejected) return;
      body += chunk;
      if (Buffer.byteLength(body, "utf8") > maxBytes) {
        rejected = true;
        // 不销毁 socket：继续由 Node 消耗后续 body，但立即让路由返回 413。
        // 直接 req.destroy() 会让客户端更常看到 ECONNRESET 而不是结构化 413。
        reject(Object.assign(new Error("payload too large"), { statusCode: 413 }));
      }
    });
    req.on("end", () => { if (!rejected) resolve(body); });
    req.on("error", err => { if (!rejected) reject(err); });
  });
}

async function readJsonBody(req, maxBytes = 10000) {
  const body = await readTextBody(req, maxBytes);
  if (!body) return {};
  try { return JSON.parse(body); } catch { throw Object.assign(new Error("bad json"), { statusCode: 400 }); }
}

function compactText(value, maxLen = 256) {
  const s = value == null ? "" : String(value).trim();
  if (!s || s === "-") return "";
  const n = Number.isFinite(Number(maxLen)) ? Math.max(1, Math.min(2048, Math.trunc(Number(maxLen)))) : 256;
  return s.slice(0, n);
}

function formatIpAddress(data) {
  const values = [data.city_name, data.region_name, data.zip_code, data.country_name];
  const out = [];
  for (const raw of values) {
    const v = compactText(raw, 160);
    if (v && !out.includes(v)) out.push(v);
  }
  return out.join(", ").slice(0, 512);
}

function specialIpv4(ip) {
  const p = ip.split(".").map(Number);
  if (p.length !== 4 || p.some(n => !Number.isInteger(n) || n < 0 || n > 255)) return true;
  const [a,b,c] = p;
  return a === 0 || a === 10 || a === 127 ||
    (a === 100 && b >= 64 && b <= 127) ||
    (a === 169 && b === 254) ||
    (a === 172 && b >= 16 && b <= 31) ||
    (a === 192 && b === 0 && c === 0) ||
    (a === 192 && b === 0 && c === 2) ||
    (a === 192 && b === 88 && c === 99) ||
    (a === 192 && b === 168) ||
    (a === 198 && (b === 18 || b === 19)) ||
    (a === 198 && b === 51 && c === 100) ||
    (a === 203 && b === 0 && c === 113) ||
    a >= 224;
}

function isSpecialIp(ip) {
  const kind = net.isIP(ip);
  if (kind === 4) return specialIpv4(ip);
  if (kind !== 6) return true;
  const s = ip.toLowerCase();

  // IPv4-mapped IPv6，例如 ::ffff:192.168.1.1。
  const mapped = s.match(/^::ffff:(\d{1,3}(?:\.\d{1,3}){3})$/);
  if (mapped) return specialIpv4(mapped[1]);

  return s === "::" || s === "::1" ||
    s.startsWith("fe8") || s.startsWith("fe9") || s.startsWith("fea") || s.startsWith("feb") ||
    s.startsWith("fc") || s.startsWith("fd") || s.startsWith("ff") ||
    s.startsWith("100:") || s.startsWith("2001:db8:");
}

function boundedWindowAllow(map, key, limit, windowMs) {
  const now = Date.now();
  const k = String(key || "unknown").slice(0, 128);
  let state = map.get(k);
  if (!state || now - state.start >= windowMs) state = { start:now, count:0, seen:now };
  state.seen = now;
  if (state.count >= limit) {
    map.delete(k); map.set(k, state);
    return false;
  }
  state.count += 1;
  map.delete(k); map.set(k, state);
  while (map.size > RATE_LIMIT_CLIENTS_MAX) map.delete(map.keys().next().value);
  return true;
}

function checkRateLimit(client) {
  const ok = boundedWindowAllow(ipRateClients, client, IP_LOOKUP_RATE_LIMIT, 60000);
  if (!ok) stats.rateLimited += 1;
  return ok;
}

function checkGeoRateLimit() {
  // Nominatim 公共服务限制针对整个应用，而不是单个访问者，所以这里保留全局窗口。
  const now = Date.now();
  if (now - geoRateWindowStart >= 60000) { geoRateWindowStart = now; geoRateWindowCount = 0; }
  if (geoRateWindowCount >= GEO_RATE_LIMIT) return false;
  geoRateWindowCount += 1;
  return true;
}

function cacheMapGet(map, key, ttlMs, statKey) {
  const hit = map.get(key);
  if (!hit) return null;
  if (ttlMs <= 0 || Date.now() - hit.ts > ttlMs) { map.delete(key); return null; }
  map.delete(key); map.set(key, hit);
  if (statKey) stats[statKey] += 1;
  return hit.data;
}
function cacheMapPut(map, key, data, max) {
  map.set(key, { ts:Date.now(), data });
  while (map.size > max) map.delete(map.keys().next().value);
}

function ipCircuitState() {
  const now = Date.now();
  const retryAfterMs = Math.max(0, ipUpstream.circuitOpenUntil - now);
  return {
    available: retryAfterMs === 0,
    circuitOpen: retryAfterMs > 0,
    retryAfterMs,
    consecutiveFailures: ipUpstream.consecutiveFailures,
    lastSuccessAt: ipUpstream.lastSuccessAt || null,
    lastFailureAt: ipUpstream.lastFailureAt || null,
    lastError: ipUpstream.lastError || ""
  };
}

function noteIpSuccess() {
  ipUpstream.consecutiveFailures = 0;
  ipUpstream.circuitOpenUntil = 0;
  ipUpstream.lastSuccessAt = Date.now();
  ipUpstream.lastError = "";
}

function noteIpFailure(error) {
  ipUpstream.consecutiveFailures += 1;
  ipUpstream.lastFailureAt = Date.now();
  ipUpstream.lastError = String(error && error.message || error || "IP2Location lookup failed").slice(0, 300);
  if (ipUpstream.consecutiveFailures >= IP2LOCATION_FAILURE_THRESHOLD) {
    ipUpstream.circuitOpenUntil = Date.now() + IP2LOCATION_COOLDOWN_MS;
  }
}

function manualFallbackPayload(message, extra) {
  stats.ipFallbacks += 1;
  return {
    error: "ip lookup failed",
    message: message || "IP2Location 暂时不可用",
    manualFallback: true,
    fallbackMode: "manual-map",
    hint: "IP 查询失败不会影响手动定位：可搜索地点、点击地图、拖动图钉、直接填写经纬度，然后点击保存定位。",
    upstream: ipCircuitState(),
    ...(extra || {})
  };
}

function cacheGet(ip) {
  const hit = lookupCache.get(ip);
  if (!hit) return null;
  if (IP2LOCATION_CACHE_TTL_MS <= 0 || Date.now() - hit.ts > IP2LOCATION_CACHE_TTL_MS) { lookupCache.delete(ip); return null; }
  lookupCache.delete(ip); lookupCache.set(ip, hit);
  stats.cacheHits += 1;
  return { ...hit.data, cacheHit: true };
}

function cachePut(ip, data) {
  if (IP2LOCATION_CACHE_TTL_MS <= 0) return;
  lookupCache.set(ip, { ts: Date.now(), data });
  while (lookupCache.size > IP2LOCATION_CACHE_MAX) lookupCache.delete(lookupCache.keys().next().value);
}

function requestJson(targetUrl, headers, timeoutMs) {
  return new Promise((resolve, reject) => {
    const u = new URL(targetUrl);
    const client = u.protocol === "http:" ? http : https;
    let settled = false;
    const done = (err, value) => { if (settled) return; settled = true; err ? reject(err) : resolve(value); };
    const req = client.request({ protocol:u.protocol, hostname:u.hostname, port:u.port || undefined, path:u.pathname + u.search, method:"GET", headers }, apiRes => {
      let body = "", bodyBytes = 0;
      apiRes.setEncoding("utf8");
      apiRes.on("data", chunk => {
        bodyBytes += Buffer.byteLength(chunk, "utf8");
        if (bodyBytes > 256 * 1024) { apiRes.destroy(new Error("upstream response too large")); return; }
        body += chunk;
      });
      apiRes.on("error", err => done(err));
      apiRes.on("end", () => {
        if (apiRes.statusCode < 200 || apiRes.statusCode >= 300) {
          let detail = "";
          try {
            const parsed = JSON.parse(body || "{}");
            detail = parsed && parsed.error
              ? (parsed.error.error_message || parsed.error.message || (typeof parsed.error === "string" ? parsed.error : ""))
              : (parsed.message || "");
          } catch {}
          const err = new Error("upstream HTTP " + apiRes.statusCode + (detail ? ": " + String(detail).slice(0,220) : ""));
          err.statusCode = apiRes.statusCode;
          err.retryAfter = apiRes.headers["retry-after"];
          err.responseBody = String(body || "").slice(0,1024);
          return done(err);
        }
        try { done(null, JSON.parse(body)); } catch { done(new Error("upstream returned invalid JSON")); }
      });
    });
    req.setTimeout(timeoutMs, () => req.destroy(new Error("upstream request timeout")));
    req.on("error", err => done(err));
    req.end();
  });
}


function gitBlobSha(buffer) {
  const b = Buffer.isBuffer(buffer) ? buffer : Buffer.from(buffer);
  return crypto.createHash("sha1")
    .update(Buffer.from("blob " + b.length + "\0", "utf8"))
    .update(b)
    .digest("hex");
}

function upstreamAssetPath(kind) {
  const spec = UPSTREAM_ASSETS[kind];
  if (!spec) throw new Error("unknown upstream asset: " + kind);
  return path.join(UPSTREAM_CACHE_DIR, spec.filename);
}

function validateUpstreamAssetBuffer(kind, buffer) {
  const spec = UPSTREAM_ASSETS[kind];
  if (!spec) return { ok:false, error:"unknown asset" };
  const b = Buffer.isBuffer(buffer) ? buffer : Buffer.from(buffer);
  const actualSha = gitBlobSha(b);
  if (spec.expectedSize && b.length !== spec.expectedSize) {
    return { ok:false, error:"size mismatch: expected " + spec.expectedSize + ", got " + b.length, actualSha };
  }
  if (!/^[0-9a-f]{40}$/i.test(spec.expectedBlobSha || "")) {
    return { ok:false, error:"invalid expected Git blob SHA" };
  }
  if (!safeEqual(actualSha, spec.expectedBlobSha)) {
    return { ok:false, error:"Git blob SHA mismatch: expected " + spec.expectedBlobSha + ", got " + actualSha, actualSha };
  }
  return { ok:true, actualSha, size:b.length };
}

function readCachedUpstreamAsset(kind) {
  const file = upstreamAssetPath(kind);
  try {
    const buf = fs.readFileSync(file);
    const check = validateUpstreamAssetBuffer(kind, buf);
    if (!check.ok) {
      try {
        const bad = file + ".invalid-" + Date.now();
        fs.renameSync(file, bad);
      } catch {}
      return null;
    }
    stats.upstreamAssetCacheHits += 1;
    const st = upstreamAssetState[kind];
    st.ready = true; st.source = "disk-cache"; st.lastError = "";
    return buf;
  } catch {
    return null;
  }
}

function atomicWriteBuffer(file, buffer, mode = 0o644) {
  ensureParent(file);
  const tmp = file + ".tmp-" + process.pid + "-" + crypto.randomBytes(4).toString("hex");
  let fd = null;
  try {
    fd = fs.openSync(tmp, "wx", mode);
    fs.writeFileSync(fd, buffer);
    try { fs.fsyncSync(fd); } catch {}
    fs.closeSync(fd); fd = null;
    fs.renameSync(tmp, file);
    try {
      const dfd = fs.openSync(path.dirname(file), "r");
      try { fs.fsyncSync(dfd); } finally { fs.closeSync(dfd); }
    } catch {}
  } finally {
    if (fd != null) try { fs.closeSync(fd); } catch {}
    try { if (fs.existsSync(tmp)) fs.unlinkSync(tmp); } catch {}
  }
}

function requestBuffer(targetUrl, headers, timeoutMs, maxBytes, redirects = 0) {
  return new Promise((resolve, reject) => {
    let u;
    try { u = new URL(targetUrl); } catch (e) { reject(e); return; }
    if (u.protocol !== "http:" && u.protocol !== "https:") {
      reject(new Error("unsupported upstream protocol"));
      return;
    }
    const client = u.protocol === "http:" ? http : https;
    let settled = false;
    const done = (err, value) => {
      if (settled) return;
      settled = true;
      err ? reject(err) : resolve(value);
    };
    const req = client.request({
      protocol:u.protocol, hostname:u.hostname, port:u.port || undefined,
      path:u.pathname + u.search, method:"GET", headers:headers || {}
    }, apiRes => {
      if (apiRes.statusCode >= 300 && apiRes.statusCode < 400 && apiRes.headers.location) {
        apiRes.resume();
        if (redirects >= 3) return done(new Error("too many upstream redirects"));
        let nextUrl;
        try { nextUrl = new URL(apiRes.headers.location, u); }
        catch (e) { return done(e); }
        // 资产下载只允许同主机重定向，并禁止 HTTPS 降级到 HTTP。
        // 这样即使 CDN/GitHub 端异常返回恶意 Location，也不会把服务器变成内网探测器。
        if (nextUrl.hostname.toLowerCase() !== u.hostname.toLowerCase()) {
          return done(new Error("cross-host upstream redirect blocked"));
        }
        if (u.protocol === "https:" && nextUrl.protocol !== "https:") {
          return done(new Error("upstream redirect protocol downgrade blocked"));
        }
        if (nextUrl.protocol !== "http:" && nextUrl.protocol !== "https:") {
          return done(new Error("unsupported upstream redirect protocol"));
        }
        requestBuffer(nextUrl.toString(), headers, timeoutMs, maxBytes, redirects + 1).then(v => done(null, v), done);
        return;
      }
      if (apiRes.statusCode < 200 || apiRes.statusCode >= 300) {
        apiRes.resume();
        const e = new Error("upstream HTTP " + apiRes.statusCode);
        e.statusCode = apiRes.statusCode;
        return done(e);
      }
      const chunks = [];
      let total = 0;
      apiRes.on("data", chunk => {
        total += chunk.length;
        if (total > maxBytes) {
          apiRes.destroy(new Error("upstream response too large"));
          return;
        }
        chunks.push(chunk);
      });
      apiRes.on("error", done);
      apiRes.on("end", () => done(null, Buffer.concat(chunks)));
    });
    req.setTimeout(timeoutMs, () => req.destroy(new Error("upstream request timeout")));
    req.on("error", done);
    req.end();
  });
}

function sha384Base64(buffer) {
  const b = Buffer.isBuffer(buffer) ? buffer : Buffer.from(buffer);
  return crypto.createHash("sha384").update(b).digest("base64");
}

function leafletAssetPath(kind) {
  const spec = LEAFLET_ASSETS[kind];
  if (!spec) throw new Error("unknown leaflet asset: " + kind);
  return path.join(LEAFLET_CACHE_DIR, spec.filename);
}

function validateLeafletAssetBuffer(kind, buffer) {
  const spec = LEAFLET_ASSETS[kind];
  if (!spec) return { ok:false, error:"unknown asset" };
  const b = Buffer.isBuffer(buffer) ? buffer : Buffer.from(buffer);
  if (b.length < 1000 || b.length > LEAFLET_FETCH_MAX_BYTES) {
    return { ok:false, error:"unexpected asset size: " + b.length };
  }
  const actualSha384 = sha384Base64(b);
  if (!safeEqual(actualSha384, spec.expectedSha384)) {
    return { ok:false, error:"SHA-384 mismatch", actualSha384 };
  }
  return { ok:true, actualSha384, size:b.length };
}

function readCachedLeafletAsset(kind) {
  const file = leafletAssetPath(kind);
  try {
    const buf = fs.readFileSync(file);
    const check = validateLeafletAssetBuffer(kind, buf);
    if (!check.ok) {
      try { fs.renameSync(file, file + ".invalid-" + Date.now()); } catch {}
      return null;
    }
    const st = leafletAssetState[kind];
    st.ready = true; st.source = "disk-cache"; st.lastError = "";
    return buf;
  } catch { return null; }
}

async function fetchAndVerifyLeaflet(kind) {
  const spec = LEAFLET_ASSETS[kind];
  const attempts = LEAFLET_SOURCE_BASES.map(async base => {
    const url = base + "/" + spec.filename;
    const buf = await requestBuffer(url, { "User-Agent":USER_AGENT, "Accept":"*/*" }, LEAFLET_FETCH_TIMEOUT_MS, LEAFLET_FETCH_MAX_BYTES);
    const check = validateLeafletAssetBuffer(kind, buf);
    if (!check.ok) {
      const e = new Error("Leaflet " + kind + " integrity check failed from " + base + ": " + check.error);
      e.code = "LEAFLET_INTEGRITY_MISMATCH";
      throw e;
    }
    return { buf, source:url };
  });
  if (typeof Promise.any === "function") return Promise.any(attempts);
  const results = await Promise.allSettled(attempts);
  for (const r of results) if (r.status === "fulfilled") return r.value;
  throw (results[0] && results[0].reason) || new Error("all Leaflet sources failed");
}

async function ensureLeafletAssetImpl(kind) {
  const spec = LEAFLET_ASSETS[kind];
  if (!spec) throw new Error("unknown leaflet asset: " + kind);
  const state = leafletAssetState[kind];
  const cached = readCachedLeafletAsset(kind);
  if (cached) return cached;

  const now = Date.now();
  if (LEAFLET_RETRY_COOLDOWN_MS > 0 && state.lastError && state.lastAttemptAt &&
      now - state.lastAttemptAt < LEAFLET_RETRY_COOLDOWN_MS) {
    const e = new Error("Leaflet " + kind + " remote repair is cooling down after previous failure");
    e.code = "LEAFLET_COOLDOWN";
    e.retryAfterMs = Math.max(1, LEAFLET_RETRY_COOLDOWN_MS - (now - state.lastAttemptAt));
    throw e;
  }

  state.lastAttemptAt = now;
  try {
    const hit = await fetchAndVerifyLeaflet(kind);
    atomicWriteBuffer(leafletAssetPath(kind), hit.buf, 0o644);
    state.ready = true; state.source = hit.source; state.lastSuccessAt = Date.now(); state.lastError = "";
    return hit.buf;
  } catch (e) {
    state.ready = false; state.lastError = String(e && e.message || e);
    const fallback = readCachedLeafletAsset(kind);
    if (fallback) { state.ready = true; state.source = "disk-cache-fallback"; return fallback; }
    throw e;
  }
}

async function ensureLeafletAsset(kind) {
  if (leafletAssetInFlight.has(kind)) return leafletAssetInFlight.get(kind);
  const task = ensureLeafletAssetImpl(kind);
  leafletAssetInFlight.set(kind, task);
  try { return await task; }
  finally { if (leafletAssetInFlight.get(kind) === task) leafletAssetInFlight.delete(kind); }
}

function leafletAssetsStatus() {
  const out = {};
  for (const kind of Object.keys(LEAFLET_ASSETS)) {
    const spec = LEAFLET_ASSETS[kind];
    let cachedOnDisk = false, valid = false, actualSha384 = "";
    try {
      const buf = fs.readFileSync(leafletAssetPath(kind));
      cachedOnDisk = true;
      const check = validateLeafletAssetBuffer(kind, buf);
      valid = check.ok; actualSha384 = check.actualSha384 || "";
    } catch {}
    out[kind] = {
      ready:valid || leafletAssetState[kind].ready, cachedOnDisk, valid, filename:spec.filename,
      expectedSha384:spec.expectedSha384, actualSha384, runtime:{ ...leafletAssetState[kind] }
    };
  }
  return out;
}

function publicLeafletAssetsStatus() {
  const full = leafletAssetsStatus(), out = {};
  for (const kind of Object.keys(full)) out[kind] = { ready:!!full[kind].ready, cachedOnDisk:!!full[kind].cachedOnDisk, valid:!!full[kind].valid };
  return out;
}

async function warmUpLeafletAssets() {
  if (!LEAFLET_PRELOAD) return;
  const results = await Promise.allSettled([ensureLeafletAsset("css"), ensureLeafletAsset("js")]);
  for (let i = 0; i < results.length; i += 1) {
    const kind = i === 0 ? "css" : "js";
    if (results[i].status === "fulfilled") console.log("leaflet vendor: " + kind + " ready (" + leafletAssetPath(kind) + ")");
    else console.warn("leaflet vendor: " + kind + " preload failed: " + String(results[i].reason && results[i].reason.message || results[i].reason));
  }
}

function localFrontendAssetsStatus() {
  const out = {};
  for (const [name, def] of Object.entries({
    css:{ file:path.join(PUBLIC_DIR,"app.css") },
    watchdog:{ file:path.join(PUBLIC_DIR,"watchdog.js") },
    app:{ file:path.join(PUBLIC_DIR,"app.js") }
  })) {
    try {
      const st = fs.statSync(def.file);
      out[name] = { ready:st.isFile() && st.size > 0, bytes:st.size };
    } catch { out[name] = { ready:false, bytes:0 }; }
  }
  out.ready = out.css.ready && out.watchdog.ready && out.app.ready;
  out.buildId = FRONTEND_BUILD_ID;
  return out;
}

function staticAssetDefinition(pathname) {
  const defs = {
    "/assets/app.css": { file:path.join(PUBLIC_DIR,"app.css"), type:"text/css; charset=utf-8" },
    "/assets/watchdog.js": { file:path.join(PUBLIC_DIR,"watchdog.js"), type:"application/javascript; charset=utf-8" },
    "/assets/app.js": { file:path.join(PUBLIC_DIR,"app.js"), type:"application/javascript; charset=utf-8" }
  };
  return defs[pathname] || null;
}

function sendStaticFile(req, res, def) {
  let buf;
  try { buf = fs.readFileSync(def.file); }
  catch { return send(res, 404, "text/plain; charset=utf-8", "asset not found"); }
  const etag = '"sha256-' + crypto.createHash("sha256").update(buf).digest("base64url") + '"';
  // app.js/watchdog/app.css 会随补丁版本变化。使用 ETag 强制每次页面加载重新验证，
  // 避免浏览器把同一个 ?v=11.0.0 的旧前端缓存一年，导致“服务器已升级但后台仍跑旧代码”。
  const cacheControl = "no-cache, max-age=0, must-revalidate";
  if (String(req.headers["if-none-match"] || "").split(",").map(v => v.trim()).includes(etag)) {
    res.writeHead(304, { ...BASE_HEADERS, "ETag":etag, "Cache-Control":cacheControl });
    return res.end();
  }
  return send(res, 200, def.type, buf, { "ETag":etag, "Cache-Control":cacheControl });
}


async function ensureUpstreamAssetImpl(kind, options = {}) {
  const spec = UPSTREAM_ASSETS[kind];
  if (!spec) throw new Error("unknown upstream asset: " + kind);
  const state = upstreamAssetState[kind];

  if (!options.force) {
    const cached = readCachedUpstreamAsset(kind);
    if (cached) return cached;
    const now = Date.now();
    if (UPSTREAM_RETRY_COOLDOWN_MS > 0 && state.lastError && state.lastAttemptAt &&
        now - state.lastAttemptAt < UPSTREAM_RETRY_COOLDOWN_MS) {
      const e = new Error("audited upstream " + kind + " repair is cooling down after previous failure");
      e.code = "UPSTREAM_COOLDOWN";
      e.retryAfterMs = Math.max(1, UPSTREAM_RETRY_COOLDOWN_MS - (now - state.lastAttemptAt));
      throw e;
    }
  }

  state.lastAttemptAt = Date.now();
  stats.upstreamAssetFetches += 1;
  try {
    const buf = await requestBuffer(
      spec.sourceUrl,
      { "User-Agent":USER_AGENT, "Accept":"text/plain, application/javascript;q=0.9, */*;q=0.1" },
      UPSTREAM_FETCH_TIMEOUT_MS,
      UPSTREAM_FETCH_MAX_BYTES
    );
    const check = validateUpstreamAssetBuffer(kind, buf);
    if (!check.ok) {
      const e = new Error("上游脚本完整性校验失败：" + check.error);
      e.code = "UPSTREAM_INTEGRITY_MISMATCH";
      throw e;
    }
    atomicWriteBuffer(upstreamAssetPath(kind), buf, 0o644);
    state.ready = true;
    state.source = "verified-upstream";
    state.lastSuccessAt = Date.now();
    state.lastError = "";
    return buf;
  } catch (e) {
    stats.upstreamAssetFailures += 1;
    state.ready = false;
    state.lastError = String(e && e.message || e);
    const fallback = readCachedUpstreamAsset(kind);
    if (fallback) {
      state.ready = true;
      state.source = "disk-cache-fallback";
      return fallback;
    }
    throw e;
  }
}

async function ensureUpstreamAsset(kind, options = {}) {
  const key = kind + ":" + (options.force ? "force" : "normal");
  if (upstreamAssetInFlight.has(key)) return upstreamAssetInFlight.get(key);
  const task = ensureUpstreamAssetImpl(kind, options);
  upstreamAssetInFlight.set(key, task);
  try {
    return await task;
  } finally {
    if (upstreamAssetInFlight.get(key) === task) upstreamAssetInFlight.delete(key);
  }
}

function upstreamAssetsStatus() {
  const out = {};
  for (const kind of Object.keys(UPSTREAM_ASSETS)) {
    const spec = UPSTREAM_ASSETS[kind];
    const file = upstreamAssetPath(kind);
    let disk = false;
    let valid = false;
    let actualSha = "";
    try {
      const buf = fs.readFileSync(file);
      disk = true;
      const check = validateUpstreamAssetBuffer(kind, buf);
      valid = check.ok;
      actualSha = check.actualSha || "";
    } catch {}
    out[kind] = {
      ready:valid || upstreamAssetState[kind].ready,
      cachedOnDisk:disk,
      valid,
      filename:spec.filename,
      expectedBlobSha:spec.expectedBlobSha,
      actualBlobSha:actualSha,
      expectedSize:spec.expectedSize,
      sourceUrl:spec.sourceUrl,
      runtime:{ ...upstreamAssetState[kind] }
    };
  }
  return out;
}

function publicUpstreamAssetsStatus() {
  const full = upstreamAssetsStatus();
  const out = {};
  for (const kind of Object.keys(full)) {
    const x = full[kind] || {};
    out[kind] = { ready:!!x.ready, cachedOnDisk:!!x.cachedOnDisk, valid:!!x.valid };
  }
  return out;
}

async function warmUpUpstreamAssets() {
  if (CLIENT_SCRIPT_SOURCE !== "self" || !UPSTREAM_PRELOAD) return;
  for (const kind of ["core", "qx"]) {
    try {
      await ensureUpstreamAsset(kind);
      console.log("upstream mirror: " + kind + " ready (" + upstreamAssetPath(kind) + ")");
    } catch (e) {
      console.warn("upstream mirror: " + kind + " preload failed: " + (e && e.message || e));
    }
  }
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

async function lookupIp2LocationUncached(ip) {
  const circuit = ipCircuitState();
  if (circuit.circuitOpen) {
    const e = new Error("IP2Location 暂时进入冷却保护，请使用手动地图定位或稍后重试");
    e.code = "IP2LOCATION_CIRCUIT_OPEN";
    e.retryAfterMs = circuit.retryAfterMs;
    throw e;
  }
  const base = new URL(IP2LOCATION_BASE_URL);
  base.searchParams.set("ip", ip);
  base.searchParams.set("format", "json");
  const headers = { Accept: "application/json", "User-Agent": USER_AGENT };
  if (IP2LOCATION_API_KEY) headers.Authorization = "Bearer " + IP2LOCATION_API_KEY;

  let lastErr;
  for (let attempt = 0; attempt < 2; attempt += 1) {
    try {
      stats.upstreamCalls += 1;
      const data = await requestJson(base.toString(), headers, IP2LOCATION_TIMEOUT_MS);
      if (data && data.error) {
        const msg = data.error.error_message || data.error.message || JSON.stringify(data.error);
        throw new Error("IP2Location: " + msg);
      }
      noteIpSuccess();
      return data;
    } catch (e) {
      lastErr = e;
      const transient = e.statusCode === 429 || (e.statusCode >= 500 && e.statusCode <= 599) || /timeout|ECONNRESET|EAI_AGAIN/i.test(e.message || "");
      if (!transient || attempt === 1) break;
      let delay = 350;
      if (e.retryAfter) {
        if (/^\d+$/.test(String(e.retryAfter))) {
          delay = Math.min(5000, Number(e.retryAfter) * 1000);
        } else {
          const when = Date.parse(String(e.retryAfter));
          if (Number.isFinite(when)) delay = Math.min(5000, Math.max(0, when - Date.now()));
        }
      }
      await sleep(delay);
    }
  }
  const finalErr = lastErr || new Error("IP2Location lookup failed");
  noteIpFailure(finalErr);
  throw finalErr;
}

function withNominatimSlot(fn) {
  const run = nominatimQueue.then(async () => {
    const wait = Math.max(0, 1100 - (Date.now() - lastNominatimCallAt));
    if (wait) await sleep(wait);
    lastNominatimCallAt = Date.now();
    return fn();
  }, async () => {
    const wait = Math.max(0, 1100 - (Date.now() - lastNominatimCallAt));
    if (wait) await sleep(wait);
    lastNominatimCallAt = Date.now();
    return fn();
  });
  // 队列只负责排序；单个请求失败不能让后续队列永久 rejected。
  nominatimQueue = run.catch(() => {});
  return run;
}

async function geocodeSearch(query) {
  const q = String(query || "").trim().slice(0, 300);
  if (!q) return [];
  const key = "search:" + q.toLowerCase();
  const cached = cacheMapGet(geoCache, key, GEO_CACHE_TTL_MS, "geocodeCacheHits");
  if (cached) return cached;
  if (!checkGeoRateLimit()) throw Object.assign(new Error("地址搜索过于频繁，请稍后再试"), { statusCode:429 });
  const u = new URL(NOMINATIM_BASE_URL + "/search");
  u.searchParams.set("format", "jsonv2"); u.searchParams.set("addressdetails", "0");
  u.searchParams.set("limit", "8"); u.searchParams.set("q", q);
  stats.geocodeCalls += 1;
  const raw = await withNominatimSlot(() => requestJson(u.toString(), { Accept:"application/json", "User-Agent":USER_AGENT }, 7000));
  const out = Array.isArray(raw) ? raw.map(it => ({
    lat:Number(it.lat), lon:Number(it.lon), display_name:String(it.display_name || "").slice(0, 700)
  })).filter(it => Number.isFinite(it.lat) && Number.isFinite(it.lon)).slice(0,8) : [];
  cacheMapPut(geoCache, key, out, GEO_CACHE_MAX);
  return out;
}

async function reverseGeocode(lat, lng) {
  const la = Number(lat), lo = Number(lng);
  if (!Number.isFinite(la) || !Number.isFinite(lo) || la < -90 || la > 90 || lo < -180 || lo > 180) return null;
  const key = "reverse:" + la.toFixed(5) + "," + lo.toFixed(5);
  const cached = cacheMapGet(geoCache, key, GEO_CACHE_TTL_MS, "geocodeCacheHits");
  if (cached) return cached;
  if (!checkGeoRateLimit()) return null;
  const u = new URL(NOMINATIM_BASE_URL + "/reverse");
  u.searchParams.set("format", "jsonv2"); u.searchParams.set("lat", String(la)); u.searchParams.set("lon", String(lo));
  u.searchParams.set("zoom", "18"); u.searchParams.set("addressdetails", "0");
  try {
    stats.geocodeCalls += 1;
    const raw = await withNominatimSlot(() => requestJson(u.toString(), { Accept:"application/json", "User-Agent":USER_AGENT }, 7000));
    const out = raw && raw.display_name ? { display_name:String(raw.display_name).slice(0,700), lat:la, lon:lo } : null;
    if (out) cacheMapPut(geoCache, key, out, GEO_CACHE_MAX);
    return out;
  } catch (e) { stats.geocodeErrors += 1; return null; }
}

async function fetchElevation(lat, lng) {
  const la = Number(lat), lo = Number(lng);
  if (!Number.isFinite(la) || !Number.isFinite(lo) || la < -90 || la > 90 || lo < -180 || lo > 180) return null;
  const key = "elev:" + la.toFixed(5) + "," + lo.toFixed(5);
  const cached = cacheMapGet(geoCache, key, 24 * 3600 * 1000, null);
  if (cached != null) return cached;
  const u = new URL(ELEVATION_BASE_URL);
  u.searchParams.set("latitude", String(la));
  u.searchParams.set("longitude", String(lo));
  try {
    stats.elevationCalls += 1;
    const d = await requestJson(u.toString(), { Accept:"application/json", "User-Agent":USER_AGENT }, 5000);
    const n = Number(d && d.elevation && d.elevation[0]);
    const out = Number.isFinite(n) ? Math.round(n) : null;
    if (out != null) cacheMapPut(geoCache, key, out, GEO_CACHE_MAX);
    return out;
  } catch { return null; }
}

async function resolveIp(ip) {
  const cached = cacheGet(ip);
  if (cached) return cached;
  stats.cacheMisses += 1;
  if (inFlight.has(ip)) return inFlight.get(ip);
  const promise = (async () => {
    const data = await lookupIp2LocationUncached(ip);
    const latitude = Number(data && data.latitude), longitude = Number(data && data.longitude);
    if (!Number.isFinite(latitude) || !Number.isFinite(longitude) || latitude < -90 || latitude > 90 || longitude < -180 || longitude > 180) {
      const invalid = new Error("IP2Location.io 没有返回有效经纬度");
      noteIpFailure(invalid);
      throw invalid;
    }
    let altitude = Number(data && data.elevation);
    if (!Number.isFinite(altitude)) altitude = await fetchElevation(latitude, longitude);
    const normalized = {
      ip: compactText(data.ip, 64) || ip,
      latitude, longitude,
      address: formatIpAddress(data),
      altitude: Number.isFinite(altitude) ? Math.round(altitude) : null,
      countryCode: compactText(data.country_code, 16), countryName: compactText(data.country_name, 160),
      regionName: compactText(data.region_name, 160), cityName: compactText(data.city_name, 160), zipCode: compactText(data.zip_code, 32),
      timeZone: compactText(data.time_zone, 64), asn: compactText(data.asn, 64), asName: compactText(data.as, 256),
      isProxy: data.is_proxy === true, cacheHit: false, source: "IP2Location.io"
    };
    cachePut(ip, normalized);
    return normalized;
  })().finally(() => inFlight.delete(ip));
  inFlight.set(ip, promise);
  return promise;
}

function mergeLookupIntoLoc(cur, lookup) {
  const next = { ...cur, enabled:true, latitude:lookup.latitude, longitude:lookup.longitude, address:lookup.address || "" };
  if (lookup.altitude != null) next.altitude = lookup.altitude;
  return normalizeLoc(next);
}

const LOGIN_PAGE = `<!doctype html><html lang="zh"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>定位选点登录</title><style>body{font-family:-apple-system,BlinkMacSystemFont,sans-serif;background:#f5f7fb;margin:0;display:grid;place-items:center;min-height:100vh}.card{width:min(92vw,420px);background:white;padding:28px;border-radius:16px;box-shadow:0 10px 35px rgba(0,0,0,.08)}h1{font-size:22px;margin:0 0 8px}p{color:#666;font-size:14px;line-height:1.5}input,button{box-sizing:border-box;width:100%;padding:12px 14px;font-size:16px;border-radius:10px}input{border:1px solid #ccd3df;margin:12px 0}button{border:0;background:#007aff;color:#fff;font-weight:650}.hint{font-size:12px;color:#888;margin-top:12px}</style></head><body><form class="card" method="post" action="/login"><h1>定位选点管理</h1><p>输入 .env 中的 TOKEN。登录成功后浏览器使用 HttpOnly 会话，地址栏不再长期携带 token。</p><input type="password" name="token" placeholder="TOKEN" autocomplete="current-password" required autofocus><button type="submit">登录</button><div class="hint">Loon / Shadowrocket 使用独立只读 CLIENT_TOKEN；后台管理 TOKEN 不再写入客户端配置。</div></form></body></html>`;

async function routeRequest(req, res) {
  const url = new URL(req.url, "http://" + (req.headers.host || "localhost"));
  if (req.method === "OPTIONS") return send(res, 204, "text/plain", "");

  // 管理后台本地静态资源：无 TOKEN、无用户数据，可公开缓存。
  if (req.method === "GET") {
    const staticDef = staticAssetDefinition(url.pathname);
    if (staticDef) return sendStaticFile(req, res, staticDef);
  }

  // Leaflet 仅作为可选增强，通过本机同源端点提供；首次请求/启动预热会从多个 CDN 拉取并校验固定 SHA-384。
  if ((url.pathname === "/assets/vendor/leaflet/leaflet.js" || url.pathname === "/assets/vendor/leaflet/leaflet.css") && req.method === "GET") {
    const kind = url.pathname.endsWith(".css") ? "css" : "js";
    const spec = LEAFLET_ASSETS[kind];
    try {
      const etag = '"sha384-' + spec.expectedSha384 + '"';
      const inm = String(req.headers["if-none-match"] || "").split(",").map(x => x.trim());
      if (inm.includes(etag)) {
        res.writeHead(304, { ...BASE_HEADERS, "ETag":etag, "Cache-Control":"public, max-age=31536000, immutable" });
        return res.end();
      }
      const buf = await ensureLeafletAsset(kind);
      return send(res, 200, spec.contentType, buf, {
        "Cache-Control":"public, max-age=31536000, immutable",
        "ETag":etag,
        "X-Vendor":"Leaflet/" + LEAFLET_VERSION
      });
    } catch (e) {
      return send(res, 503, "text/plain; charset=utf-8", "optional map component unavailable; manual coordinates remain available\n");
    }
  }

  // 已审计上游脚本镜像端点：不包含用户配置或 TOKEN，可公开读取。
  // 生成的客户端配置默认指向这里，手机端不再强依赖 GitHub Raw。
  if ((url.pathname === "/client/location-spoofer.js" || url.pathname === "/client/location-spoofer-qx.js") && req.method === "GET") {
    const kind = url.pathname.endsWith("-qx.js") ? "qx" : "core";
    try {
      const spec = UPSTREAM_ASSETS[kind];
      const etag = '"' + spec.expectedBlobSha + '"';
      const inm = String(req.headers["if-none-match"] || "").split(",").map(x => x.trim());
      if (inm.includes(etag)) {
        res.writeHead(304, { ...BASE_HEADERS, "ETag":etag, "Cache-Control":"public, max-age=86400, immutable" });
        return res.end();
      }
      const buf = await ensureUpstreamAsset(kind);
      return send(res, 200, "application/javascript; charset=utf-8", buf, {
        "Cache-Control":"public, max-age=86400, immutable",
        "ETag":etag,
        "X-Upstream-Repository":UPSTREAM_REPO,
        "X-Upstream-Commit":UPSTREAM_AUDITED_COMMIT,
        "X-Upstream-Git-Blob":spec.expectedBlobSha
      });
    } catch (e) {
      const requestId = crypto.randomBytes(6).toString("hex");
      console.error("client asset unavailable [" + requestId + "] " + kind + ": " + String(e && e.message || e));
      return send(res, 503, "text/plain; charset=utf-8",
        "audited upstream client script is temporarily unavailable\nrequestId=" + requestId + "\n");
    }
  }

  if (url.pathname === "/login" && req.method === "GET") {
    return send(res, 200, "text/html; charset=utf-8", LOGIN_PAGE, { "Content-Security-Policy":"default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; frame-ancestors 'none'" });
  }
  if (url.pathname === "/login" && req.method === "POST") {
    const ip = clientIp(req);
    if (!boundedWindowAllow(loginAttempts, ip, LOGIN_RATE_LIMIT, 10 * 60 * 1000)) {
      stats.loginsFailed += 1;
      return sendJson(res, 429, { error:"too many login attempts", retryAfterSeconds:600 });
    }
    try {
      const text = await readTextBody(req, 4096);
      const form = new URLSearchParams(text);
      const candidate = String(form.get("token") || "");
      if (!safeEqual(candidate, TOKEN)) {
        stats.loginsFailed += 1;
        return send(res, 403, "text/html; charset=utf-8", LOGIN_PAGE.replace("</form>", "<p style='color:#c00'>TOKEN 错误</p></form>"), { "Content-Security-Policy":"default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; frame-ancestors 'none'" });
      }
      loginAttempts.delete(ip); stats.loginsOk += 1;
      res.writeHead(303, { ...BASE_HEADERS, "Set-Cookie":sessionCookie(req, false), "Location":"/" });
      return res.end();
    } catch (e) { return sendJson(res, e.statusCode || 400, { error:e.message || "bad request" }); }
  }
  if (url.pathname === "/logout" && req.method === "POST") {
    if (!checkAdmin(req, url, res)) return;
    if (!enforceSameOrigin(req, res)) return;
    res.writeHead(303, { ...BASE_HEADERS, "Set-Cookie":sessionCookie(req, true), "Location":"/login" });
    return res.end();
  }

  // 兼容旧链接 /?token=...：验证后写入短期 HttpOnly 会话并立即清理地址栏 token。
  if ((url.pathname === "/" || url.pathname === "") && req.method === "GET" && url.searchParams.get("token")) {
    const q = url.searchParams.get("token") || "";
    if (!safeEqual(q, TOKEN)) return send(res, 403, "text/plain; charset=utf-8", "bad token");
    res.writeHead(303, { ...BASE_HEADERS, "Set-Cookie":sessionCookie(req, false), "Location":"/" });
    return res.end();
  }

  if (url.pathname === "/health" && req.method === "GET") {
    const cfg = readLocState();
    return sendJson(res, 200, {
      ok:true,
      version:APP_VERSION,
      configHealthy:cfg.valid && !configRecoveryStatus.degraded,
      configSource:configRecoveryStatus.degraded ? "degraded-default" : cfg.source,
      manualFallbackAvailable:true,
      clientScriptSource:CLIENT_SCRIPT_SOURCE,
      upstreamMirror:publicUpstreamAssetsStatus(),
      frontendAssets:{ local:localFrontendAssetsStatus(), leaflet:publicLeafletAssetsStatus() },
      uptimeSeconds:Math.floor((Date.now()-stats.startedAt)/1000)
    });
  }

  if (url.pathname === "/client/status" && req.method === "GET") {
    if (!checkAdmin(req, url, res)) return;
    return sendJson(res, 200, {
      ok:true,
      sourceMode:CLIENT_SCRIPT_SOURCE,
      preload:UPSTREAM_PRELOAD,
      cacheDir:UPSTREAM_CACHE_DIR,
      assets:upstreamAssetsStatus(),
      auditedRepository:UPSTREAM_REPO,
      auditedCommit:UPSTREAM_AUDITED_COMMIT
    });
  }

  if (url.pathname === "/client/preload" && req.method === "POST") {
    if (!checkAdmin(req, url, res)) return;
    if (!enforceSameOrigin(req, res)) return;
    const result = {};
    for (const kind of ["core","qx"]) {
      try {
        const buf = await ensureUpstreamAsset(kind, { force:true });
        result[kind] = { ok:true, bytes:buf.length, blobSha:gitBlobSha(buf) };
      } catch (e) {
        result[kind] = { ok:false, error:String(e && e.message || e) };
      }
    }
    const ok = Object.values(result).every(x => x.ok);
    return sendJson(res, ok ? 200 : 503, { ok, result, assets:upstreamAssetsStatus() });
  }

  if (url.pathname === "/status" && req.method === "GET") {
    if (!checkAdmin(req, url, res)) return;
    const statusLoc = readLoc(); // authenticated status may trigger safe recovery from backup/history
    const cfg = readLocState();
    return sendJson(res, 200, {
      ok:true, version:APP_VERSION, manualFallbackAvailable:true, ipLookup:ipCircuitState(),
      backupAvailable:fs.existsSync(BACKUP_FILE), historyCount:historyFiles().length,
      autoReverseGeocode:AUTO_REVERSE_GEOCODE, proxyMode:TRUST_PROXY_MODE_RAW,
      proxyTrustedForRequest:proxyHeadersTrusted(req), externalOrigin:canonicalExternalOrigin(req),
      publicOriginOverride:PUBLIC_ORIGIN || "",
      geoCacheEntries:geoCache.size, uptimeSeconds:Math.floor((Date.now()-stats.startedAt)/1000),
      configHealthy:cfg.valid && !configRecoveryStatus.degraded, configSource:configRecoveryStatus.degraded ? "degraded-default" : cfg.source, revision:cfg.valid ? cfg.revision : revisionOfLoc(statusLoc),
      recovery:{ ...configRecoveryStatus },
      envFile:{ loaded:ENV_STATE.loaded, name:path.basename(ENV_STATE.file), method:ENV_STATE.method },
      apiKeyConfigured:!!IP2LOCATION_API_KEY, host:HOST, port:PORT,
      frontend:{ localAssets:localFrontendAssetsStatus(), leaflet:leafletAssetsStatus() },
      legacyAdminQueryTokenAllowed:ALLOW_LEGACY_ADMIN_QUERY_TOKEN,
      upstream:{
        repository:UPSTREAM_REPO, auditedCommit:UPSTREAM_AUDITED_COMMIT, ref:UPSTREAM_REF,
        clientScriptSource:CLIENT_SCRIPT_SOURCE, mirror:upstreamAssetsStatus()
      }
    });
  }

  if (url.pathname === "/compat/upstream" && req.method === "GET") {
    if (!checkAdmin(req, url, res)) return;
    const loc = readLoc();
    const catalog = profileCatalog(req);
    const required = catalog.expectedRemoteFields;
    const missing = required.filter(k => !Object.prototype.hasOwnProperty.call(loc, k));
    const numericOk = Number.isFinite(Number(loc.latitude)) && Number.isFinite(Number(loc.longitude)) &&
      Number.isFinite(Number(loc.horizontalAccuracy)) && Number.isFinite(Number(loc.verticalAccuracy)) && Number.isFinite(Number(loc.altitude));
    return sendJson(res, 200, {
      ok: missing.length === 0 && numericOk,
      upstream:catalog,
      locJsonContract:{ missing, numericOk, enabledType:typeof loc.enabled, failOpenType:typeof loc.failOpen, debugType:typeof loc.debug },
      notes:[
        "V11 /loc.json 保持上游 location-spoofer.js 可直接 JSON.parse + merge + normalize 的扁平对象格式。",
        "动态客户端配置固定到已审计上游提交；默认还通过本机校验镜像提供脚本，减少手机客户端对 GitHub Raw 的依赖。",
        "Quantumult X 上游脚本当前不读取 configUrl，因此不宣称支持网页远程选点。",
        "上游 README 明确提到网页远程配置用于 Loon / Shadowrocket；Surge / Stash 生成配置复用同一主核心，但标为实验性，不作为已上游验证能力。",
        "上游主核心对远程配置有 5 分钟持久缓存：命中旧缓存时当前拦截先使用缓存并后台刷新，所以保存后可能需要再次触发定位才能看到最新值。"
      ]
    });
  }

  if (url.pathname === "/profiles" && req.method === "GET") {
    if (!checkAdmin(req, url, res)) return;
    return sendJson(res, 200, profileCatalog(req));
  }

  if (url.pathname === "/profiles/shadowrocket.sgmodule" && req.method === "GET") {
    if (!checkClientRead(req, url, res)) return;
    return sendGeneratedProfile(res, url, "ios-location-spoofer-remote.sgmodule", buildShadowrocketProfile, req);
  }
  if (url.pathname === "/profiles/surge.sgmodule" && req.method === "GET") {
    if (!checkClientRead(req, url, res)) return;
    return sendGeneratedProfile(res, url, "ios-location-spoofer-remote-surge.sgmodule", buildSurgeProfile, req);
  }
  if (url.pathname === "/profiles/ios-location-spoofer.lnplugin" && req.method === "GET") {
    if (!checkClientRead(req, url, res)) return;
    return sendGeneratedProfile(res, url, "ios-location-spoofer-remote.lnplugin", buildLoonProfile, req);
  }
  if (url.pathname === "/profiles/ios-location-spoofer.stoverride" && req.method === "GET") {
    if (!checkClientRead(req, url, res)) return;
    return sendGeneratedProfile(res, url, "ios-location-spoofer-remote.stoverride", buildStashProfile, req);
  }

  if (url.pathname === "/diagnostics/request" && req.method === "GET") {
    if (!checkAdmin(req, url, res)) return;
    const oc = originCheck(req);
    return sendJson(res, 200, {
      ok:true,
      remoteAddress:normalizeRemoteAddress(req.socket && req.socket.remoteAddress || ""),
      clientIp:clientIp(req),
      trustProxyMode:TRUST_PROXY_MODE_RAW,
      proxyHeadersTrusted:proxyHeadersTrusted(req),
      host:firstHeaderValue(req.headers.host),
      forwardedHost:firstHeaderValue(req.headers["x-forwarded-host"]),
      forwardedProto:firstHeaderValue(req.headers["x-forwarded-proto"]),
      forwardedPort:firstHeaderValue(req.headers["x-forwarded-port"]),
      origin:firstHeaderValue(req.headers.origin),
      expectedOrigin:canonicalExternalOrigin(req),
      publicOriginOverride:PUBLIC_ORIGIN || "",
      originCheck:oc
    });
  }

  if (url.pathname === "/diagnostics/selfcheck" && req.method === "GET") {
    if (!checkAdmin(req, url, res)) return;
    const checks = [];
    function add(name, ok, detail, severity) {
      checks.push({ name, ok:!!ok, detail:String(detail || ""), severity:severity || (ok ? "ok" : "error") });
    }

    const [nodeMajor, nodeMinor] = process.versions.node.split(".").map(Number);
    add("Node.js", nodeMajor > 20 || (nodeMajor === 20 && nodeMinor >= 12), process.versions.node);

    try {
      fs.accessSync(path.dirname(DATA_FILE), fs.constants.W_OK);
      add("数据目录", true, path.dirname(DATA_FILE) + " 可写");
    } catch (e) { add("数据目录", false, e.message); }

    let cfg = readLocState();
    if (!cfg.valid) {
      try { readLoc(); cfg = readLocState(); } catch {}
    }
    add("loc.json", cfg.valid && !configRecoveryStatus.degraded,
      (configRecoveryStatus.degraded ? "降级模式" : cfg.source) + (configRecoveryStatus.lastCorruptFile ? "；隔离 " + configRecoveryStatus.lastCorruptFile : ""),
      cfg.valid && !configRecoveryStatus.degraded ? "ok" : "warning");

    if (fs.existsSync(BACKUP_FILE)) {
      add("备份", !!readValidLocFile(BACKUP_FILE), BACKUP_FILE, readValidLocFile(BACKUP_FILE) ? "ok" : "warning");
    } else {
      add("备份", true, "尚无备份（首次保存前正常）", "info");
    }

    add("反向代理", !TRUST_PROXY || proxyHeadersTrusted(req),
      "TRUST_PROXY=" + TRUST_PROXY_MODE_RAW + "；externalOrigin=" + canonicalExternalOrigin(req),
      (!TRUST_PROXY || proxyHeadersTrusted(req)) ? "ok" : "warning");

    const oc = originCheck(req);
    add("Origin", oc.ok, oc.ok ? (oc.expected || "无浏览器 Origin") : (oc.received + " != " + oc.expected), oc.ok ? "ok" : "warning");
    const localFrontFiles = ["app.css","watchdog.js","app.js"];
    let localFrontOk = true;
    const localFrontDetail = [];
    for (const name of localFrontFiles) {
      const file = path.join(PUBLIC_DIR, name);
      try {
        const st = fs.statSync(file);
        const good = st.isFile() && st.size > 20;
        localFrontOk = localFrontOk && good;
        localFrontDetail.push(name + "=" + (good ? st.size + "B" : "invalid"));
      } catch { localFrontOk = false; localFrontDetail.push(name + "=missing"); }
    }
    add("后台本地前端资源", localFrontOk, localFrontDetail.join("；"), localFrontOk ? "ok" : "error");

    const leaflet = leafletAssetsStatus();
    const leafletReady = !!(leaflet.js && leaflet.js.valid && leaflet.css && leaflet.css.valid);
    add("可选地图组件", true, leafletReady ? "Leaflet 1.9.4 本机校验缓存已就绪" : "Leaflet 尚未缓存/网络不可用；这不会阻塞后台，手工经纬度仍可用", leafletReady ? "ok" : "info");

    const mirror = upstreamAssetsStatus();
    const coreMirrorOk = CLIENT_SCRIPT_SOURCE === "github" || (mirror.core && mirror.core.valid);
    add("客户端核心镜像", coreMirrorOk,
      CLIENT_SCRIPT_SOURCE === "github" ? "直接使用固定提交 GitHub Raw" :
      (coreMirrorOk ? ("Git blob 校验通过 " + mirror.core.expectedBlobSha.slice(0,12)) : "尚未预热或完整性校验失败；可运行 npm run preload:upstream"),
      coreMirrorOk ? "ok" : "warning");
    add("IP2Location", !ipCircuitState().circuitOpen,
      ipCircuitState().circuitOpen ? ("冷却中，剩余 " + Math.ceil(ipCircuitState().retryAfterMs/1000) + "s") : "可尝试；API Key " + (IP2LOCATION_API_KEY ? "已配置" : "未配置/keyless"),
      ipCircuitState().circuitOpen ? "warning" : "ok");
    add("手动定位兜底", true, "即使外部 API/地图失败，latitude/longitude 仍可直接保存");

    const compatLoc = readLoc();
    const compatFields = ["enabled","latitude","longitude","horizontalAccuracy","verticalAccuracy","altitude","failOpen","debug"];
    const compatMissing = compatFields.filter(k => !Object.prototype.hasOwnProperty.call(compatLoc, k));
    const compatNumeric = ["latitude","longitude","horizontalAccuracy","verticalAccuracy","altitude"].every(k => Number.isFinite(Number(compatLoc[k])));
    add("上游配置契约", compatMissing.length === 0 && compatNumeric,
      "mekos2772@" + UPSTREAM_AUDITED_COMMIT.slice(0,12) + "；missing=" + (compatMissing.join(",") || "none") + "；numeric=" + compatNumeric,
      compatMissing.length === 0 && compatNumeric ? "ok" : "error");

    const criticalFailed = checks.some(c => !c.ok && c.severity === "error");
    return sendJson(res, criticalFailed ? 503 : 200, {
      ok:!criticalFailed, version:APP_VERSION, checks,
      revision:cfg.valid ? cfg.revision : revisionOfLoc(readLoc()),
      historyCount:historyFiles().length
    });
  }

  if (url.pathname === "/history" && req.method === "GET") {
    if (!checkAdmin(req, url, res)) return;
    return sendJson(res, 200, { items:listHistory(url.searchParams.get("limit")) });
  }

  if (url.pathname === "/restore-history" && req.method === "POST") {
    if (!checkAdmin(req, url, res)) return;
    if (!enforceSameOrigin(req, res)) return;
    try {
      const j = await readJsonBody(req);
      const restored = await withWriteLock(() => restoreHistory(j.id, j.ifRevision));
      return sendJson(res, 200, { ...restored, _revision:revisionOfLoc(restored) });
    } catch (e) {
      return sendJson(res, e.statusCode || 400, {
        error:e.message || "history restore failed", code:e.code || undefined,
        currentRevision:e.currentRevision || undefined
      });
    }
  }

  if (url.pathname === "/geocode" && req.method === "GET") {
    if (!checkAdmin(req, url, res)) return;
    try { return sendJson(res, 200, { results:await geocodeSearch(url.searchParams.get("q") || "") }); }
    catch (e) { stats.geocodeErrors += 1; return sendJson(res, e.statusCode || 502, { error:e.message || "geocode failed", manualFallback:true }); }
  }

  if (url.pathname === "/reverse-geocode" && req.method === "GET") {
    if (!checkAdmin(req, url, res)) return;
    const la=Number(url.searchParams.get("lat")), lo=Number(url.searchParams.get("lng"));
    if (!Number.isFinite(la)||!Number.isFinite(lo)||la<-90||la>90||lo<-180||lo>180) return sendJson(res,400,{error:"bad coords"});
    const result = AUTO_REVERSE_GEOCODE ? await reverseGeocode(la, lo) : null;
    return sendJson(res, 200, { result });
  }

  if (url.pathname === "/elevation" && req.method === "GET") {
    if (!checkAdmin(req, url, res)) return;
    const la=Number(url.searchParams.get("lat")), lo=Number(url.searchParams.get("lng"));
    if (!Number.isFinite(la)||!Number.isFinite(lo)||la<-90||la>90||lo<-180||lo>180) return sendJson(res,400,{error:"bad coords"});
    return sendJson(res, 200, { elevation:await fetchElevation(la, lo) });
  }

  if (url.pathname === "/loc.json" && req.method === "GET") {
    if (!checkClientRead(req, url, res)) return;
    const admin = isAdminAuthenticated(req);
    const loc = readLoc();
    const revision = revisionOfLoc(loc);
    // 配置文件损坏且 backup/history 都不可恢复时，手机客户端不能收到 200 + Apple Park 默认值；
    // 否则远程配置会覆盖模块内“最近已知位置” fallback。管理会话仍可读取默认表单并手动重新保存修复。
    if (configRecoveryStatus.degraded && !admin) {
      return send(res, 503, "text/plain; charset=utf-8",
        "location configuration unavailable; repair it in the admin UI\n",
        { "X-Config-Degraded":"1" });
    }
    return send(res, 200, "application/json; charset=utf-8", JSON.stringify(loc), {
      "ETag": '"' + revision + '"',
      "X-Config-Revision": revision,
      ...(configRecoveryStatus.degraded ? { "X-Config-Degraded":"1" } : {})
    });
  }

  if (url.pathname === "/metrics" && req.method === "GET") {
    if (!checkAdmin(req, url, res)) return;
    return sendJson(res, 200, {
      ...stats, cacheEntries:lookupCache.size, geoCacheEntries:geoCache.size, inFlight:inFlight.size,
      rateLimitClients:ipRateClients.size, rateLimitPerClientPerMinute:IP_LOOKUP_RATE_LIMIT, cacheTtlMs:IP2LOCATION_CACHE_TTL_MS,
      ipUpstream: ipCircuitState(), failureThreshold:IP2LOCATION_FAILURE_THRESHOLD,
      cooldownMs:IP2LOCATION_COOLDOWN_MS, manualFallbackAvailable:true,
      historyCount:historyFiles().length, historyMax:HISTORY_MAX, proxyMode:TRUST_PROXY_MODE_RAW,
      clientScriptSource:CLIENT_SCRIPT_SOURCE, upstreamMirror:upstreamAssetsStatus(), leaflet:leafletAssetsStatus()
    });
  }

  if (url.pathname === "/ip-lookup" && (req.method === "GET" || req.method === "POST")) {
    if (!checkAdmin(req, url, res)) return;
    if (req.method === "POST" && !enforceSameOrigin(req, res)) return;
    if (!checkRateLimit(clientIp(req))) {
      return sendJson(res, 429, manualFallbackPayload("IP 查询过于频繁，请稍后再试；手动地图定位仍可正常使用", { error:"rate limited" }));
    }
    try {
      const body = req.method === "POST" ? await readJsonBody(req) : {};
      const ip = String(body.ip || url.searchParams.get("ip") || "").trim();

      // GET 永远只读预览。写入只能通过 POST，防止带 token 的链接/预取/爬虫误改定位。
      const applyField = req.method === "POST" ? optionalBooleanField(body, "apply") : undefined;
      const apply = req.method === "POST" && (applyField === true);
      const ifRevision = req.method === "POST" ? String(body.ifRevision || "") : "";

      if (!net.isIP(ip)) return sendJson(res, 400, { error:"invalid ip", message:"请输入有效的 IPv4 或 IPv6 地址", manualFallback:true, fallbackMode:"manual-map" });
      if (!IP_LOOKUP_ALLOW_SPECIAL && isSpecialIp(ip)) return sendJson(res, 400, { error:"special ip", message:"私有、保留、回环或文档地址通常没有可用公网地理位置；可直接改用手动地图定位", manualFallback:true, fallbackMode:"manual-map" });

      const lookup = await resolveIp(ip);
      let location;
      let revision;

      if (apply) {
        const result = await withWriteLock(() => {
          const cur = readLoc();
          const candidate = mergeLookupIntoLoc(cur, lookup);
          const saved = writeLoc(candidate, { expectedRevision:ifRevision });
          writeMeta({ source:"IP2Location.io", appliedAt:new Date().toISOString(), queryIp:ip, lookup });
          return { location:saved, revision:revisionOfLoc(saved) };
        });
        location = result.location;
        revision = result.revision;
      } else {
        const cur = readLoc();
        location = mergeLookupIntoLoc(cur, lookup);
        revision = revisionOfLoc(cur);
      }

      return sendJson(res, 200, { saved:apply, location, lookup, revision, previewOnly:req.method === "GET" });
    } catch (e) {
      stats.lookupErrors += 1;
      if (e && e.code === "REVISION_CONFLICT") {
        return sendJson(res, 409, {
          error:e.message, code:e.code, currentRevision:e.currentRevision,
          manualFallback:true, fallbackMode:"manual-map"
        });
      }
      const status = e && e.code === "IP2LOCATION_CIRCUIT_OPEN" ? 503 : 502;
      return sendJson(res, status, manualFallbackPayload(e.message || "IP 查询失败"));
    }
  }

  if (url.pathname === "/set" && req.method === "POST") {
    if (!checkAdmin(req, url, res)) return;
    if (!enforceSameOrigin(req, res)) return;
    try {
      const j = await readJsonBody(req);
      const laRaw = j.lat !== undefined ? j.lat : j.latitude;
      const loRaw = j.lng !== undefined ? j.lng : j.longitude;
      const la = Number(laRaw), lo = Number(loRaw);
      if (!Number.isFinite(la) || la < -90 || la > 90) throw badField("latitude", "latitude 必须位于 -90..90");
      if (!Number.isFinite(lo) || lo < -180 || lo > 180) throw badField("longitude", "longitude 必须位于 -180..180");
      const patch = { enabled:true, latitude:la, longitude:lo };
      if (Object.prototype.hasOwnProperty.call(j,"address")) patch.address = String(j.address || "").trim().slice(0,512);
      const altitude = optionalNumberField(j, "altitude", -12000, 100000, true);
      const hacc = optionalNumberField(j, "horizontalAccuracy", 0, 1000000, true);
      const vacc = optionalNumberField(j, "verticalAccuracy", 0, 1000000, true);
      const failOpen = optionalBooleanField(j, "failOpen");
      const debug = optionalBooleanField(j, "debug");
      if (altitude !== undefined) patch.altitude = altitude;
      if (hacc !== undefined) patch.horizontalAccuracy = hacc;
      if (vacc !== undefined) patch.verticalAccuracy = vacc;
      if (failOpen !== undefined) patch.failOpen = failOpen;
      if (debug !== undefined) patch.debug = debug;
      const saved = await withWriteLock(() => {
        // 在锁内重新读取，避免等待写锁期间配置已变化；只覆盖本次请求显式提交的字段。
        const latest = readLoc();
        assertRevision(j.ifRevision, latest);
        const merged = { ...latest, ...patch };
        const out = writeLoc(merged, { expectedRevision:j.ifRevision });
        stats.manualSaves += 1;
        writeMeta({ source:String(j.source || "manual-map").slice(0,64), appliedAt:new Date().toISOString() });
        return out;
      });
      return sendJson(res, 200, { ...saved, _revision:revisionOfLoc(saved) });
    } catch (e) {
      return sendJson(res, e.statusCode || 400, {
        error:e.message || "bad json", code:e.code || undefined,
        currentRevision:e.currentRevision || undefined
      });
    }
  }

  if (url.pathname === "/enable" && req.method === "POST") {
    if (!checkAdmin(req, url, res)) return;
    if (!enforceSameOrigin(req, res)) return;
    try {
      const j = await readJsonBody(req);
      const enabled = optionalBooleanField(j, "enabled");
      if (enabled === undefined) throw badField("enabled", "enabled 为必填 true/false");
      const saved = await withWriteLock(() => {
        const cur = readLoc();
        assertRevision(j.ifRevision, cur);
        cur.enabled = enabled;
        return writeLoc(cur, { expectedRevision:j.ifRevision });
      });
      return sendJson(res, 200, { ...saved, _revision:revisionOfLoc(saved) });
    } catch (e) {
      return sendJson(res, e.statusCode || 400, {
        error:e.message || "bad json", code:e.code || undefined,
        currentRevision:e.currentRevision || undefined
      });
    }
  }

  if (url.pathname === "/rollback" && req.method === "POST") {
    if (!checkAdmin(req, url, res)) return;
    if (!enforceSameOrigin(req, res)) return;
    try {
      const j = await readJsonBody(req);
      const restored = await withWriteLock(() => rollbackLoc(j.ifRevision));
      return sendJson(res, 200, { ...restored, _revision:revisionOfLoc(restored) });
    } catch (e) {
      return sendJson(res, e.statusCode || 400, {
        error:e.message || "rollback failed", code:e.code || undefined,
        currentRevision:e.currentRevision || undefined
      });
    }
  }

  if ((url.pathname === "/" || url.pathname === "") && req.method === "GET") {
    if (!isAdminAuthenticated(req)) {
      res.writeHead(303, { ...BASE_HEADERS, "Location":"/login" });
      return res.end();
    }
    return send(res, 200, "text/html; charset=utf-8", PAGE, { "Content-Security-Policy": PAGE_CSP });
  }

  if (url.pathname === "/favicon.ico") return send(res, 204, "text/plain", "");
  return send(res, 404, "text/plain; charset=utf-8", "not found");
}

function requestTargetForLog(rawUrl) {
  // 查询参数可能包含 CLIENT_TOKEN；错误日志只记录 path，避免异常路径把令牌写进日志。
  try { return new URL(String(rawUrl || "/"), "http://localhost").pathname; }
  catch { return String(rawUrl || "/").split("?", 1)[0]; }
}

async function handler(req, res) {
  try {
    return await routeRequest(req, res);
  } catch (e) {
    stats.unexpectedErrors += 1;
    const requestId = crypto.randomBytes(6).toString("hex");
    console.error("request error [" + requestId + "] " + req.method + " " + requestTargetForLog(req.url) + ": " + (e && e.stack || e));
    if (res.headersSent) {
      try { res.end(); } catch {}
      return;
    }
    return sendJson(res, e && e.statusCode || 500, {
      error: e && e.statusCode && e.statusCode < 500 ? String(e.message || "request failed") : "internal server error",
      code: e && e.code || "INTERNAL_ERROR",
      requestId
    });
  }
}

function onListenError(err) {
  if (err.code === "EADDRINUSE") console.error("启动失败：端口 " + PORT + " 已被占用");
  else if (err.code === "EACCES") console.error("启动失败：没有权限监听端口 " + PORT);
  else console.error("启动失败：" + err.message);
  process.exit(1);
}

function start() {
  // V11 宝塔版固定由 Node 提供本机 HTTP，由 Nginx 终止公网 HTTPS。
  // 这样 .env 不再出现 CERT/KEY，两套证书配置不会互相打架。
  const server = http.createServer(handler);
  server.on("error", onListenError);
  server.keepAliveTimeout = 65000;
  server.headersTimeout = 70000;
  server.requestTimeout = 15000;
  const sockets = new Set();
  server.on("connection", socket => { sockets.add(socket); socket.on("close", () => sockets.delete(socket)); });
  server.listen(PORT, HOST, () => {
    console.log("location picker v11 listening on " + HOST + ":" + PORT + " (http; HTTPS should terminate at Nginx)");
    console.log("config: " + (ENV_STATE.loaded ? ("loaded " + path.basename(ENV_STATE.file) + " via " + ENV_STATE.method) : "no .env found; using system environment only"));
    if (HOST === "127.0.0.1" || HOST === "::1") console.log("security: loopback-only binding enabled; use Nginx reverse proxy for public access");
    console.log("proxy: TRUST_PROXY=" + TRUST_PROXY_MODE_RAW + " (true=仅信任本机回环反代，all=信任任意直接上游)");
    console.log("client scripts: source=" + CLIENT_SCRIPT_SOURCE + (CLIENT_SCRIPT_SOURCE === "self" ? ("; verified mirror cache=" + UPSTREAM_CACHE_DIR) : "; pinned GitHub Raw"));
    if (UPSTREAM_REF === "main" && CLIENT_SCRIPT_SOURCE === "self") {
      console.warn("兼容提示：UPSTREAM_REF=main 通常会与固定 blob SHA 校验不匹配；生产建议锁定审计提交，或同时更新 UPSTREAM_*_BLOB_SHA/SIZE。");
    }
    if (TRUST_PROXY && !TRUST_PROXY_ALL && !(HOST === "127.0.0.1" || HOST === "::1")) {
      console.warn("安全提示：HOST 不是回环地址且 TRUST_PROXY=true；仅来自回环地址的 X-Forwarded-* 会被信任。若确有独立反代主机，请明确使用 TRUST_PROXY=all 并配置防火墙。");
    }
    warmUpUpstreamAssets().catch(e => console.warn("upstream mirror warm-up failed: " + (e && e.message || e)));
    warmUpLeafletAssets().catch(e => console.warn("leaflet vendor warm-up failed: " + (e && e.message || e)));
  });
  let closing = false;
  function shutdown(signal) {
    if (closing) return; closing = true;
    console.log("shutdown: " + signal);
    server.close(() => process.exit(0));
    setTimeout(() => { for (const socket of sockets) socket.destroy(); process.exit(1); }, 5000).unref();
  }
  process.once("SIGTERM", () => shutdown("SIGTERM"));
  process.once("SIGINT", () => shutdown("SIGINT"));
  return server;
}

const PAGE = `<!doctype html>
<html lang="zh">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<title>定位选点 V11</title>
<link rel="stylesheet" href="/assets/app.css?v=${FRONTEND_BUILD_ID}">
<script defer src="/assets/watchdog.js?v=${FRONTEND_BUILD_ID}"></script>
<script defer src="/assets/app.js?v=${FRONTEND_BUILD_ID}"></script>
</head>
<body>
<noscript><div class="noscript">此后台需要 JavaScript。当前浏览器禁用了 JavaScript，因此无法操作定位配置。</div></noscript>
<div class="top"><strong>定位选点 V11</strong><div class="actions"><button id="refreshstatus" type="button">刷新状态</button><button id="historybtn" type="button">历史版本</button><button id="selfcheckbtn" type="button">系统自检</button><button id="clientbtn" type="button">客户端配置</button><button id="diagbtn" type="button">反代诊断</button><button id="logoutbtn" type="button">退出登录</button></div></div>
<div class="statusline" id="statusline">前端启动中…若数秒后仍无变化，请检查本地 /assets/app.js；地图/CDN 不会阻塞后台核心。</div>
<div class="bar">
  <input id="q" placeholder="搜地名，回车列出候选（只预览，不改定位）">
  <button id="locatebtn" disabled>当前位置</button>
  <button id="btn">搜</button>
</div>
<div class="bar">
  <input id="ipq" placeholder="输入 IPv4 / IPv6，例如 8.8.8.8" autocapitalize="off" autocomplete="off" spellcheck="false">
  <button id="ippreviewbtn" disabled>IP 查询预览</button>
  <button id="ipapplybtn" disabled>IP 查询并写入</button>
</div>
<div class="attribution">IP 快捷定位：<a href="https://www.ip2location.io" target="_blank" rel="noopener noreferrer">IP2Location.io</a>；地址搜索/反向地址：<a href="https://nominatim.openstreetmap.org" target="_blank" rel="noopener noreferrer">OpenStreetMap Nominatim</a>。地图组件/API 任一不可用时，<b>手工 latitude / longitude 保存仍保持可用</b>。</div>
<div class="modebox" id="modebox"><b>定位模式：</b><span id="modetext">等待前端主程序启动…</span><button id="manualmodebtn" type="button">切换手动定位</button></div>
<div class="ipmeta" id="ipmeta"></div>
<div class="results" id="results"></div>
<div id="map" class="map-unavailable"><div class="mapmsg">地图属于可选增强，后台核心启动后再异步加载。</div></div>
<div id="info">等待配置读取…</div>
<div class="opts">
  <label>latitude<input id="latmanual" type="number" inputmode="decimal" step="any"></label>
  <label>longitude<input id="lngmanual" type="number" inputmode="decimal" step="any"></label>
  <button id="coordbtn" class="coordbtn" type="button">应用经纬度</button>
  <label class="wide">address<input id="address" type="text" placeholder="IP 查询后自动填充，也可手动修改"></label>
  <label>海拔 altitude(米)<input id="alt" type="number" inputmode="numeric"></label>
  <label>水平精度 horizontalAccuracy<input id="hacc" type="number" inputmode="numeric"></label>
  <label>垂直精度 verticalAccuracy<input id="vacc" type="number" inputmode="numeric"></label>
  <label class="check"><input id="failopen" type="checkbox"> failOpen</label>
  <label class="check"><input id="debug" type="checkbox"> debug</label>
  <button id="savebtn" disabled>保存定位</button>
  <button id="rollbackbtn" disabled>撤销上次保存</button>
  <button id="restorebtn" disabled>恢复真实定位</button>
  <button id="favadd">收藏此点</button>
  <button id="favlistbtn">我的收藏</button>
</div>
<div class="results" id="favs"></div>
<div class="modalback" id="historymodal"><div class="modal"><button class="closebtn" id="historyclose" type="button">关闭</button><h3>历史版本</h3><div id="historylist">尚未读取</div></div></div>
<div class="modalback" id="clientmodal"><div class="modal"><button class="closebtn" id="clientclose" type="button">关闭</button><h3>客户端配置（锁定已审计上游版本）</h3><div id="clientlist">尚未读取</div></div></div>
<div class="toast" id="toast"></div>
</body>
</html>`;


if (require.main === module) start();
module.exports = {
  handler, start, readLoc, readLocState, writeLoc, rollbackLoc, normalizeLoc, revisionOfLoc, currentRevision,
  isSpecialIp, ipCircuitState, geocodeSearch, reverseGeocode, fetchElevation,
  canonicalExternalOrigin, originCheck, proxyHeadersTrusted, clientIp, remoteConfigUrl,
  buildShadowrocketProfile, buildSurgeProfile, buildLoonProfile, buildStashProfile, profileCatalog,
  listHistory, restoreHistory, withWriteLock, gitBlobSha, validateUpstreamAssetBuffer,
  ensureUpstreamAsset, upstreamAssetsStatus, clientScriptUrl, effectiveClientScriptSource, UPSTREAM_ASSETS,
  ensureLeafletAsset, leafletAssetsStatus, validateLeafletAssetBuffer, localFrontendAssetsStatus, LEAFLET_ASSETS, requestBuffer
};
