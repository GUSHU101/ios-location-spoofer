(function(){
  "use strict";
  window.__LP_BOOT_OK = false;
  window.__LP_RUNTIME_ERROR = false;

  function text(id, value){
    var el=document.getElementById(id);
    if(el) el.textContent=value;
  }
  function renderFailure(message){
    text("statusline", message);
    var mode=document.getElementById("modebox");
    if(mode) mode.className="modebox error";
    text("modetext", "前端启动异常；请刷新页面并检查 /assets/app.js、/assets/app.css 是否 HTTP 200，或在服务器运行 npm run selfcheck。主程序未启动前不会执行任何保存操作。");
  }
  function fail(message){
    window.__LP_RUNTIME_ERROR = true;
    renderFailure(message);
  }
  function cleanMessage(value){
    return String(value||"未知前端错误").replace(/[\r\n]+/g," ").slice(0,180);
  }

  window.addEventListener("error", function(ev){
    // 主 app.js 本地资源若 404/网络失败，立即给出诊断；不要把可选地图瓦片失败误判为后台启动失败。
    var target=ev&&ev.target;
    if(target&&target.tagName==="SCRIPT"&&target.src&&/\/assets\/app\.js(?:[?#]|$)/.test(target.src)){
      fail("后台主程序资源加载失败：/assets/app.js。请检查部署文件和 Nginx 反代。 ");
      return;
    }
    if(!ev || !ev.error) return;
    fail("前端 JavaScript 运行异常："+cleanMessage(ev.error.message||ev.message));
  }, true);
  window.addEventListener("unhandledrejection", function(ev){
    var reason=ev&&ev.reason;
    fail("前端异步运行异常："+cleanMessage(reason&&reason.message||reason));
  });

  // 关键：不能等待 DOMContentLoaded。defer 的 app.js 如果网络请求一直 Pending，
  // DOMContentLoaded 本身也会被推迟；若把 watchdog 挂在 DOMContentLoaded 上，就无法发现“app.js 一直加载中”。
  // watchdog.js 排在 app.js 前且同为 defer，文档解析完成后会先执行，因此这里直接开始独立计时。
  window.__LP_WATCHDOG_TIMER=setTimeout(function(){
    if(!window.__LP_BOOT_OK){
      fail("前端主程序未在 6 秒内启动。后台没有继续等待第三方资源；请检查 /assets/app.js 是否 HTTP 200，并执行 npm run selfcheck。");
    }
  },6000);

  // 极端情况下元素尚不可见时，DOMContentLoaded 后仅重新渲染已有错误；不把计时器依赖于该事件。
  document.addEventListener("DOMContentLoaded", function(){
    if(window.__LP_RUNTIME_ERROR && !window.__LP_BOOT_OK){
      renderFailure("前端主程序启动失败。请检查本地静态资源并运行 npm run selfcheck。");
    }
  }, {once:true});
})();
