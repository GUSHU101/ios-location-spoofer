"use strict";
window.__LP_APP_VERSION="11.0.0";

function apiUrl(path){return path;}
function apiFetch(path,options){
  options=options||{};
  var timeoutMs=Number(options.timeoutMs||8000);
  var fetchOptions={};
  Object.keys(options).forEach(function(k){if(k!=="timeoutMs")fetchOptions[k]=options[k];});
  if(typeof AbortController==="undefined"||fetchOptions.signal||!Number.isFinite(timeoutMs)||timeoutMs<=0){
    return fetch(apiUrl(path),fetchOptions);
  }
  var ctrl=new AbortController();
  fetchOptions.signal=ctrl.signal;
  var timer=setTimeout(function(){ctrl.abort();},timeoutMs);
  return fetch(apiUrl(path),fetchOptions).finally(function(){clearTimeout(timer);});
}
function apiJson(path,options){
  return apiFetch(path,options).then(function(r){
    return r.text().then(function(text){
      var data={};try{data=text?JSON.parse(text):{};}catch(e){data={message:text||("HTTP "+r.status)};}
      if(!r.ok){
        var err=new Error(data.message||data.error||("HTTP "+r.status));
        err.status=r.status;err.data=data;throw err;
      }
      return data;
    });
  });
}
function errorDetail(err){
  if(!err)return "未知错误";
  var d=err.data||{};
  var parts=[];
  if(err.status)parts.push("HTTP "+err.status);
  if(d.code)parts.push(d.code);
  parts.push(d.message||d.error||err.message||"请求失败");
  if(d.expectedOrigin&&d.receivedOrigin)parts.push("Origin: "+d.receivedOrigin+" → 期望 "+d.expectedOrigin);
  return parts.join(" · ");
}

var GCJ = (function(){
  var PI = Math.PI, a = 6378245.0, ee = 0.00669342162296594323;
  function outOfChina(lat,lng){return (lng<72.004||lng>137.8347)||(lat<0.8293||lat>55.8271);}
  function tLat(x,y){
    var r=-100.0+2.0*x+3.0*y+0.2*y*y+0.1*x*y+0.2*Math.sqrt(Math.abs(x));
    r+=(20.0*Math.sin(6.0*x*PI)+20.0*Math.sin(2.0*x*PI))*2.0/3.0;
    r+=(20.0*Math.sin(y*PI)+40.0*Math.sin(y/3.0*PI))*2.0/3.0;
    r+=(160.0*Math.sin(y/12.0*PI)+320*Math.sin(y*PI/30.0))*2.0/3.0;return r;
  }
  function tLng(x,y){
    var r=300.0+x+2.0*y+0.1*x*x+0.1*x*y+0.1*Math.sqrt(Math.abs(x));
    r+=(20.0*Math.sin(6.0*x*PI)+20.0*Math.sin(2.0*x*PI))*2.0/3.0;
    r+=(20.0*Math.sin(x*PI)+40.0*Math.sin(x/3.0*PI))*2.0/3.0;
    r+=(150.0*Math.sin(x/12.0*PI)+300.0*Math.sin(x/30.0*PI))*2.0/3.0;return r;
  }
  function wgs2gcj(lat,lng){
    if(outOfChina(lat,lng))return [lat,lng];
    var dLat=tLat(lng-105.0,lat-35.0), dLng=tLng(lng-105.0,lat-35.0);
    var radLat=lat/180.0*PI, m=Math.sin(radLat); m=1-ee*m*m; var sm=Math.sqrt(m);
    dLat=(dLat*180.0)/((a*(1-ee))/(m*sm)*PI);
    dLng=(dLng*180.0)/(a/sm*Math.cos(radLat)*PI);
    return [lat+dLat,lng+dLng];
  }
  function gcj2wgs(lat,lng){
    if(outOfChina(lat,lng))return [lat,lng];
    var wlat=lat, wlng=lng;
    for(var i=0;i<3;i++){var g=wgs2gcj(wlat,wlng);wlat+=lat-g[0];wlng+=lng-g[1];}
    return [wlat,wlng];
  }
  return {wgs2gcj:wgs2gcj,gcj2wgs:gcj2wgs};
})();

var map, marker;
var WGS={lat:NaN,lng:NaN};
var datum="gcj";
var saved=true;
var enabledState=true;
var locationMode="manual";
var lastIpError="";
var configRevision="";
var mapReady=false;
var configLoaded=false;
var mapEngineLoaded=false;
var mapInitAttempted=false;
var derivedSeq=0;
var derivedTimer=null;

function $(id){return document.getElementById(id);}
function toast(t){var e=$("toast");e.textContent=t;e.classList.add("show");setTimeout(function(){e.classList.remove("show");},2200);}
function numOrNull(id){var v=$(id).value.trim();return v===""?null:Number(v);}
function wrapLng(lng){return ((((Number(lng)+180)%360)+360)%360)-180;}
function mapUsable(){return !!(mapReady&&map&&marker);}
function updateSaveAvailability(){var b=$("savebtn");if(b)b.disabled=!hasUsableCoords();}
function moveMapToCurrent(zoom){
  if(!mapUsable()||!Number.isFinite(Number(WGS.lat))||!Number.isFinite(Number(WGS.lng)))return false;
  var p=dispPos();marker.setLatLng(p);map.setView(p,zoom||15);return true;
}
function updateRevisionFrom(data){
  if(data&&data._revision)configRevision=String(data._revision);
  else if(data&&data.revision)configRevision=String(data.revision);
}
function handleRevisionError(err){
  var d=err&&err.data||{};
  if(err&&err.status===409&&d.code==="REVISION_CONFLICT"){
    if(d.currentRevision)configRevision=String(d.currentRevision);
    toast("配置已在其他页面被修改，请刷新状态或重新载入后再保存");
    refreshStatus();
    return true;
  }
  return false;
}

function syncCoordInputs(){
  if(Number.isFinite(WGS.lat))$("latmanual").value=Number(WGS.lat).toFixed(6);
  if(Number.isFinite(WGS.lng))$("lngmanual").value=Number(WGS.lng).toFixed(6);
}

function setMode(mode,message,severity){
  locationMode=mode||"manual";
  var box=$("modebox"), text=$("modetext");
  box.className="modebox"+(severity?" "+severity:(locationMode==="manual"?" manual":""));
  text.textContent=message||(locationMode==="ip"?"IP2Location 快捷定位":"手动地图定位");
  if(map&&map.getContainer){
    if(locationMode==="manual")map.getContainer().classList.add("manual-focus");
    else map.getContainer().classList.remove("manual-focus");
  }
}

function enterManualFallback(message){
  lastIpError=String(message||"IP2Location 暂时不可用");
  setMode("manual",lastIpError+"；已自动切换为手动地图定位。可搜索地点、点击地图、拖动图钉或直接输入经纬度，然后保存。","error");
  try{$("q").focus();}catch(e){}
}

function enterManualMode(message){
  setMode("manual",message||"手动地图定位：搜索地点后点地图放置图钉，或拖动图钉 / 直接填写经纬度。","manual");
}

function setLocateBusy(busy){
  var b=$("locatebtn");
  b.disabled=!!busy;
  b.textContent=busy?"定位中…":"当前位置";
}

function setIpBusy(busy){
  var p=$("ippreviewbtn"), a=$("ipapplybtn");
  p.disabled=!!busy;a.disabled=!!busy;
  p.textContent=busy?"查询中…":"IP 查询预览";
  a.textContent=busy?"处理中…":"IP 查询并写入";
}

function geolocationErrorMessage(err){
  if(err&&err.code===1)return "定位权限被拒绝，请在 Safari 设置中允许定位";
  if(err&&err.code===2)return "暂时无法获取当前位置";
  if(err&&err.code===3)return "获取当前位置超时，请到开阔处重试";
  return "获取当前位置失败";
}

var FAV_KEY="lp_favs_v1";
var FAV_MAX=12;
function loadFavs(){
  try{var raw=localStorage.getItem(FAV_KEY);var a=raw?JSON.parse(raw):[];return Array.isArray(a)?a:[];}catch(e){return [];}
}
function saveFavs(list){try{localStorage.setItem(FAV_KEY,JSON.stringify(list.slice(0,FAV_MAX)));}catch(e){}}
function applyFavorite(it){
  var lat=Number(it.lat),lng=wrapLng(it.lng);
  if(!Number.isFinite(lat)||!Number.isFinite(lng)){toast("收藏坐标无效");return;}
  WGS={lat:lat,lng:lng};saved=false;syncCoordInputs();updateSaveAvailability();enterManualMode("已加载收藏定位点，可继续在地图上手动微调后保存。");
  if(it.alt!=null&&it.alt!=="")$("alt").value=it.alt;
  if(it.hacc!=null&&it.hacc!=="")$("hacc").value=it.hacc;
  if(it.vacc!=null&&it.vacc!=="")$("vacc").value=it.vacc;
  if(it.address!=null)$("address").value=String(it.address);
  if(it.failOpen!=null)$("failopen").checked=it.failOpen!==false;
  if(it.debug!=null)$("debug").checked=it.debug===true;
  moveMapToCurrent(15);info();toast("已加载收藏，确认后保存");
}
function renderFavs(){
  var box=$("favs"),list=loadFavs();box.innerHTML="";
  if(!list.length){box.classList.remove("show");return;}
  list.forEach(function(it,idx){
    var row=document.createElement("div");row.className="rrow";
    var name=document.createElement("span");name.className="fname";name.textContent=it.name||(Number(it.lat).toFixed(4)+","+Number(it.lng).toFixed(4));
    name.addEventListener("click",function(){$("results").classList.remove("show");applyFavorite(it);});
    var del=document.createElement("button");del.className="fdel";del.type="button";del.textContent="删";
    del.addEventListener("click",function(e){e.stopPropagation();var next=loadFavs();next.splice(idx,1);saveFavs(next);if(next.length)renderFavs();else{box.innerHTML="";box.classList.remove("show");}toast("已删除收藏");});
    row.appendChild(name);row.appendChild(del);box.appendChild(row);
  });
  box.classList.add("show");
}
function addFavorite(){
  if(!Number.isFinite(WGS.lat)||!Number.isFinite(WGS.lng)){toast("当前坐标无效");return;}
  var def=$("address").value.trim()||$("q").value.trim()||(WGS.lat.toFixed(4)+","+WGS.lng.toFixed(4));
  var name=window.prompt("收藏名称",def);if(name===null)return;name=String(name).trim()||def;
  var list=loadFavs().filter(function(it){return Math.abs(Number(it.lat)-WGS.lat)>1e-5||Math.abs(Number(it.lng)-WGS.lng)>1e-5;});
  list.unshift({name:name,lat:WGS.lat,lng:WGS.lng,address:$("address").value.trim(),alt:numOrNull("alt"),hacc:numOrNull("hacc"),vacc:numOrNull("vacc"),failOpen:$("failopen").checked,debug:$("debug").checked,ts:Date.now()});
  saveFavs(list);renderFavs();toast("已收藏");
}
function toggleFavs(){
  var box=$("favs");if(box.classList.contains("show")){box.classList.remove("show");return;}
  $("results").classList.remove("show");if(!loadFavs().length){toast("暂无收藏");return;}renderFavs();
}

function info(){
  var el=$("info");el.textContent="";
  if(!Number.isFinite(Number(WGS.lat))||!Number.isFinite(Number(WGS.lng))){
    el.textContent="尚未加载有效坐标。可直接填写 latitude / longitude 后点“应用经纬度”，再保存修复配置。";
    return;
  }
  var b=document.createElement("b");
  if(!enabledState){
    b.style.color="#ff9500";b.textContent="已恢复真实定位 · 脚本放行不修改";el.appendChild(b);
    el.appendChild(document.createTextNode("　（关开定位后生效）"));return;
  }
  var tag=saved?"已保存 ✓":"未保存 · 点“保存定位”生效";
  b.style.color=saved?"#34c759":"#ff9500";b.textContent=tag;el.appendChild(b);
  el.appendChild(document.createTextNode("　WGS-84 "+WGS.lat.toFixed(5)+", "+WGS.lng.toFixed(5)+"　海拔 "+($("alt").value||"?")+"m　模式 "+(locationMode==="ip"?"IP":"手动")));
}

function updateEnabledUI(){
  var b=$("restorebtn");
  if(enabledState){b.textContent="恢复真实定位";b.style.background="#8e8e93";}
  else{b.textContent="● 重新开启伪造";b.style.background="#ff9500";}
  info();
}

function toggleEnabled(){
  var want=!enabledState;
  apiJson("/enable",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({enabled:want,ifRevision:configRevision})})
    .then(function(d){updateRevisionFrom(d);enabledState=want;updateEnabledUI();toast(want?"已开启伪造，记得关开定位生效":"已恢复真实定位，记得关开定位生效");refreshStatus();})
    .catch(function(e){if(!handleRevisionError(e))toast("切换失败："+errorDetail(e));});
}

function dispPos(){return datum==="gcj"?GCJ.wgs2gcj(WGS.lat,WGS.lng):[WGS.lat,WGS.lng];}
function toWgs(lat,lng){lng=wrapLng(lng);return datum==="gcj"?GCJ.gcj2wgs(lat,lng):[lat,lng];}

function fetchElevation(lat,lng){
  lng=wrapLng(lng);
  return apiFetch("/elevation?lat="+encodeURIComponent(lat)+"&lng="+encodeURIComponent(lng))
    .then(function(r){return r.ok?r.json():null;})
    .then(function(d){return d&&d.elevation!=null?d.elevation:null;})
    .catch(function(){return null;});
}

function fetchReverseAddress(lat,lng){
  return apiFetch("/reverse-geocode?lat="+encodeURIComponent(lat)+"&lng="+encodeURIComponent(lng))
    .then(function(r){return r.ok?r.json():null;})
    .then(function(d){return d&&d.result&&d.result.display_name?d.result.display_name:"";})
    .catch(function(){return "";});
}

function scheduleDerivedForCurrent(){
  var seq=++derivedSeq;
  var lat=Number(WGS.lat),lng=Number(WGS.lng);
  if(derivedTimer)clearTimeout(derivedTimer);
  derivedTimer=setTimeout(function(){
    Promise.all([fetchElevation(lat,lng),fetchReverseAddress(lat,lng)]).then(function(values){
      // 用户已经移动到其它位置时，丢弃旧请求结果，避免旧海拔/旧地址覆盖新坐标。
      if(seq!==derivedSeq||Math.abs(Number(WGS.lat)-lat)>1e-9||Math.abs(Number(WGS.lng)-lng)>1e-9)return;
      var el=values[0],addr=values[1];
      if(el!==null)$("alt").value=Math.round(el);
      if(addr&&!$("address").value.trim())$("address").value=addr;
      info();
    }).catch(function(){});
  },450);
}

function movePin(dispLat,dispLng){
  dispLng=wrapLng(dispLng);var w=toWgs(dispLat,dispLng);WGS={lat:w[0],lng:wrapLng(w[1])};saved=false;
  $("address").value="";syncCoordInputs();updateSaveAvailability();enterManualMode("手动地图定位：图钉已移动，确认参数后点击保存定位。");
  if(mapUsable())marker.setLatLng([dispLat,dispLng]);info();
  scheduleDerivedForCurrent();
}

function buildPayload(){
  return {
    lat:WGS.lat,
    lng:WGS.lng,
    address:$("address").value.trim(),
    altitude:numOrNull("alt"),
    horizontalAccuracy:numOrNull("hacc"),
    verticalAccuracy:numOrNull("vacc"),
    failOpen:$("failopen").checked,
    debug:$("debug").checked,
    source:locationMode==="ip"?"ip-preview-manual-save":"manual-map",
    ifRevision:configRevision
  };
}

function commit(options){
  options=options||{};
  return apiJson("/set",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(buildPayload())})
    .then(function(data){
      updateRevisionFrom(data);saved=true;enabledState=true;configLoaded=true;updateSaveAvailability();$("restorebtn").disabled=false;updateEnabledUI();
      if(!options.quiet)toast("已保存 ✓ 记得关开定位生效");
      return data;
    })
    .catch(function(err){
      if(!handleRevisionError(err)&&!options.quiet)toast("保存失败："+errorDetail(err));
      throw err;
    });
}

function applyIpLookup(data, wasSaved){
  var loc=data.location||data;
  var lat=Number(loc.latitude),lng=wrapLng(loc.longitude);
  if(!Number.isFinite(lat)||!Number.isFinite(lng))throw new Error("IP 查询没有返回有效坐标");
  WGS={lat:lat,lng:lng};saved=!!wasSaved;syncCoordInputs();updateSaveAvailability();
  setMode("ip",wasSaved?"IP2Location 定位已写入；仍可在地图上手动微调后再次保存。":"IP2Location 查询预览；可继续手动微调图钉后保存。","");
  $("address").value=loc.address||"";
  if(loc.horizontalAccuracy!==undefined&&loc.horizontalAccuracy!==null)$("hacc").value=loc.horizontalAccuracy;
  if(loc.verticalAccuracy!==undefined&&loc.verticalAccuracy!==null)$("vacc").value=loc.verticalAccuracy;
  if(loc.altitude!==undefined&&loc.altitude!==null&&Number.isFinite(Number(loc.altitude)))$("alt").value=Math.round(Number(loc.altitude));
  $("failopen").checked=loc.failOpen!==false;
  $("debug").checked=loc.debug===true;
  if(wasSaved)enabledState=true;
  moveMapToCurrent(12);updateEnabledUI();info();
}

function renderIpMeta(data){
  var box=$("ipmeta"),m=data.lookup||data.meta||{},items=[];
  function add(label,value){
    if(value===undefined||value===null||value==="")return;
    items.push([String(label),String(value)]);
  }
  add("IP",m.ip);
  add("国家",m.countryName);
  add("地区",m.regionName);
  add("城市",m.cityName);
  add("时区",m.timeZone);
  if(m.asn)add("ASN",String(m.asn)+(m.asName?" / "+String(m.asName):""));
  if(m.isProxy===true)add("代理标记","是（取决于当前 IP2Location 套餐字段能力）");
  if(m.cacheHit===true)add("缓存","命中");
  else if(m.cacheHit===false)add("缓存","未命中");
  // IP2Location 属于外部数据源：禁止 innerHTML 拼接，所有值只通过 textContent 写入，
  // 避免异常/恶意上游字符串在管理页面形成 DOM XSS。
  box.textContent="";
  items.forEach(function(it,idx){
    if(idx)box.appendChild(document.createTextNode("　"));
    var b=document.createElement("b");b.textContent=it[0];box.appendChild(b);
    box.appendChild(document.createTextNode(" "+it[1]));
  });
  if(items.length)box.classList.add("show");else box.classList.remove("show");
}

function requestIpLookup(apply){
  var ip=$("ipq").value.trim();
  if(!ip){toast("请先输入 IPv4 或 IPv6 地址");return;}
  setIpBusy(true);
  apiJson("/ip-lookup",{
    method:"POST",headers:{"Content-Type":"application/json"},
    body:JSON.stringify({ip:ip,apply:!!apply,ifRevision:configRevision}),timeoutMs:22000
  })
    .then(function(data){
      updateRevisionFrom(data);applyIpLookup(data,data.saved===true);renderIpMeta(data);
      var loc=data.location||{};var where=loc.address?"（"+loc.address+"）":"";
      toast(apply?"IP 查询完成并已原子写入 loc.json "+where:"IP 查询完成，当前仅预览，确认后可保存");
    })
    .then(function(){setIpBusy(false);},function(err){
      setIpBusy(false);
      if(handleRevisionError(err))return;
      var detail=errorDetail(err);
      enterManualFallback("IP2Location 无法正常调用："+detail);
      toast("IP 查询失败："+detail+"；已切换手动地图");
    });
}

function applyManualCoords(){
  var lat=Number($("latmanual").value),lng=Number($("lngmanual").value);
  if(!Number.isFinite(lat)||lat<-90||lat>90||!Number.isFinite(lng)||lng<-180||lng>180){
    toast("经纬度格式无效：纬度 -90~90，经度 -180~180");return;
  }
  WGS={lat:lat,lng:wrapLng(lng)};saved=false;$("address").value="";syncCoordInputs();updateSaveAvailability();
  enterManualMode("手动经纬度已应用，可在地图上继续微调后保存。");
  moveMapToCurrent(15);info();
  scheduleDerivedForCurrent();
}

function locateCurrent(){
  if(enabledState){toast("请先恢复真实定位并刷新定位服务");return;}
  if(!navigator.geolocation){toast("当前浏览器不支持定位");return;}
  setLocateBusy(true);
  navigator.geolocation.getCurrentPosition(
    function(pos){
      var lat=Number(pos&&pos.coords&&pos.coords.latitude),lng=wrapLng(pos&&pos.coords&&pos.coords.longitude);
      if(!Number.isFinite(lat)||!Number.isFinite(lng)){toast("获取当前位置失败");setLocateBusy(false);return;}
      WGS={lat:lat,lng:lng};saved=false;$("address").value="";syncCoordInputs();updateSaveAvailability();
      enterManualMode("已获取浏览器真实位置作为手动定位点，确认后保存。");
      moveMapToCurrent(16);info();
      scheduleDerivedForCurrent();
      toast("已定位到当前位置，请确认后保存");setLocateBusy(false);
    },
    function(err){toast(geolocationErrorMessage(err));setLocateBusy(false);},
    {enableHighAccuracy:true,maximumAge:0,timeout:12000}
  );
}

function search(){
  var q=$("q").value.trim();if(!q)return;
  enterManualMode("正在使用原始地址搜索；选择候选后在地图上点击放置图钉。");
  apiJson("/geocode?q="+encodeURIComponent(q))
    .then(function(data){
      var a=data&&data.results||[];
      var box=$("results");box.innerHTML="";
      if(!a||!a.length){box.classList.remove("show");toast("没找到");return;}
      a.forEach(function(it){
        var row=document.createElement("div");row.className="rrow";row.textContent=it.display_name;
        row.addEventListener("click",function(){
          box.classList.remove("show");box.innerHTML="";var la=+it.lat,lo=+it.lon;
          if(mapUsable()){
            var p=datum==="gcj"?GCJ.wgs2gcj(la,lo):[la,lo];
            map.setView(p,15);toast("已定位视野，在地图上点一下放置图钉");
          }else{
            WGS={lat:la,lng:wrapLng(lo)};saved=false;syncCoordInputs();updateSaveAvailability();
            $("address").value=it.display_name||"";info();scheduleDerivedForCurrent();
            toast("地图组件不可用，已直接把搜索结果填入经纬度，可保存");
          }
        });
        box.appendChild(row);
      });
      box.classList.add("show");
    })
    .catch(function(){
      enterManualMode("地址搜索服务暂时不可用；仍可直接点击地图、拖动图钉或填写经纬度定位。");
      toast("地址搜索失败，地图点选/拖图钉/经纬度仍可使用");
    });
}

function refreshStatus(){
  return apiFetch("/status").then(function(r){if(!r.ok)throw new Error("HTTP "+r.status);return r.json();}).then(function(d){
    var remoteChanged=false;
    if(d.revision){
      if(saved||!configRevision)configRevision=String(d.revision);
      else if(String(d.revision)!==configRevision)remoteChanged=true;
    }
    var ip=d.ipLookup||{};
    var ipText=ip.circuitOpen?("IP2Location 冷却中 "+Math.ceil((ip.retryAfterMs||0)/1000)+"s"):"IP2Location 可尝试";
    var proxyText=d.externalOrigin?(" · 外部地址 "+d.externalOrigin):"";
    var cfgText=d.configHealthy===false?" · ⚠ loc.json 降级/待恢复":"";
    var changedText=remoteChanged?" · ⚠ 服务器配置已变化，当前未保存编辑将触发冲突保护":"";
    var mirror=d.upstream&&d.upstream.mirror&&d.upstream.mirror.core;
    var clientText=d.upstream&&d.upstream.clientScriptSource==="self"
      ?(" · 客户端核心镜像 "+(mirror&&mirror.valid?"✓":"未就绪"))
      :" · 客户端核心 GitHub Raw";
    $("statusline").textContent="V"+(d.version||"11")+" · "+ipText+" · 手动定位始终可用 · 备份："+(d.backupAvailable?"有":"暂无")+" · 历史 "+(d.historyCount||0)+clientText+cfgText+changedText+proxyText;
    $("rollbackbtn").disabled=!d.backupAvailable;
  }).catch(function(){$("statusline").textContent="状态接口暂时不可用，但手工经纬度保存仍可继续使用";});
}

function rollbackLast(){
  if(!window.confirm("撤销上一次保存并恢复到前一个 loc.json？当前配置会保存成可再次切换的备份。"))return;
  apiJson("/rollback",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({ifRevision:configRevision})})
    .then(function(d){updateRevisionFrom(d);applyRestoredLocation(d,"已撤销上次保存，可继续调整。");toast("已恢复上一次配置");})
    .catch(function(e){if(!handleRevisionError(e))toast("撤销失败："+errorDetail(e));});
}

function applyRestoredLocation(d,message){
  WGS={lat:Number(d.latitude),lng:Number(d.longitude)};saved=true;enabledState=d.enabled!==false;configLoaded=true;syncCoordInputs();updateSaveAvailability();
  $("address").value=d.address||"";$("alt").value=d.altitude;$("hacc").value=d.horizontalAccuracy;$("vacc").value=d.verticalAccuracy;
  $("failopen").checked=d.failOpen!==false;$("debug").checked=d.debug===true;
  moveMapToCurrent(13);updateEnabledUI();enterManualMode(message||"已恢复历史配置，可继续调整。");refreshStatus();
}

function closeHistory(){
  $("historymodal").classList.remove("show");
}

function restoreHistoryItem(id){
  if(!window.confirm("恢复这个历史版本？当前配置会先自动保存进历史。"))return;
  apiJson("/restore-history",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({id:id,ifRevision:configRevision})})
    .then(function(d){updateRevisionFrom(d);closeHistory();applyRestoredLocation(d,"已恢复选中的历史版本，可继续调整。");toast("历史版本已恢复");})
    .catch(function(e){if(!handleRevisionError(e))toast("恢复历史失败："+errorDetail(e));});
}

function openHistory(){
  var modal=$("historymodal"),list=$("historylist");
  modal.classList.add("show");list.textContent="加载中…";
  apiJson("/history?limit=20").then(function(d){
    var items=d.items||[];list.innerHTML="";
    if(!items.length){list.textContent="暂无历史版本";return;}
    items.forEach(function(it){
      var row=document.createElement("div");row.className="mrow";
      var txt=document.createElement("div");txt.className="mtext";
      var loc=it.location||{};
      txt.textContent=(it.time||it.id)+" · "+Number(loc.latitude).toFixed(6)+", "+Number(loc.longitude).toFixed(6)+(loc.address?" · "+loc.address:"");
      var btn=document.createElement("button");btn.type="button";btn.textContent="恢复";btn.addEventListener("click",function(){restoreHistoryItem(it.id);});
      row.appendChild(txt);row.appendChild(btn);list.appendChild(row);
    });
  }).catch(function(e){list.textContent="历史读取失败："+errorDetail(e);});
}

function showSelfCheck(){
  apiJson("/diagnostics/selfcheck",{timeoutMs:15000}).then(function(d){
    var lines=["系统自检 V"+(d.version||"11")];
    (d.checks||[]).forEach(function(c){
      lines.push((c.ok?"✓ ":((c.severity==="warning"||c.severity==="info")?"! ":"✗ "))+c.name+"："+c.detail);
    });
    window.alert(lines.join("\n"));
  }).catch(function(e){
    var d=e.data||{}, lines=["系统自检存在问题： "+errorDetail(e)];
    (d.checks||[]).forEach(function(c){lines.push((c.ok?"✓ ":"✗ ")+c.name+"："+c.detail);});
    window.alert(lines.join("\n"));
  });
}

function closeClients(){
  $("clientmodal").classList.remove("show");
}

function openClients(){
  var modal=$("clientmodal"),list=$("clientlist");
  modal.classList.add("show");list.textContent="加载中…";
  apiJson("/profiles").then(function(d){
    list.innerHTML="";
    var head=document.createElement("div");head.className="mtext";
    head.style.marginBottom="10px";
    var mirror=d.mirrorStatus&&d.mirrorStatus.core;
    head.textContent="已审计上游："+(d.auditedRepository||"")+" @ "+String(d.auditedCommit||"").slice(0,12)+
      "；脚本来源："+(d.clientScriptSource==="self"?"本机校验镜像":"GitHub Raw")+
      (d.clientScriptSource==="self"?("（"+(mirror&&mirror.valid?"已就绪":"未就绪")+"）"):"")+
      "；远程配置："+(d.configUrl||"");
    list.appendChild(head);
    if(d.configuredClientScriptSource==="self"&&!(mirror&&mirror.valid)){
      var preloadRow=document.createElement("div");preloadRow.className="mrow";
      var preloadText=document.createElement("div");preloadText.className="mtext";preloadText.textContent="客户端核心镜像尚未预热。可立即从已审计上游拉取并做 Git blob 完整性校验。";
      var preloadBtn=document.createElement("button");preloadBtn.type="button";preloadBtn.textContent="立即预热";
      preloadBtn.addEventListener("click",function(){
        preloadBtn.disabled=true;preloadBtn.textContent="预热中…";
        apiJson("/client/preload",{method:"POST",headers:{"Content-Type":"application/json"},body:"{}",timeoutMs:25000})
          .then(function(){toast("客户端核心镜像已预热并校验");openClients();refreshStatus();})
          .catch(function(e){preloadBtn.disabled=false;preloadBtn.textContent="重试预热";toast("预热失败："+errorDetail(e));});
      });
      preloadRow.appendChild(preloadText);preloadRow.appendChild(preloadBtn);list.appendChild(preloadRow);
    }
    (d.profiles||[]).forEach(function(it){
      var row=document.createElement("div");row.className="mrow";
      var txt=document.createElement("div");txt.className="mtext";
      var title=document.createElement("div");title.textContent=it.name+" · 网页远程选点已接入";
      var urlLine=document.createElement("div");urlLine.style.cssText="margin-top:5px;font-size:11px;word-break:break-all;color:#667";urlLine.textContent=it.installUrl||"";
      txt.appendChild(title);txt.appendChild(urlLine);
      var box=document.createElement("div");box.style.cssText="display:flex;gap:6px;flex-wrap:wrap";
      var copy=document.createElement("button");copy.type="button";copy.textContent="复制URL";
      copy.addEventListener("click",function(){
        var v=it.installUrl||"";
        if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(v).then(function(){toast("已复制模块 URL");}).catch(function(){window.prompt("复制模块 URL",v);});}
        else window.prompt("复制模块 URL",v);
      });
      box.appendChild(copy);
      var a=document.createElement("a");a.href=it.download;a.textContent="下载文件";a.style.cssText="border:0;border-radius:7px;padding:8px 11px;background:#007aff;color:#fff;text-decoration:none";
      box.appendChild(a);
      if(it.githubFallback&&d.clientScriptSource!=="github"){
        var g=document.createElement("a");g.href=it.githubFallback;g.textContent="GitHub备用URL";g.style.cssText="border:0;border-radius:7px;padding:8px 11px;background:#8e8e93;color:#fff;text-decoration:none";
        box.appendChild(g);
      }
      row.appendChild(txt);row.appendChild(box);list.appendChild(row);
    });
    if(d.quantumultX&&!d.quantumultX.remotePicker){
      var warn=document.createElement("div");warn.className="mrow";
      var txt=document.createElement("div");txt.className="mtext";txt.textContent="Quantumult X："+(d.quantumultX.reason||"上游当前不支持远程网页配置");
      warn.appendChild(txt);list.appendChild(warn);
    }
  }).catch(function(e){list.textContent="客户端配置读取失败："+errorDetail(e);});
}

function showDiagnostics(){
  apiJson("/diagnostics/request").then(function(d){
    var lines=[
      "外部 Origin: "+(d.expectedOrigin||""),
      "浏览器 Origin: "+(d.origin||"(无)"),
      "Host: "+(d.host||""),
      "X-Forwarded-Host: "+(d.forwardedHost||"(无)"),
      "X-Forwarded-Proto: "+(d.forwardedProto||"(无)"),
      "X-Forwarded-Port: "+(d.forwardedPort||"(无)"),
      "反代头已信任: "+(d.proxyHeadersTrusted?"是":"否")
    ];
    window.alert(lines.join("\n"));
  }).catch(function(e){toast("反代诊断失败："+errorDetail(e));});
}

function logout(){
  // 登出也必须有超时；即使网络/反代异常，也不能让 UI 永久等待。
  apiFetch("/logout",{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:"",timeoutMs:5000})
    .then(function(){location.href="/login";})
    .catch(function(){location.href="/login";});
}

function setMapPlaceholder(title,detail,isError){
  // 若 Leaflet 已经部分初始化，先释放事件/图层，避免失败重试后残留旧实例。
  if(map&&typeof map.remove==="function"){try{map.remove();}catch(e){}}
  mapReady=false;map=null;marker=null;
  var host=$("map");
  host.textContent="";
  host.classList.add("map-unavailable");
  var box=document.createElement("div");box.className="mapmsg"+(isError?" error":"");
  var strong=document.createElement("b");strong.textContent=title||"地图暂不可用";
  box.appendChild(strong);
  if(detail){box.appendChild(document.createElement("br"));box.appendChild(document.createTextNode(detail));}
  host.appendChild(box);
}

function hasUsableCoords(){
  var la=Number(WGS.lat),lo=Number(WGS.lng);
  return Number.isFinite(la)&&la>=-90&&la<=90&&Number.isFinite(lo)&&lo>=-180&&lo<=180;
}

function loadLeafletCss(){
  if(document.querySelector('link[data-lp-leaflet="1"]'))return;
  var link=document.createElement("link");
  link.rel="stylesheet";link.href="/assets/vendor/leaflet/leaflet.css?v=1.9.4";link.setAttribute("data-lp-leaflet","1");
  document.head.appendChild(link);
}

function loadLeafletScript(){
  if(typeof window.L!=="undefined")return Promise.resolve();
  var existing=document.querySelector('script[data-lp-leaflet="1"]');
  if(existing&&existing.dataset.loaded==="1")return Promise.resolve();
  return new Promise(function(resolve,reject){
    var done=false;
    var created=!existing;
    var script=existing||document.createElement("script");
    function cleanupFailedScript(){
      // 只移除本轮创建且尚未成功的脚本。超时后移除，避免“已经降级后又迟到加载”污染全局 window.L。
      if(created&&script&&script.parentNode&&script.dataset.loaded!=="1"){try{script.parentNode.removeChild(script);}catch(e){}}
    }
    function finish(err){
      if(done)return;done=true;clearTimeout(timer);
      if(err)cleanupFailedScript();
      err?reject(err):resolve();
    }
    var timer=setTimeout(function(){finish(new Error("地图组件加载超时"));},6500);
    script.addEventListener("load",function(){script.dataset.loaded="1";finish();},{once:true});
    script.addEventListener("error",function(){finish(new Error("地图组件资源不可用"));},{once:true});
    if(created){
      script.src="/assets/vendor/leaflet/leaflet.js?v=1.9.4";
      script.async=true;script.setAttribute("data-lp-leaflet","1");document.head.appendChild(script);
    }
  });
}

function initMapNow(){
  if(mapInitAttempted||!mapEngineLoaded||typeof window.L==="undefined"||!hasUsableCoords())return false;
  mapInitAttempted=true;
  try{
    var host=$("map");host.textContent="";host.classList.remove("map-unavailable");
    var amapVec=L.tileLayer("https://wprd0{s}.is.autonavi.com/appmaptile?x={x}&y={y}&z={z}&lang=zh_cn&size=1&scl=1&style=7",{subdomains:"1234",maxZoom:18,attribution:"高德地图"});
    amapVec.datum="gcj";
    var amapSat=L.layerGroup([
      L.tileLayer("https://webst0{s}.is.autonavi.com/appmaptile?style=6&x={x}&y={y}&z={z}",{subdomains:"1234",maxZoom:18}),
      L.tileLayer("https://wprd0{s}.is.autonavi.com/appmaptile?x={x}&y={y}&z={z}&lang=zh_cn&size=1&scl=1&style=8",{subdomains:"1234",maxZoom:18})
    ]);amapSat.datum="gcj";
    var osm=L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",{maxZoom:19,attribution:"© OpenStreetMap"});osm.datum="wgs";

    map=L.map("map");amapVec.addTo(map);datum="gcj";map.setView(dispPos(),13);
    L.control.layers({"高德地图":amapVec,"高德卫星":amapSat,"国外 OSM":osm},null,{collapsed:false}).addTo(map);
    var icon=L.divIcon({className:"",html:'<div class="lp-pin"></div>',iconSize:[24,24],iconAnchor:[12,12]});
    marker=L.marker(dispPos(),{draggable:true,icon:icon}).addTo(map);
    mapReady=true;
    map.on("baselayerchange",function(e){datum=e.layer.datum||"wgs";var p=dispPos();marker.setLatLng(p);map.setView(p,map.getZoom());info();});
    map.on("click",function(e){movePin(e.latlng.lat,e.latlng.lng);});
    marker.on("dragend",function(){var p=marker.getLatLng();movePin(p.lat,p.lng);});
    if(locationMode==="manual")enterManualMode("手动地图定位已就绪；IP2Location 仅用于快捷填充。地图瓦片失败也不影响手工经纬度保存。");
    return true;
  }catch(e){
    mapInitAttempted=false;mapReady=false;map=null;marker=null;
    setMapPlaceholder("地图初始化失败","后台核心功能仍正常；可直接填写经纬度保存。",true);
    if(locationMode==="manual")enterManualMode("地图初始化失败；纯手工经纬度模式仍可正常保存。");
    return false;
  }
}

function maybeInitMap(){
  if(mapReady)return true;
  return initMapNow();
}

function startOptionalMapEngine(){
  setMapPlaceholder("地图组件后台加载中","基础配置、IP 查询和手工经纬度控制已独立启动；地图加载不会阻塞后台。",false);
  loadLeafletCss();
  return loadLeafletScript().then(function(){
    mapEngineLoaded=true;
    if(!maybeInitMap()&&!hasUsableCoords()){
      setMapPlaceholder("地图组件已就绪","先读取现有配置，或手动输入 latitude / longitude 后即可初始化地图。",false);
    }
  }).catch(function(e){
    mapEngineLoaded=false;
    setMapPlaceholder("地图组件暂不可用","原因："+(e&&e.message||"未知")+"。基础后台已正常运行，可直接使用手工经纬度保存。",true);
    if(locationMode==="manual")enterManualMode("地图组件暂不可用；纯手工经纬度模式仍可正常保存。");
  });
}

function loadSavedConfig(){
  $("info").textContent="正在读取已保存配置…";
  return apiFetch("/loc.json",{timeoutMs:7000}).then(function(r){
    if(!r.ok){var e=new Error("HTTP "+r.status);e.status=r.status;throw e;}
    var rev=r.headers.get("X-Config-Revision")||String(r.headers.get("ETag")||"").replace(/"/g,"");
    if(rev)configRevision=rev;
    return r.json();
  }).then(function(d){
    var la=Number(d.latitude),lo=Number(d.longitude);
    if(!Number.isFinite(la)||la<-90||la>90||!Number.isFinite(lo)||lo<-180||lo>180)throw new Error("服务器配置中的经纬度无效");
    WGS={lat:la,lng:wrapLng(lo)};configLoaded=true;saved=true;enabledState=d.enabled!==false;syncCoordInputs();
    $("address").value=d.address||"";
    $("alt").value=d.altitude!==undefined?d.altitude:"";
    $("hacc").value=d.horizontalAccuracy!==undefined?d.horizontalAccuracy:39;
    $("vacc").value=d.verticalAccuracy!==undefined?d.verticalAccuracy:1000;
    $("failopen").checked=d.failOpen!==false;
    $("debug").checked=d.debug===true;
    $("savebtn").disabled=false;$("restorebtn").disabled=false;
    if(mapEngineLoaded)maybeInitMap();
    updateEnabledUI();info();
    if(locationMode==="manual")enterManualMode("基础配置已加载；手工经纬度保存始终可用，地图组件独立加载。 ");
    return d;
  }).catch(function(e){
    configLoaded=false;saved=false;
    $("savebtn").disabled=true;$("restorebtn").disabled=true;
    $("info").textContent="配置读取失败："+(e&&e.message||"未知错误")+"。可以直接输入经纬度并点“应用经纬度”来修复配置。";
    setMode("manual","配置读取失败，但后台主程序已启动。手工输入 latitude / longitude → 应用经纬度 → 保存定位，可直接修复。","error");
    throw e;
  });
}

function bind(id,event,handler){
  var el=$(id);if(!el)throw new Error("页面组件缺失："+id);el.addEventListener(event,handler);
}

function bindUi(){
  bind("btn","click",search);
  bind("q","keydown",function(e){if(e.key==="Enter")search();});
  bind("ippreviewbtn","click",function(){requestIpLookup(false);});
  bind("ipapplybtn","click",function(){requestIpLookup(true);});
  bind("ipq","keydown",function(e){if(e.key==="Enter")requestIpLookup(false);});
  bind("manualmodebtn","click",function(){enterManualMode();});
  bind("coordbtn","click",function(){applyManualCoords();$("savebtn").disabled=!hasUsableCoords();if(mapEngineLoaded)maybeInitMap();});
  bind("latmanual","keydown",function(e){if(e.key==="Enter"){$("coordbtn").click();}});
  bind("lngmanual","keydown",function(e){if(e.key==="Enter"){$("coordbtn").click();}});
  bind("locatebtn","click",locateCurrent);
  bind("savebtn","click",function(){commit().then(refreshStatus).catch(function(){});});
  bind("rollbackbtn","click",rollbackLast);
  bind("refreshstatus","click",refreshStatus);
  bind("historybtn","click",openHistory);
  bind("historyclose","click",closeHistory);
  bind("historymodal","click",function(e){if(e.target===$("historymodal"))closeHistory();});
  bind("selfcheckbtn","click",showSelfCheck);
  bind("clientbtn","click",openClients);
  bind("clientclose","click",closeClients);
  bind("clientmodal","click",function(e){if(e.target===$("clientmodal"))closeClients();});
  bind("diagbtn","click",showDiagnostics);
  bind("logoutbtn","click",logout);
  bind("restorebtn","click",toggleEnabled);
  bind("favadd","click",addFavorite);
  bind("favlistbtn","click",toggleFavs);
}

function boot(){
  bindUi();
  window.__LP_BOOT_OK=true;
  window.__LP_RUNTIME_ERROR=false;
  if(window.__LP_WATCHDOG_TIMER){clearTimeout(window.__LP_WATCHDOG_TIMER);window.__LP_WATCHDOG_TIMER=null;}
  $("statusline").textContent="后台核心已启动，正在检查服务状态…";
  $("modetext").textContent="基础控制已启动；地图组件将在后台独立加载。";
  $("savebtn").disabled=true;$("rollbackbtn").disabled=true;$("restorebtn").disabled=true;
  setLocateBusy(false);setIpBusy(false);info();

  // 核心配置与状态先启动；可选地图依赖并行、隔离，任何 CDN/地图失败都不会阻塞这里。
  refreshStatus();
  loadSavedConfig().catch(function(){});
  startOptionalMapEngine();
}

if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",boot,{once:true});
else boot();
