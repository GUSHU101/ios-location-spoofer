module.exports = {
  apps: [{
    name: 'ios-location-picker',
    script: './server.js',
    cwd: __dirname,
    autorestart: true,
    max_restarts: 10,
    restart_delay: 1500,
    kill_timeout: 6000,
    time: true
  }]
};
