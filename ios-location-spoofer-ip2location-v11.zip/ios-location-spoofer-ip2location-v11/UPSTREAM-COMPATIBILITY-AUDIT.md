# 上游兼容性审计（V11）

审计目标：`mekos2772/ios-location-spoofer`

锁定提交：

```text
b72d6f67efb2b457647ae05e3e20ae3f3f6f0262
```

V11 原则：**不重写已审计 Apple WLOC / ARPC / protobuf 核心，只增强服务器、网页选点、远程配置接入、缓存和供应链校验。**

## 文件锁

```text
location-spoofer.js
blob: 51fa0c2527c60ee4ba460bc898d1c28c0abfdb08
size: 62368

location-spoofer-qx.js
blob: 4caa1f306836d4c8a32a426c9c0d1149936f41ad
size: 19647
```

V11 下载后重新按 Git object blob 算法计算 SHA-1，并同时比对精确字节长度。

## `/loc.json` 契约

保持扁平 JSON：

```text
enabled
latitude
longitude
horizontalAccuracy
verticalAccuracy
altitude
failOpen
debug
```

`address` 是服务器增强字段；revision 在 Header/管理 API 中管理，不要求上游核心识别。

## 坐标系

- Apple 配置：WGS-84；
- OSM：WGS-84；
- 高德显示：GCJ-02；
- 高德点击/拖动：写入前迭代反解 WGS-84。

最终 `/loc.json` 提供 WGS-84。

## 平台边界

- **Shadowrocket**：V11 生成带 `configUrl` 的远程模块；`upstream-documented`。
- **Loon**：上游原生存在 `configHost/configToken/configUrl` + cron；`upstream-native`。
- **Surge / Stash**：复用主核心，可以注入 `configUrl`，但仍标为 `shared-core-experimental`。
- **Quantumult X**：审计版本 QX 独立核心不读取 `configUrl`；V11 不虚假标记为支持网页远程选点。

## 上游远程配置缓存

主核心仍有约 5 分钟 persistentStore 缓存。服务器保存成功不代表手机当前这一次拦截一定立即丢弃旧缓存；必要时再次触发定位。

V11 不修改这一代理运行时关键时序。

## V11 自托管镜像

默认：

```text
/client/location-spoofer.js?v=<完整40位blob-sha>
```

流程：

```text
固定审计 URL
→ bounded download
→ Git blob SHA + size
→ atomic cache
→ public self-hosted client endpoint
```

失败时：

- 已有正确缓存：继续使用缓存；
- 无缓存：返回 503；
- 普通公共请求进入失败冷却，避免持续外连；
- 管理员 preload 可强制立即重试。

跨主机 redirect 与 HTTPS→HTTP redirect 被拒绝。

## 已知上游运行边界

服务端自检无法消除以下真实环境变量：

- Apple `/clls/wloc` 在线响应可能变化；
- 某些设备/系统状态下 Apple 可能返回纯文本 `Bad Request` 而不是 protobuf；
- 不同代理 App/MITM 实现存在差异；
- 上游当前还有针对旧 iOS JavaScriptCore BigInt 兼容性的未合并工作。

因此 V11 的“兼容锁定”指服务器/生成配置/指定上游代码可复现，不代表所有 iOS 版本都能由服务器测试证明成功。
