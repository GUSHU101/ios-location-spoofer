# Changelog

## V11.0.0

- 重构管理后台启动链：主 HTML/CSS/watchdog/app.js 全部 same-origin，不再让第三方 Leaflet CDN 阻塞后台初始化。
- 配置加载、状态加载、地图加载彻底解耦；地图失败只降级地图，不阻塞手工经纬度/保存/IP 查询。
- 增加独立启动 watchdog，计时不依赖 DOMContentLoaded，可检测 defer app.js 长时间 Pending。
- 后台静态资源 URL 绑定实际内容 SHA-256 指纹，并保留 ETag + must-revalidate。
- Leaflet 改为服务端双源获取、固定 SHA-384 校验、同源缓存、失败冷却；浏览器端 6.5 秒超时并移除迟到 script。
- 地图失败/重置前释放 Leaflet 实例及事件，避免失败重试残留。
- 所有后台 API 使用 AbortController 默认超时；logout 也纳入 5 秒超时。
- 上游核心公共镜像新增失败冷却，防止 GitHub 故障时公共脚本端点反复触发外连。
- 第三方资产下载禁止跨主机重定向和 HTTPS→HTTP 降级。
- 新增真实 Nginx TLS 反代烟测 `npm run smoke:nginx`，覆盖非标准 HTTPS 端口 Origin、模块 URL、loc.json、登录、app.js、写入及 token 日志泄漏。
- 深度自检自动检查 JavaScript 与 shell 语法、51 项集成测试、release audit、浏览器 smoke、Nginx smoke、可选 deployment doctor。
- 最终主 server.js coverage：line 82.99%、branch 60.87%、functions 88.71%。

## V10.0.0

- 完整复审 V9 服务器、认证、生成模块、Nginx、上游兼容契约和发布自检。
- **修复关键回归**：V9 `/profiles/*.sgmodule?token=...` 直接 URL 添加会被 query-token 白名单拒绝并返回 401；V10 正式支持只读模块订阅 URL。
- 新增管理 `TOKEN` / 只读 `CLIENT_TOKEN` 分权；生成客户端配置不再携带管理 TOKEN。
- CLIENT_TOKEN 默认由 TOKEN 单向 HMAC 派生，也可显式独立设置；旧 V9 管理 TOKEN 的 loc.json query URL保留只读迁移兼容。
- Shadowrocket/Loon/Surge/Stash 生成配置使用当前保存位置作为静态 fallback，避免远程配置异常时无条件回到 Apple Park。
- 持久化 loc.json 新增字段语义校验；非法经纬度/精度/海拔/布尔值进入 backup/history 恢复流程。
- `/set` 与 `/enable` 严格字段解析，非法输入返回 `400 INVALID_FIELD`，不再静默重置。
- 自托管上游核心 URL 增加审计 blob 版本参数，确保 immutable 缓存升级安全。
- 上游核心首次并发获取增加 in-flight 去重。
- `/health` 缩减公开镜像信息，详细 source/error/cache 状态只在认证接口返回。
- Leaflet 1.9.4 CSS/JS 使用与上游 Worker 一致的 SRI + crossorigin。
- 修复 IP2Location 元数据使用 `innerHTML` 拼接外部字符串的 DOM XSS 风险，改为纯 `textContent`/TextNode 渲染。
- Nginx 示例对 `/loc.json` 与 `/profiles/` 关闭 access log，降低只读 token 落日志风险。
- `doctor` 增加 CLIENT_TOKEN、模块 URL 订阅、管理隔离和 loc.json 语义检查。
- `release-audit` 与 `selfcheck` 扩展，自动测试增加到 45 项。
- 修复异常日志直接记录 `req.url` 可能把 `CLIENT_TOKEN` query 写入 Node 日志：V10 最终版仅记录 pathname。
- HTTP 80 跳转虚拟主机关闭 access log，降低误用 `http://.../profiles?...` 时令牌落日志的风险。
- TOKEN 比较改为固定长度 SHA-256 digest 后再 `timingSafeEqual`，避免长度早退。
- Docker Compose 改用 named volume，避免自动创建的 `./data` 为 root 所有导致容器内 `node` 用户无法持久化。
- 修正前端状态接口版本兜底残留 `9`；缓存 TTL=0 现在严格表示禁用缓存。

## V9.0.0

- 基于 `mekos2772/ios-location-spoofer` 当前 main 审计提交 `b72d6f67...` 继续保持上游核心锁定。
- 新增已审计客户端脚本自托管镜像：默认生成模块指向 `/client/location-spoofer.js`。
- 上游脚本首次拉取后按 Git blob SHA + 精确字节长度做完整性校验；校验失败拒绝提供。
- 新增持久化 `upstream-cache/`；已验证缓存存在时，上游 GitHub Raw 临时不可用仍可继续提供客户端脚本。
- 新增 `/client/location-spoofer.js`、`/client/location-spoofer-qx.js` 公共只读端点，带 ETag/immutable 缓存头。
- 新增 `/client/status`、`POST /client/preload`。
- 新增 `npm run preload:upstream`，部署后可主动预热并验证上游核心。
- 新增 `CLIENT_SCRIPT_SOURCE=self|github`，可一键回退直接 GitHub Raw 模式。
- 新增高级 `UPSTREAM_SOURCE_BASE` / blob SHA / size 覆盖，用于经过审计的自建 fork。
- Docker 持久化 `UPSTREAM_CACHE_DIR=/data/upstream-cache`。
- doctor 增加客户端脚本来源、上游 blob 锁、缓存目录和上游 DNS 检查。
- 运行时 selfcheck 增加“客户端核心镜像”检查。
- 自动测试扩展到 25 项，覆盖脚本镜像、完整性拒绝、磁盘离线回退、预热端点及客户端配置。

## V7.0.0

- 宝塔版 Node 固定内部 HTTP，彻底移除 CERT/KEY 运行配置。
- 非标准 HTTPS 端口 Origin/Proxy 识别继续强化。
- GET IP 查询强制只读；写入只允许 POST。
- query token 缩小到 `GET /loc.json` 兼容入口。
- 修复可信 Nginx 下 X-Forwarded-For 可被客户端前置伪造影响限流的问题。
- IP 查询限流改为按客户端、有界 LRU 窗口。
- Nominatim 请求改为严格串行，继续缓存结果。
- 新增配置 revision / HTTP 409 乐观并发控制。
- 新增 loc.json 损坏隔离与 backup/history 自动恢复。
- 原子写临时文件异常时自动清理；备份失败时停止覆盖主配置。
- 地图/Leaflet CDN 失败时保留纯经纬度保存通道。
- 海拔/反向地址前端请求加入防抖与旧响应丢弃。
- 全局请求异常兜底 + requestId。
- doctor 深度检查 `.env`、权限、URL、数据 JSON、端口、运行中 V7、宝塔 Nginx 转发头。
- `doctor:network` 只做 DNS 检查，不消耗 IP2Location API 查询额度。
- 自动测试扩展到 14 项。

