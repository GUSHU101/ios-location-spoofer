# 宝塔部署 V11（ios.caseora.cc:8081）

## 架构

```text
公网 https://ios.caseora.cc:8081
       ↓
Nginx :8081 SSL
       ↓
Node http://127.0.0.1:8080
```

## 1. 上传

建议：

```text
/www/wwwroot/ios-location-spoofer-ip2location-v11/
```

Node 项目目录：

```text
/www/wwwroot/ios-location-spoofer-ip2location-v11/location-picker/
```

## 2. Node

最低：`>=20.12.0`；推荐 Node 22 LTS。

```bash
node -v
```

## 3. `.env`

```bash
cd /www/wwwroot/ios-location-spoofer-ip2location-v11/location-picker
cp .env.example .env
openssl rand -hex 24
openssl rand -hex 24
chmod 600 .env
```

填写：

```env
TOKEN=第一个随机管理TOKEN
CLIENT_TOKEN=第二个不同的只读TOKEN
HOST=127.0.0.1
PORT=8080
IP2LOCATION_API_KEY=
TRUST_PROXY=true
```

不要填写 `CERT` / `KEY`。

## 4. 先做静态自检

```bash
npm run check
npm test
npm run audit:release
```

## 5. 启动 Node

PM2：

```bash
pm2 start ecosystem.config.cjs
pm2 save
```

检查：

```bash
curl http://127.0.0.1:8080/health
ss -lntp | grep :8080
```

应看到 `version: 11.0.0`，并且：

```text
frontendAssets.local.ready = true
```

## 6. Nginx 8081

使用：

```text
location-picker/baota-nginx-8081.conf.example
```

核心项：

```nginx
listen 8081 ssl;
proxy_pass http://127.0.0.1:8080;
proxy_set_header Host $http_host;
proxy_set_header X-Forwarded-Proto https;
proxy_set_header X-Forwarded-Host $http_host;
proxy_set_header X-Forwarded-Port 8081;
```

检查并重载：

```bash
nginx -t
systemctl reload nginx
```

放行 **TCP 8081**。示例没有启用 QUIC/HTTP3，所以不要求 UDP 8081。

## 7. 真实 Nginx 专项烟测

```bash
npm run smoke:nginx
```

它只使用临时高端口和临时自签证书，不修改你的真实站点配置；完成后自动清理。

## 8. 预热已审计客户端核心

```bash
npm run preload:upstream
```

成功后客户端核心会进入本地验证缓存。

## 9. 完整部署 doctor

服务运行时执行：

```bash
npm run doctor
```

检查：

- `.env` 权限；
- TOKEN/CLIENT_TOKEN；
- 127.0.0.1:8080；
- 本地 app.css/watchdog.js/app.js；
- Leaflet cache/cooldown；
- 上游核心 cache/cooldown；
- `/health`；
- CLIENT_TOKEN `/loc.json`；
- Shadowrocket URL 订阅；
- 管理接口隔离；
- 宝塔 Nginx `$http_host` / forwarded proto/port；
- token 路径 access_log 关闭。

## 10. 后台

电脑打开：

```text
https://ios.caseora.cc:8081/login
```

如果地图组件暂时不可用，页面也必须继续显示状态、手工经纬度、保存等基础控制；不应永久停在“加载中”。

## 11. Shadowrocket

后台 → 客户端配置 → Shadowrocket → 复制 URL：

```text
https://ios.caseora.cc:8081/profiles/shadowrocket.sgmodule?token=<CLIENT_TOKEN>&clientSource=self
```

手机直接通过 URL 添加模块。手机不需要登录后台。

## 12. 一次性最终自检

```bash
npm run selfcheck
npm run verify:release
```

在具备 nginx/openssl/curl 的宝塔服务器上，它还会自动执行临时真实 Nginx TLS 烟测。
