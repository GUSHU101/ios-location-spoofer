# iOS Location Spoofer Location Picker V11

V11 是针对宝塔/Nginx 自托管场景重新做过启动架构和故障隔离的版本。目标不是让“地图正常时能用”，而是确保任何可选依赖失败时，管理后台核心仍然可进入、可诊断、可手动保存经纬度。

## 推荐部署结构

```text
https://ios.caseora.cc:8081
        ↓
Nginx :8081 TLS
        ↓
http://127.0.0.1:8080
        ↓
Node V11
```

Node 不处理公网 TLS。`.env` 不需要 `CERT` / `KEY`。

## V11 对“后台一直加载中”的根治

旧版页面把外部 Leaflet JavaScript 放在后台主程序之前。第三方 CDN 如果长时间 Pending，浏览器会阻塞后续初始化，页面只剩“加载中”。

V11 改为：

```text
本机 HTML
  ├─ /assets/app.css
  ├─ /assets/watchdog.js
  └─ /assets/app.js
         ↓
   后台核心先启动
     ├─ /status
     ├─ /loc.json
     ├─ IP 查询
     ├─ 手工经纬度
     └─ 保存/恢复/历史

可选地图组件
  └─ 后台异步加载 Leaflet
       ├─ 成功 → 地图启用
       └─ 失败/超时 → 纯手工模式继续可用
```

后台 HTML 不再包含第三方阻塞脚本。Leaflet 也不是浏览器直连 CDN，而是浏览器访问同源 `/assets/vendor/leaflet/*`；服务器后台从固定镜像获取后先做 SHA-384 校验再缓存。

此外：

- 主前端资源 URL 使用实际文件内容指纹，而不只依赖 `11.0.0` 字符串；热修后 URL 自动变化。
- 本地 JS/CSS 使用 ETag + `must-revalidate`，进一步降低旧缓存继续运行的风险。
- 独立 watchdog 在主 app.js 之前启动，并且**不等待 DOMContentLoaded**；即使 app.js 请求一直 Pending，也会在 6 秒后给出明确故障提示。
- Leaflet 6.5 秒超时后会移除本轮迟到脚本，防止页面已经降级后旧请求又异步修改全局状态。
- 地图初始化失败时会释放 Leaflet map/listener，再进入降级 UI。

## 最简 `.env`

```env
TOKEN=你的后台管理TOKEN
# 推荐显式设置另一个手机只读 TOKEN：
# CLIENT_TOKEN=你的手机只读TOKEN

HOST=127.0.0.1
PORT=8080
IP2LOCATION_API_KEY=
TRUST_PROXY=true
```

建议分别生成：

```bash
openssl rand -hex 24
openssl rand -hex 24
```

`TOKEN` 和 `CLIENT_TOKEN` 不能相同。

如果未填写 `CLIENT_TOKEN`，V11 为兼容 V10 会继续从管理 TOKEN 稳定派生一个只读令牌。长期使用更推荐显式设置独立 `CLIENT_TOKEN`，这样以后轮换后台 TOKEN 不必重新订阅手机模块。

## 手机端 Shadowrocket

后台 → **客户端配置** → Shadowrocket → **复制 URL**。

形如：

```text
https://ios.caseora.cc:8081/profiles/shadowrocket.sgmodule?token=<CLIENT_TOKEN>&clientSource=self
```

手机 Shadowrocket 直接通过 URL 添加模块即可。手机不需要登录管理后台。

生成模块内部：

- 核心脚本默认指向本机审计镜像 `/client/location-spoofer.js?v=<40位blob-sha>`；
- 定位配置指向 `/loc.json?token=<CLIENT_TOKEN>`；
- 静态 fallback 使用服务器当前已保存坐标，而不是固定 Apple Park。

仍需按照上游代理工具要求开启 HTTPS 解密/MITM，并安装、完全信任代理 CA。

## IP2Location 是可选增强

IP 查询失败绝不应该让整个后台不可用。

```text
IP2Location 成功
  → 填充经纬度/地址/海拔

IP2Location 超时/失败/限流
  → 显示真实错误
  → 自动保留手工模式
  → latitude / longitude 仍可直接保存
```

GET `/ip-lookup` 永远只预览；真正修改定位只允许 POST。

## 上游核心供应链锁定

V11 默认锁定：

```text
repository: mekos2772/ios-location-spoofer
commit: b72d6f67efb2b457647ae05e3e20ae3f3f6f0262

location-spoofer.js
blob: 51fa0c2527c60ee4ba460bc898d1c28c0abfdb08
size: 62368

location-spoofer-qx.js
blob: 4caa1f306836d4c8a32a426c9c0d1149936f41ad
size: 19647
```

服务器首次镜像上游核心时重新计算 Git blob SHA，并同时验证精确文件大小。错误内容不会进入有效缓存。

公共客户端脚本端点在上游故障且本地无有效缓存时会进入失败冷却窗口，避免刷新/恶意请求不断触发外部下载。管理员显式 preload 仍可以立即重试。

第三方资产下载还禁止跨主机重定向和 HTTPS→HTTP 协议降级。

## 配置可靠性

V11 保留：

- `loc.json` 原子写入；
- backup + history；
- JSON/字段语义损坏隔离；
- revision 乐观并发控制，旧页面写入返回 HTTP 409；
- 不可恢复损坏时，CLIENT_TOKEN 的 `/loc.json` 返回 503，而不是伪装成正常 Apple Park；
- 历史恢复前继续做字段语义校验；
- 多窗口写入串行化。

## 自检命令

```bash
npm run check
npm test
npm run test:coverage
npm run audit:release
npm run verify:release
npm run browser:smoke
npm run smoke:nginx
npm run selfcheck
npm run doctor
```

`smoke:nginx` 会在临时高端口真实启动：

```text
临时 Nginx TLS → 临时 Node
```

并实际验证：

- HTTPS Origin/非标准端口重建；
- CLIENT_TOKEN 读取 `/loc.json`；
- Shadowrocket URL 模块订阅；
- 管理登录；
- 本地 app.js；
- POST `/set`；
- CLIENT_TOKEN 不进入 Nginx access log。

缺少 nginx/openssl/curl 时该专项测试会明确 SKIP。

## 当前自动审计结果

本发布包最终回归：

```text
51 tests
51 pass
0 fail
```

主 `server.js` 测试覆盖率：

```text
line      82.99%
branch    60.87%
functions 88.71%
```

本环境的真实 Nginx TLS 反代烟测通过。Chromium 真浏览器烟测脚本可运行，但当前构建环境的组织策略禁止本地 HTTP 导航，因此该项明确显示 SKIP，而不是冒充 PASS。

## 重要边界

这些自检可以确认 V11 服务器、网页、Nginx 反代、客户端配置生成和已审计上游脚本供应链的行为，但不能把测试结果等同为“所有 iOS + 所有代理 App + Apple 当前在线 WLOC 永远成功”。

Apple `/clls/wloc` 在线响应、具体 iOS/代理 App 的 MITM 行为仍然需要最终真机验证。
