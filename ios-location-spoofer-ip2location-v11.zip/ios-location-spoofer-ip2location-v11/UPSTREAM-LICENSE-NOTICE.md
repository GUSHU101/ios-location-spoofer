# Upstream license notice

V11 is an integration/extension package built for compatibility with:

- Project: `mekos2772/ios-location-spoofer`
- Audited revision: `b72d6f67efb2b457647ae05e3e20ae3f3f6f0262`
- Upstream license: GNU Affero General Public License, Version 3 (AGPL-3.0)

The V11 verified client mirror serves exact, hash-checked copies of the audited upstream `location-spoofer.js` and `location-spoofer-qx.js`; V11 does not silently rewrite these client assets.

When redistributing or modifying upstream-derived code, retain the upstream source/license notices and comply with AGPL-3.0. Refer to the upstream repository `LICENSE` for the complete terms.

`UPSTREAM-AUDIT-MANIFEST.json` records the audited commit/tree, blob SHA-1 values, byte sizes, client-auth boundary and known compatibility limits.
