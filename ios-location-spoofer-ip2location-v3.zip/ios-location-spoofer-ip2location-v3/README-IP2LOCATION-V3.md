# ios-location-spoofer · IP2Location.io 深度增强版 V3

V3 的核心变化是：**IP2Location.io 只作为快捷定位增强，不再成为网页选点流程的单点依赖。**

只要网页地图本身可以打开，即使发生 API Key 错误、免费额度耗尽、429、5xx、DNS/网络异常、连接超时或 IP2Location 服务不可用，原项目的手动地图定位仍然可以继续使用并正常写入 `loc.json`。

## V3 定位流程

### A. IP 自动定位

1. 输入 IPv4 / IPv6。
2. 点 `IP 查询预览` 或 `IP 查询并写入`。
3. 服务器调用 IP2Location.io。
4. 成功时自动填充：
   - latitude
   - longitude
   - address
   - altitude（若 IP2Location 没给，则尝试 Open-Meteo）
   - 保留当前 horizontalAccuracy / verticalAccuracy / failOpen / debug
5. 地图移动到对应位置。

### B. IP2Location 不可用时自动降级

IP 查询失败后页面不会卡住，也不会禁用地图，而是自动显示：

> 已自动切换为手动地图定位

随后可继续使用下面任意一种方式：

- 地址搜索 → 选择候选 → 在地图上点击放图钉
- 直接点击地图
- 拖动现有图钉
- 手动填写 `latitude` / `longitude` → 点 `应用经纬度`
- 使用浏览器“当前位置”（需要先恢复真实定位）
- 从收藏中加载以前保存的位置

最后直接点击 `保存定位`，服务端仍通过独立 `/set` API 写入 `loc.json`。

**这条手动保存链路完全不依赖 IP2Location。**

## 新增：IP2Location 熔断保护

如果上游连续失败，V3 不会每次点按钮都继续轰炸失效的 API。

默认：

```env
IP2LOCATION_FAILURE_THRESHOLD=3
IP2LOCATION_COOLDOWN_MS=60000
```

含义：连续 3 次查询失败后，IP 查询进入 60 秒冷却期。冷却期间请求会快速返回“请使用手动地图定位”，不会继续访问 IP2Location。

冷却结束后，下次 IP 查询会自动尝试恢复。

这对以下情况尤其有用：

- API 免费额度耗尽
- API Key 被禁用或配置错误
- IP2Location 临时故障
- 服务器无法访问 IP2Location
- 上游持续 429 / 5xx

## 新增：永久可用的手动模式状态栏

页面顶部现在明确显示当前定位模式：

- `IP2Location 查询预览`
- `IP2Location 定位已写入`
- `手动地图定位`
- `IP2Location 失败，已自动切换手动地图定位`

并提供 `切换手动地图定位` 按钮。

即使 IP 查询已经成功，也可以随后手动拖动图钉进行微调；一旦手动调整，页面会自动切换回手动模式。

## 新增：手动经纬度输入

页面直接增加：

```text
latitude   [          ]
longitude  [          ]
[应用经纬度]
```

适用于：

- IP2Location 不可用
- 地址搜索不可用
- 已经从其他渠道知道准确经纬度
- 地图瓦片加载慢但仍希望直接设置位置

输入后会校验：

- latitude：`-90 ~ 90`
- longitude：`-180 ~ 180`

然后移动图钉，并可继续点 `保存定位`。

## 地址搜索失败也不会阻断定位

原项目的地址搜索使用 Nominatim。

V3 中如果地址搜索失败，页面会明确提示：

> 地址搜索失败，地图点选 / 拖图钉 / 经纬度仍可使用

也就是说：

```text
IP2Location
    ↓ 失败
手动地图
    ↓
Nominatim 搜索
    ↓ 也失败
仍可点击地图 / 拖图钉 / 填经纬度
    ↓
/set
    ↓
loc.json
```

## 海拔查询失败也不会阻断保存

手动移动图钉时仍尝试 Open-Meteo elevation。

如果高程接口不可用：

- 不会中断定位；
- 保留当前 altitude；
- 用户仍可手动填写 altitude；
- `保存定位` 仍可正常使用。

## `/set` 与 IP 查询完全解耦

这是 V3 最重要的后端保证。

IP 查询路径：

```text
/ip-lookup
  ↓
IP2Location.io
```

手动保存路径：

```text
/set
  ↓
loc.json
```

两条链路互不依赖。

即使 `/ip-lookup` 连续返回 502 / 503，`/set` 仍能正常写入：

```json
{
  "lat": 48.85837,
  "lng": 2.294481,
  "address": "manual-map",
  "altitude": 35,
  "horizontalAccuracy": 39,
  "verticalAccuracy": 1000,
  "failOpen": true,
  "debug": false,
  "source": "manual-map"
}
```

## 健康检查增强

`GET /health` 现在额外返回 IP 查询熔断状态以及手动降级是否可用。

例如：

```json
{
  "ok": true,
  "manualFallbackAvailable": true,
  "ipLookup": {
    "available": false,
    "circuitOpen": true,
    "retryAfterMs": 42183,
    "consecutiveFailures": 3
  }
}
```

注意：这里的 `ok: true` 表示**定位配置服务器本身仍正常**。

即使 IP2Location 暂时不可用，服务器仍可提供地图页面、读取 `loc.json`、手动保存定位，所以服务本身不会被错误判定为整体不可用。

## `/metrics` 新增指标

新增：

- `manualSaves`
- `ipFallbacks`
- `ipUpstream.consecutiveFailures`
- `ipUpstream.circuitOpen`
- `ipUpstream.retryAfterMs`
- `failureThreshold`
- `cooldownMs`
- `manualFallbackAvailable`

用于判断当前系统到底是在 IP 自动定位模式还是已经进入手动降级模式。

## 推荐环境变量

```env
TOKEN=replace-with-a-long-random-token
PORT=8080

IP2LOCATION_API_KEY=
IP2LOCATION_TIMEOUT_MS=6500
IP2LOCATION_CACHE_TTL_MS=21600000
IP2LOCATION_CACHE_MAX=512
IP_LOOKUP_RATE_LIMIT=60
IP_LOOKUP_ALLOW_SPECIAL=false

# V3 新增
IP2LOCATION_FAILURE_THRESHOLD=3
IP2LOCATION_COOLDOWN_MS=60000
```

## Docker

```bash
cd location-picker
cp .env.example .env
```

至少设置：

```env
TOKEN=你的随机Token
IP2LOCATION_API_KEY=你的Key或留空
```

启动：

```bash
docker compose up -d --build
```

访问：

```text
http://服务器IP:8080/?token=你的TOKEN
```

## 手动降级实际操作

如果页面提示：

```text
IP2Location 无法正常调用……已自动切换为手动地图定位
```

不需要重启 Node，也不需要修改配置。

直接：

1. 在上面的地址框搜索目标地址；
2. 或直接在地图上点击目标位置；
3. 或拖动图钉；
4. 或填写 latitude / longitude 后点 `应用经纬度`；
5. 检查 altitude / horizontalAccuracy / verticalAccuracy / failOpen / debug；
6. 点 `保存定位`。

写入后 `loc.json` 仍是核心定位脚本原来使用的格式。

## 自动测试

```bash
cd location-picker
npm test
```

V3 测试除 V2 的正常 IP 查询、缓存、写入测试之外，还增加了故障降级测试：

1. 模拟 IP2Location 持续返回 503；
2. 确认 `/ip-lookup` 返回 `manualFallback: true`；
3. 确认熔断启动后不再持续请求上游；
4. 在 IP2Location 完全不可用状态下调用 `/set`；
5. 确认手动坐标仍成功写入 `loc.json`；
6. 确认页面包含手动地图与手动经纬度入口。

当前测试：

```text
2 tests
2 pass
0 fail
```

## 与原项目核心脚本的关系

V3 仍只增强 `location-picker` 网页与配置服务。

没有改动 Apple `/clls/wloc` 数据解析与替换核心逻辑，因此：

- IP2Location 成功 → 自动生成位置参数；
- IP2Location 失败 → 原始地图手动生成位置参数；
- 最后两者都写入相同的 `loc.json`；
- `location-spoofer.js` 继续按原方式读取使用。
