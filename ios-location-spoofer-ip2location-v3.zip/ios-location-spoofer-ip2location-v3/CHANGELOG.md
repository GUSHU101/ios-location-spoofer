# V3 Change Log

## V3 — IP 自动定位失效时无缝降级到手动地图定位

- IP2Location.io 从“定位流程依赖”调整为“可选快捷定位增强”。
- `/ip-lookup` 失败时返回 `manualFallback: true` 和 `fallbackMode: manual-map`。
- 前端收到 IP 查询失败后自动切换为手动地图模式，不禁用地图、搜索、图钉或保存按钮。
- 增加永久可见的定位模式状态栏与“切换手动地图定位”按钮。
- 增加手动 `latitude` / `longitude` 输入与“应用经纬度”功能。
- 地图点击、图钉拖动、收藏加载、浏览器当前位置都会自动切换为手动定位模式。
- 地址搜索失败时仍明确保留地图点选 / 拖动图钉 / 手动经纬度能力。
- `/set` 手动保存链路保持与 IP2Location 完全独立。
- 增加 IP2Location 连续失败熔断器：默认 3 次失败进入 60 秒冷却。
- 熔断期间快速提示使用手动地图，不继续轰炸不可用的 IP2Location 上游。
- `/health` 增加 `ipLookup` 状态和 `manualFallbackAvailable`。
- `/metrics` 增加 `manualSaves`、`ipFallbacks`、熔断状态、失败阈值和冷却时间。
- `loc.meta.json` 可记录 `manual-map` / `ip-preview-manual-save` 等来源。
- 增加 IP2Location 故障状态下仍可 `/set` 写入 `loc.json` 的集成测试。

## 保留 V2 能力

- IP 查询预览 / 原子写入。
- LRU 缓存与并发查询去重。
- transient failure 有限重试。
- IP 查询限流。
- 私有 / 保留 IPv4 / IPv6 拦截。
- 原子 JSON 持久化。
- `loc.meta.json` 诊断元数据。
- altitude 高程补全。
- Bearer Token 与 `?token=` 双认证方式。
- CSP / no-referrer / clickjacking / MIME hardening。
- Docker 只读根文件系统、cap drop、no-new-privileges。
