const test = require("node:test");
const assert = require("node:assert/strict");
const http = require("node:http");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const { spawn } = require("node:child_process");

function listen(server){return new Promise(r=>server.listen(0,"127.0.0.1",()=>r(server.address().port)));}
function close(server){return new Promise(r=>server.close(r));}
function wait(ms){return new Promise(r=>setTimeout(r,ms));}
async function waitHealth(base){for(let i=0;i<50;i++){try{const r=await fetch(base+"/health");if(r.ok)return;}catch{}await wait(50);}throw new Error("server not ready");}

test("IP lookup preview/apply, cache and field persistence", async (t) => {
  let upstreamCalls=0;
  const mock=http.createServer((req,res)=>{
    upstreamCalls++;
    const u=new URL(req.url,"http://x");
    assert.equal(u.searchParams.get("ip"),"8.8.8.8");
    res.setHeader("content-type","application/json");
    res.end(JSON.stringify({ip:"8.8.8.8",country_code:"US",country_name:"United States of America",region_name:"California",city_name:"Mountain View",latitude:37.38605,longitude:-122.08385,zip_code:"94035",time_zone:"-07:00",asn:"15169",as:"Google LLC",is_proxy:false,elevation:31}));
  });
  const mockPort=await listen(mock);
  t.after(()=>close(mock));

  const tmp=fs.mkdtempSync(path.join(os.tmpdir(),"lp-v2-"));
  const appPort=await new Promise(resolve=>{const s=http.createServer();s.listen(0,"127.0.0.1",()=>{const p=s.address().port;s.close(()=>resolve(p));});});
  const child=spawn(process.execPath,[path.join(__dirname,"..","server.js")],{env:{...process.env,TOKEN:"test-token",PORT:String(appPort),DATA_FILE:path.join(tmp,"loc.json"),META_FILE:path.join(tmp,"loc.meta.json"),IP2LOCATION_BASE_URL:`http://127.0.0.1:${mockPort}/`,IP2LOCATION_CACHE_TTL_MS:"60000",IP_LOOKUP_RATE_LIMIT:"20"},stdio:["ignore","pipe","pipe"]});
  t.after(()=>child.kill("SIGTERM"));
  const base=`http://127.0.0.1:${appPort}`;
  await waitHealth(base);

  let r=await fetch(base+"/loc.json?token=bad");
  assert.equal(r.status,403);

  r=await fetch(base+"/ip-lookup?token=test-token",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({ip:"8.8.8.8",apply:false})});
  assert.equal(r.status,200);
  let data=await r.json();
  assert.equal(data.saved,false);
  assert.equal(data.location.latitude,37.38605);
  assert.equal(data.location.address,"Mountain View, California, 94035, United States of America");
  assert.equal(data.location.altitude,31);
  assert.equal(data.lookup.cacheHit,false);
  assert.equal(fs.existsSync(path.join(tmp,"loc.json")),false);

  r=await fetch(base+"/ip-lookup?token=test-token",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({ip:"8.8.8.8",apply:true})});
  data=await r.json();
  assert.equal(data.saved,true);
  assert.equal(data.lookup.cacheHit,true);
  assert.equal(upstreamCalls,1);
  const saved=JSON.parse(fs.readFileSync(path.join(tmp,"loc.json"),"utf8"));
  assert.equal(saved.latitude,37.38605);
  assert.equal(saved.failOpen,true);
  assert.equal(saved.debug,false);
  assert.ok(fs.existsSync(path.join(tmp,"loc.meta.json")));

  r=await fetch(base+"/ip-lookup?token=test-token",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({ip:"192.168.1.10"})});
  assert.equal(r.status,400);

  r=await fetch(base+"/set?token=test-token",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({lat:1.2,lng:2.3,address:"manual",altitude:88,horizontalAccuracy:12,verticalAccuracy:34,failOpen:false,debug:true})});
  assert.equal(r.status,200);
  data=await r.json();
  assert.equal(data.address,"manual");
  assert.equal(data.failOpen,false);
  assert.equal(data.debug,true);
});

test("IP2Location failure automatically advertises manual-map fallback and manual save still works", async (t) => {
  let upstreamCalls=0;
  const mock=http.createServer((req,res)=>{
    upstreamCalls++;
    res.statusCode=503;
    res.setHeader("content-type","application/json");
    res.end(JSON.stringify({error:"temporary unavailable"}));
  });
  const mockPort=await listen(mock);
  t.after(()=>close(mock));

  const tmp=fs.mkdtempSync(path.join(os.tmpdir(),"lp-v3-fallback-"));
  const appPort=await new Promise(resolve=>{const s=http.createServer();s.listen(0,"127.0.0.1",()=>{const p=s.address().port;s.close(()=>resolve(p));});});
  const child=spawn(process.execPath,[path.join(__dirname,"..","server.js")],{
    env:{
      ...process.env,
      TOKEN:"fallback-token",
      PORT:String(appPort),
      DATA_FILE:path.join(tmp,"loc.json"),
      META_FILE:path.join(tmp,"loc.meta.json"),
      IP2LOCATION_BASE_URL:`http://127.0.0.1:${mockPort}/`,
      IP2LOCATION_TIMEOUT_MS:"1000",
      IP2LOCATION_FAILURE_THRESHOLD:"1",
      IP2LOCATION_COOLDOWN_MS:"60000",
      IP_LOOKUP_RATE_LIMIT:"20"
    },
    stdio:["ignore","pipe","pipe"]
  });
  t.after(()=>child.kill("SIGTERM"));
  const base=`http://127.0.0.1:${appPort}`;
  await waitHealth(base);

  let r=await fetch(base+"/ip-lookup?token=fallback-token",{
    method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({ip:"8.8.4.4",apply:false})
  });
  assert.equal(r.status,502);
  let data=await r.json();
  assert.equal(data.manualFallback,true);
  assert.equal(data.fallbackMode,"manual-map");
  assert.match(data.hint,/点击地图|拖动图钉|经纬度/);
  assert.equal(data.upstream.circuitOpen,true);
  assert.equal(upstreamCalls,2); // 首次 + 一次有限重试

  // 熔断期间不再继续轰炸上游，而是立刻提示走手动定位。
  r=await fetch(base+"/ip-lookup?token=fallback-token",{
    method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({ip:"1.1.1.1",apply:false})
  });
  assert.equal(r.status,503);
  data=await r.json();
  assert.equal(data.manualFallback,true);
  assert.equal(data.upstream.circuitOpen,true);
  assert.equal(upstreamCalls,2);

  // 关键：IP2Location 完全不可用时，原始手动 /set 链路独立可用。
  r=await fetch(base+"/set?token=fallback-token",{
    method:"POST",headers:{"content-type":"application/json"},
    body:JSON.stringify({lat:48.85837,lng:2.294481,address:"manual-map",altitude:35,horizontalAccuracy:39,verticalAccuracy:1000,failOpen:true,debug:false,source:"manual-map"})
  });
  assert.equal(r.status,200);
  data=await r.json();
  assert.equal(data.latitude,48.85837);
  assert.equal(data.longitude,2.294481);
  assert.equal(data.address,"manual-map");

  const saved=JSON.parse(fs.readFileSync(path.join(tmp,"loc.json"),"utf8"));
  assert.equal(saved.latitude,48.85837);
  assert.equal(saved.longitude,2.294481);

  // 页面明确包含自动降级 + 手动地图/经纬度能力。
  r=await fetch(base+"/?token=fallback-token");
  assert.equal(r.status,200);
  const html=await r.text();
  assert.match(html,/IP2Location 只是快捷方式|IP2Location 仅用于自动填充快捷定位/);
  assert.match(html,/切换手动地图定位/);
  assert.match(html,/应用经纬度/);
  assert.match(html,/enterManualFallback/);

  r=await fetch(base+"/metrics?token=fallback-token");
  data=await r.json();
  assert.equal(data.manualFallbackAvailable,true);
  assert.ok(data.ipFallbacks>=2);
  assert.equal(data.manualSaves,1);
});
