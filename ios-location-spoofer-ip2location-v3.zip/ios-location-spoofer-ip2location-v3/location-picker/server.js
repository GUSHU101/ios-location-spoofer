// 定位选点服务 —— Node 自托管增强版 v3
// 核心目标：IP2Location.io 作为“快捷定位增强”，而不是单点依赖。
// 即使 IP2Location API Key、额度、网络或服务端异常，原始地图搜索 / 点图 / 拖图钉 / 手动经纬度 / 保存定位仍始终可用。
// 仅使用 Node.js 内置模块，无 npm 运行时依赖。

const http = require("http");
const https = require("https");
const crypto = require("crypto");
const fs = require("fs");
const path = require("path");
const net = require("net");

function intEnv(name, fallback, min, max) {
  const n = Number(process.env[name]);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, Math.round(n)));
}

const PORT = intEnv("PORT", 8080, 1, 65535);
const TOKEN = process.env.TOKEN || "";
if (!TOKEN) {
  console.error("启动失败：未设置 TOKEN 环境变量。建议：TOKEN=$(openssl rand -hex 24) PORT=8080 node server.js");
  process.exit(1);
}

const CERT = process.env.CERT || "";
const KEY = process.env.KEY || "";
const DATA_FILE = process.env.DATA_FILE || path.join(__dirname, "loc.json");
const META_FILE = process.env.META_FILE || path.join(path.dirname(DATA_FILE), "loc.meta.json");
const IP2LOCATION_API_KEY = process.env.IP2LOCATION_API_KEY || "";
const IP2LOCATION_BASE_URL = process.env.IP2LOCATION_BASE_URL || "https://api.ip2location.io/";
const IP2LOCATION_TIMEOUT_MS = intEnv("IP2LOCATION_TIMEOUT_MS", 6500, 1000, 30000);
const IP2LOCATION_CACHE_TTL_MS = intEnv("IP2LOCATION_CACHE_TTL_MS", 6 * 3600 * 1000, 0, 7 * 24 * 3600 * 1000);
const IP2LOCATION_CACHE_MAX = intEnv("IP2LOCATION_CACHE_MAX", 512, 8, 5000);
const IP_LOOKUP_RATE_LIMIT = intEnv("IP_LOOKUP_RATE_LIMIT", 60, 1, 10000); // 每分钟，全实例
const IP_LOOKUP_ALLOW_SPECIAL = /^(1|true|yes|on)$/i.test(process.env.IP_LOOKUP_ALLOW_SPECIAL || "false");
const IP2LOCATION_FAILURE_THRESHOLD = intEnv("IP2LOCATION_FAILURE_THRESHOLD", 3, 1, 100);
const IP2LOCATION_COOLDOWN_MS = intEnv("IP2LOCATION_COOLDOWN_MS", 60000, 5000, 30 * 60 * 1000);

const DEFAULT = {
  enabled: true,
  latitude: 37.3349,
  longitude: -122.00902,
  address: "",
  horizontalAccuracy: 39,
  verticalAccuracy: 1000,
  altitude: 530,
  failOpen: true,
  debug: false
};

const stats = {
  startedAt: Date.now(), upstreamCalls: 0, cacheHits: 0, cacheMisses: 0,
  rateLimited: 0, lookupErrors: 0, manualSaves: 0, ipFallbacks: 0
};
const ipUpstream = {
  consecutiveFailures: 0,
  circuitOpenUntil: 0,
  lastSuccessAt: 0,
  lastFailureAt: 0,
  lastError: ""
};
const lookupCache = new Map();
const inFlight = new Map();
let rateWindowStart = Date.now();
let rateWindowCount = 0;

function safeEqual(a, b) {
  const ab = Buffer.from(String(a));
  const bb = Buffer.from(String(b));
  if (ab.length !== bb.length) return false;
  return crypto.timingSafeEqual(ab, bb);
}

function parseBool(value, fallback) {
  if (value === true || value === false) return value;
  if (typeof value === "number") return value !== 0;
  if (typeof value === "string") {
    const v = value.trim().toLowerCase();
    if (["1", "true", "yes", "on"].includes(v)) return true;
    if (["0", "false", "no", "off"].includes(v)) return false;
  }
  return fallback;
}

function finiteNumber(value, fallback) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

function clampInt(value, fallback, min, max) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.round(Math.min(max, Math.max(min, n)));
}

function normalizeLoc(input) {
  const x = input && typeof input === "object" ? input : {};
  const out = { ...DEFAULT };
  out.enabled = parseBool(x.enabled, DEFAULT.enabled);
  out.latitude = finiteNumber(x.latitude, DEFAULT.latitude);
  out.longitude = finiteNumber(x.longitude, DEFAULT.longitude);
  if (out.latitude < -90 || out.latitude > 90) out.latitude = DEFAULT.latitude;
  if (out.longitude < -180 || out.longitude > 180) out.longitude = DEFAULT.longitude;
  out.address = String(x.address == null ? DEFAULT.address : x.address).trim().slice(0, 512);
  out.horizontalAccuracy = clampInt(x.horizontalAccuracy, DEFAULT.horizontalAccuracy, 0, 1000000);
  out.verticalAccuracy = clampInt(x.verticalAccuracy, DEFAULT.verticalAccuracy, 0, 1000000);
  out.altitude = clampInt(x.altitude, DEFAULT.altitude, -12000, 100000);
  out.failOpen = parseBool(x.failOpen, DEFAULT.failOpen);
  out.debug = parseBool(x.debug, DEFAULT.debug);
  return out;
}

function readLoc() {
  try {
    return normalizeLoc(JSON.parse(fs.readFileSync(DATA_FILE, "utf8")));
  } catch {
    return { ...DEFAULT };
  }
}

function ensureParent(file) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
}

function atomicWriteJson(file, obj) {
  ensureParent(file);
  const tmp = file + ".tmp-" + process.pid + "-" + crypto.randomBytes(4).toString("hex");
  fs.writeFileSync(tmp, JSON.stringify(obj, null, 2) + "\n", { mode: 0o600 });
  fs.renameSync(tmp, file);
}

function writeLoc(obj) {
  const normalized = normalizeLoc(obj);
  atomicWriteJson(DATA_FILE, normalized);
  return normalized;
}

function writeMeta(meta) {
  try { atomicWriteJson(META_FILE, meta); } catch (e) { console.error("meta write failed: " + e.message); }
}

const BASE_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Cache-Control": "no-store",
  "X-Content-Type-Options": "nosniff",
  "Referrer-Policy": "no-referrer",
  "X-Frame-Options": "DENY"
};

const PAGE_CSP = [
  "default-src 'none'",
  "script-src https://unpkg.com 'unsafe-inline'",
  "style-src https://unpkg.com 'unsafe-inline'",
  "img-src 'self' https: data:",
  "connect-src 'self' https://api.open-meteo.com https://nominatim.openstreetmap.org",
  "base-uri 'none'",
  "form-action 'none'",
  "frame-ancestors 'none'"
].join("; ");

function send(res, code, type, body, extra) {
  res.writeHead(code, { ...BASE_HEADERS, "Content-Type": type, ...(extra || {}) });
  res.end(body);
}
function sendJson(res, code, obj) { return send(res, code, "application/json; charset=utf-8", JSON.stringify(obj)); }

function tokenFromRequest(req, url) {
  const q = url.searchParams.get("token");
  if (q) return q;
  const auth = String(req.headers.authorization || "");
  return auth.toLowerCase().startsWith("bearer ") ? auth.slice(7).trim() : "";
}

function checkToken(req, url, res) {
  const token = tokenFromRequest(req, url);
  if (!token) { sendJson(res, 401, { error: "missing token" }); return false; }
  if (!safeEqual(token, TOKEN)) { sendJson(res, 403, { error: "bad token" }); return false; }
  return true;
}

function readJsonBody(req, maxBytes = 10000) {
  return new Promise((resolve, reject) => {
    let body = "";
    req.setEncoding("utf8");
    req.on("data", chunk => {
      body += chunk;
      if (body.length > maxBytes) {
        reject(Object.assign(new Error("payload too large"), { statusCode: 413 }));
        req.destroy();
      }
    });
    req.on("end", () => {
      if (!body) return resolve({});
      try { resolve(JSON.parse(body)); } catch { reject(Object.assign(new Error("bad json"), { statusCode: 400 })); }
    });
    req.on("error", reject);
  });
}

function compactText(value) {
  const s = value == null ? "" : String(value).trim();
  return !s || s === "-" ? "" : s;
}

function formatIpAddress(data) {
  const values = [data.city_name, data.region_name, data.zip_code, data.country_name];
  const out = [];
  for (const raw of values) {
    const v = compactText(raw);
    if (v && !out.includes(v)) out.push(v);
  }
  return out.join(", ");
}

function specialIpv4(ip) {
  const p = ip.split(".").map(Number);
  if (p.length !== 4) return true;
  const [a,b] = p;
  return a === 0 || a === 10 || a === 127 || (a === 169 && b === 254) ||
    (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) ||
    (a === 100 && b >= 64 && b <= 127) || (a === 198 && (b === 18 || b === 19)) ||
    (a === 192 && b === 0 && p[2] === 2) || (a === 198 && b === 51 && p[2] === 100) ||
    (a === 203 && b === 0 && p[2] === 113) || a >= 224;
}

function isSpecialIp(ip) {
  const kind = net.isIP(ip);
  if (kind === 4) return specialIpv4(ip);
  if (kind !== 6) return true;
  const s = ip.toLowerCase();
  return s === "::" || s === "::1" || s.startsWith("fe8") || s.startsWith("fe9") ||
    s.startsWith("fea") || s.startsWith("feb") || s.startsWith("fc") || s.startsWith("fd") ||
    s.startsWith("ff") || s.startsWith("2001:db8:");
}

function checkRateLimit() {
  const now = Date.now();
  if (now - rateWindowStart >= 60000) { rateWindowStart = now; rateWindowCount = 0; }
  if (rateWindowCount >= IP_LOOKUP_RATE_LIMIT) { stats.rateLimited += 1; return false; }
  rateWindowCount += 1;
  return true;
}

function ipCircuitState() {
  const now = Date.now();
  const retryAfterMs = Math.max(0, ipUpstream.circuitOpenUntil - now);
  return {
    available: retryAfterMs === 0,
    circuitOpen: retryAfterMs > 0,
    retryAfterMs,
    consecutiveFailures: ipUpstream.consecutiveFailures,
    lastSuccessAt: ipUpstream.lastSuccessAt || null,
    lastFailureAt: ipUpstream.lastFailureAt || null,
    lastError: ipUpstream.lastError || ""
  };
}

function noteIpSuccess() {
  ipUpstream.consecutiveFailures = 0;
  ipUpstream.circuitOpenUntil = 0;
  ipUpstream.lastSuccessAt = Date.now();
  ipUpstream.lastError = "";
}

function noteIpFailure(error) {
  ipUpstream.consecutiveFailures += 1;
  ipUpstream.lastFailureAt = Date.now();
  ipUpstream.lastError = String(error && error.message || error || "IP2Location lookup failed").slice(0, 300);
  if (ipUpstream.consecutiveFailures >= IP2LOCATION_FAILURE_THRESHOLD) {
    ipUpstream.circuitOpenUntil = Date.now() + IP2LOCATION_COOLDOWN_MS;
  }
}

function manualFallbackPayload(message, extra) {
  stats.ipFallbacks += 1;
  return {
    error: "ip lookup failed",
    message: message || "IP2Location 暂时不可用",
    manualFallback: true,
    fallbackMode: "manual-map",
    hint: "IP 查询失败不会影响手动定位：可搜索地点、点击地图、拖动图钉、直接填写经纬度，然后点击保存定位。",
    upstream: ipCircuitState(),
    ...(extra || {})
  };
}

function cacheGet(ip) {
  const hit = lookupCache.get(ip);
  if (!hit) return null;
  if (Date.now() - hit.ts > IP2LOCATION_CACHE_TTL_MS) { lookupCache.delete(ip); return null; }
  lookupCache.delete(ip); lookupCache.set(ip, hit);
  stats.cacheHits += 1;
  return { ...hit.data, cacheHit: true };
}

function cachePut(ip, data) {
  lookupCache.set(ip, { ts: Date.now(), data });
  while (lookupCache.size > IP2LOCATION_CACHE_MAX) lookupCache.delete(lookupCache.keys().next().value);
}

function requestJson(targetUrl, headers, timeoutMs) {
  return new Promise((resolve, reject) => {
    const u = new URL(targetUrl);
    const client = u.protocol === "http:" ? http : https;
    let settled = false;
    const done = (err, value) => { if (settled) return; settled = true; err ? reject(err) : resolve(value); };
    const req = client.request({ protocol:u.protocol, hostname:u.hostname, port:u.port || undefined, path:u.pathname + u.search, method:"GET", headers }, apiRes => {
      let body = "";
      apiRes.setEncoding("utf8");
      apiRes.on("data", chunk => { body += chunk; if (body.length > 256 * 1024) apiRes.destroy(new Error("upstream response too large")); });
      apiRes.on("error", err => done(err));
      apiRes.on("end", () => {
        if (apiRes.statusCode < 200 || apiRes.statusCode >= 300) {
          const err = new Error("upstream HTTP " + apiRes.statusCode); err.statusCode = apiRes.statusCode; err.retryAfter = apiRes.headers["retry-after"]; return done(err);
        }
        try { done(null, JSON.parse(body)); } catch { done(new Error("upstream returned invalid JSON")); }
      });
    });
    req.setTimeout(timeoutMs, () => req.destroy(new Error("upstream request timeout")));
    req.on("error", err => done(err));
    req.end();
  });
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

async function lookupIp2LocationUncached(ip) {
  const circuit = ipCircuitState();
  if (circuit.circuitOpen) {
    const e = new Error("IP2Location 暂时进入冷却保护，请使用手动地图定位或稍后重试");
    e.code = "IP2LOCATION_CIRCUIT_OPEN";
    e.retryAfterMs = circuit.retryAfterMs;
    throw e;
  }
  const base = new URL(IP2LOCATION_BASE_URL);
  base.searchParams.set("ip", ip);
  base.searchParams.set("format", "json");
  const headers = { Accept: "application/json", "User-Agent": "ios-location-spoofer-location-picker/3.0" };
  if (IP2LOCATION_API_KEY) headers.Authorization = "Bearer " + IP2LOCATION_API_KEY;

  let lastErr;
  for (let attempt = 0; attempt < 2; attempt += 1) {
    try {
      stats.upstreamCalls += 1;
      const data = await requestJson(base.toString(), headers, IP2LOCATION_TIMEOUT_MS);
      if (data && data.error) {
        const msg = data.error.error_message || data.error.message || JSON.stringify(data.error);
        throw new Error("IP2Location: " + msg);
      }
      noteIpSuccess();
      return data;
    } catch (e) {
      lastErr = e;
      const transient = e.statusCode === 429 || (e.statusCode >= 500 && e.statusCode <= 599) || /timeout|ECONNRESET|EAI_AGAIN/i.test(e.message || "");
      if (!transient || attempt === 1) break;
      let delay = 350;
      if (e.retryAfter && /^\d+$/.test(String(e.retryAfter))) delay = Math.min(2500, Number(e.retryAfter) * 1000);
      await sleep(delay);
    }
  }
  const finalErr = lastErr || new Error("IP2Location lookup failed");
  noteIpFailure(finalErr);
  throw finalErr;
}

async function fetchElevation(lat, lng) {
  const u = new URL("https://api.open-meteo.com/v1/elevation");
  u.searchParams.set("latitude", String(lat));
  u.searchParams.set("longitude", String(lng));
  try {
    const d = await requestJson(u.toString(), { Accept:"application/json", "User-Agent":"ios-location-spoofer-location-picker/3.0" }, 5000);
    const n = Number(d && d.elevation && d.elevation[0]);
    return Number.isFinite(n) ? Math.round(n) : null;
  } catch { return null; }
}

async function resolveIp(ip) {
  const cached = cacheGet(ip);
  if (cached) return cached;
  stats.cacheMisses += 1;
  if (inFlight.has(ip)) return inFlight.get(ip);
  const promise = (async () => {
    const data = await lookupIp2LocationUncached(ip);
    const latitude = Number(data && data.latitude), longitude = Number(data && data.longitude);
    if (!Number.isFinite(latitude) || !Number.isFinite(longitude) || latitude < -90 || latitude > 90 || longitude < -180 || longitude > 180) {
      const invalid = new Error("IP2Location.io 没有返回有效经纬度");
      noteIpFailure(invalid);
      throw invalid;
    }
    let altitude = Number(data && data.elevation);
    if (!Number.isFinite(altitude)) altitude = await fetchElevation(latitude, longitude);
    const normalized = {
      ip: compactText(data.ip) || ip,
      latitude, longitude,
      address: formatIpAddress(data),
      altitude: Number.isFinite(altitude) ? Math.round(altitude) : null,
      countryCode: compactText(data.country_code), countryName: compactText(data.country_name),
      regionName: compactText(data.region_name), cityName: compactText(data.city_name), zipCode: compactText(data.zip_code),
      timeZone: compactText(data.time_zone), asn: compactText(data.asn), asName: compactText(data.as),
      isProxy: data.is_proxy === true, cacheHit: false, source: "IP2Location.io"
    };
    cachePut(ip, normalized);
    return normalized;
  })().finally(() => inFlight.delete(ip));
  inFlight.set(ip, promise);
  return promise;
}

function mergeLookupIntoLoc(cur, lookup) {
  const next = { ...cur, enabled:true, latitude:lookup.latitude, longitude:lookup.longitude, address:lookup.address || "" };
  if (lookup.altitude != null) next.altitude = lookup.altitude;
  return normalizeLoc(next);
}

async function handler(req, res) {
  const url = new URL(req.url, "http://" + (req.headers.host || "localhost"));
  if (req.method === "OPTIONS") return send(res, 204, "text/plain", "");

  if (url.pathname === "/health" && req.method === "GET") {
    return sendJson(res, 200, {
      ok:true, tokenConfigured:!!TOKEN, apiKeyConfigured:!!IP2LOCATION_API_KEY,
      cacheEntries:lookupCache.size, uptimeSeconds:Math.floor((Date.now()-stats.startedAt)/1000),
      ipLookup: ipCircuitState(), manualFallbackAvailable:true
    });
  }

  if (url.pathname === "/loc.json" && req.method === "GET") {
    if (!checkToken(req, url, res)) return;
    return sendJson(res, 200, readLoc());
  }

  if (url.pathname === "/metrics" && req.method === "GET") {
    if (!checkToken(req, url, res)) return;
    return sendJson(res, 200, {
      ...stats, cacheEntries:lookupCache.size, inFlight:inFlight.size,
      rateWindowCount, rateLimitPerMinute:IP_LOOKUP_RATE_LIMIT, cacheTtlMs:IP2LOCATION_CACHE_TTL_MS,
      ipUpstream: ipCircuitState(), failureThreshold:IP2LOCATION_FAILURE_THRESHOLD,
      cooldownMs:IP2LOCATION_COOLDOWN_MS, manualFallbackAvailable:true
    });
  }

  if (url.pathname === "/ip-lookup" && (req.method === "GET" || req.method === "POST")) {
    if (!checkToken(req, url, res)) return;
    if (!checkRateLimit()) return sendJson(res, 429, manualFallbackPayload("IP 查询过于频繁，请稍后再试；手动地图定位仍可正常使用", { error:"rate limited" }));
    try {
      const body = req.method === "POST" ? await readJsonBody(req) : {};
      const ip = String(body.ip || url.searchParams.get("ip") || "").trim();
      const apply = parseBool(body.apply != null ? body.apply : url.searchParams.get("apply"), false);
      if (!net.isIP(ip)) return sendJson(res, 400, { error:"invalid ip", message:"请输入有效的 IPv4 或 IPv6 地址", manualFallback:true, fallbackMode:"manual-map" });
      if (!IP_LOOKUP_ALLOW_SPECIAL && isSpecialIp(ip)) return sendJson(res, 400, { error:"special ip", message:"私有、保留、回环或文档地址通常没有可用公网地理位置；可直接改用手动地图定位", manualFallback:true, fallbackMode:"manual-map" });
      const lookup = await resolveIp(ip);
      const cur = readLoc();
      let location = mergeLookupIntoLoc(cur, lookup);
      if (apply) {
        location = writeLoc(location);
        writeMeta({ source:"IP2Location.io", appliedAt:new Date().toISOString(), queryIp:ip, lookup });
      }
      return sendJson(res, 200, { saved:apply, location, lookup });
    } catch (e) {
      stats.lookupErrors += 1;
      const status = e && e.code === "IP2LOCATION_CIRCUIT_OPEN" ? 503 : 502;
      return sendJson(res, status, manualFallbackPayload(e.message || "IP 查询失败"));
    }
  }

  if (url.pathname === "/set" && req.method === "POST") {
    if (!checkToken(req, url, res)) return;
    try {
      const j = await readJsonBody(req);
      const la = Number(j.lat !== undefined ? j.lat : j.latitude);
      const lo = Number(j.lng !== undefined ? j.lng : j.longitude);
      if (!Number.isFinite(la) || !Number.isFinite(lo) || la < -90 || la > 90 || lo < -180 || lo > 180) return sendJson(res, 400, { error:"bad coords" });
      const cur = readLoc();
      const next = { ...cur, enabled:true, latitude:la, longitude:lo };
      if (Object.prototype.hasOwnProperty.call(j,"address")) next.address = String(j.address || "").trim().slice(0,512);
      if (Object.prototype.hasOwnProperty.call(j,"altitude")) next.altitude = clampInt(j.altitude, cur.altitude, -12000, 100000);
      if (Object.prototype.hasOwnProperty.call(j,"horizontalAccuracy")) next.horizontalAccuracy = clampInt(j.horizontalAccuracy, cur.horizontalAccuracy, 0, 1000000);
      if (Object.prototype.hasOwnProperty.call(j,"verticalAccuracy")) next.verticalAccuracy = clampInt(j.verticalAccuracy, cur.verticalAccuracy, 0, 1000000);
      if (Object.prototype.hasOwnProperty.call(j,"failOpen")) next.failOpen = parseBool(j.failOpen, cur.failOpen);
      if (Object.prototype.hasOwnProperty.call(j,"debug")) next.debug = parseBool(j.debug, cur.debug);
      const saved = writeLoc(next);
      stats.manualSaves += 1;
      writeMeta({ source:String(j.source || "manual-map").slice(0,64), appliedAt:new Date().toISOString() });
      return sendJson(res, 200, saved);
    } catch (e) { return sendJson(res, e.statusCode || 400, { error:e.message || "bad json" }); }
  }

  if (url.pathname === "/enable" && req.method === "POST") {
    if (!checkToken(req, url, res)) return;
    try {
      const j = await readJsonBody(req);
      const cur = readLoc(); cur.enabled = j.enabled !== false;
      return sendJson(res, 200, writeLoc(cur));
    } catch (e) { return sendJson(res, e.statusCode || 400, { error:e.message || "bad json" }); }
  }

  if ((url.pathname === "/" || url.pathname === "") && req.method === "GET") {
    if (!checkToken(req, url, res)) return;
    return send(res, 200, "text/html; charset=utf-8", PAGE, { "Content-Security-Policy": PAGE_CSP });
  }

  if (url.pathname === "/favicon.ico") return send(res, 204, "text/plain", "");
  return send(res, 404, "text/plain; charset=utf-8", "not found");
}

function onListenError(err) {
  if (err.code === "EADDRINUSE") console.error("启动失败：端口 " + PORT + " 已被占用");
  else if (err.code === "EACCES") console.error("启动失败：没有权限监听端口 " + PORT);
  else console.error("启动失败：" + err.message);
  process.exit(1);
}

function start() {
  let server;
  if (CERT && KEY) {
    try {
      server = https.createServer({ cert:fs.readFileSync(CERT), key:fs.readFileSync(KEY) }, handler);
      setInterval(() => { try { server.setSecureContext({ cert:fs.readFileSync(CERT), key:fs.readFileSync(KEY) }); } catch (e) { console.error("cert reload failed: " + e.message); } }, 12*3600*1000).unref();
    } catch (e) { console.error("https 证书读取失败，回退 http：" + e.message); }
  }
  if (!server) server = http.createServer(handler);
  server.on("error", onListenError);
  server.keepAliveTimeout = 65000;
  server.headersTimeout = 70000;
  server.requestTimeout = 15000;
  server.listen(PORT, () => console.log("location picker v3 listening on :" + PORT + (server instanceof https.Server ? " (https)" : " (http)")));
  return server;
}

const PAGE = `<!doctype html>
<html lang="zh">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<title>定位选点</title>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
<style>
  html,body{margin:0;min-height:100%;font-family:-apple-system,BlinkMacSystemFont,sans-serif}
  .bar{padding:8px;display:flex;gap:6px;box-sizing:border-box}
  .bar + .bar{padding-top:0}
  .bar input{flex:1;min-width:0;padding:10px;font-size:16px;border:1px solid #ccc;border-radius:8px}
  .bar button{padding:10px 14px;font-size:16px;border:0;border-radius:8px;background:#007aff;color:#fff;white-space:nowrap}
  .bar button:disabled{opacity:.55}
  .attribution{padding:0 10px 7px;font-size:12px;color:#666;line-height:1.35}
  .attribution a{color:#007aff;text-decoration:none}
  .ipmeta{margin:0 8px 8px;padding:9px 10px;border:1px solid #e6e6e6;border-radius:8px;background:#fafafa;font-size:12px;color:#444;line-height:1.45;display:none}
  .ipmeta.show{display:block}
  .ipmeta b{color:#111}
  .modebox{margin:0 8px 8px;padding:9px 10px;border:1px solid #d9e7ff;border-radius:8px;background:#f4f8ff;font-size:13px;line-height:1.45;color:#245}
  .modebox.manual{border-color:#ffd59a;background:#fff8ec;color:#714600}
  .modebox.error{border-color:#ffc8c5;background:#fff2f1;color:#8a201b}
  .modebox b{color:inherit}
  .modebox button{margin-left:8px;padding:6px 10px;border:0;border-radius:6px;background:#007aff;color:#fff;font-size:12px}
  .coordbtn{padding:9px 12px;border:0;border-radius:7px;background:#0a84ff;color:#fff;font-size:14px}
  #map.manual-focus{outline:3px solid rgba(255,149,0,.35);outline-offset:-3px}
  .results{margin:0 8px;border:1px solid #e2e2e2;border-radius:8px;max-height:34vh;overflow:auto;display:none}
  .results.show{display:block}
  .rrow{padding:10px 12px;font-size:14px;border-bottom:1px solid #eee;color:#222;display:flex;align-items:center;gap:8px}
  .rrow:last-child{border-bottom:0}
  .rrow:active{background:#f0f6ff}
  .rrow .fname{flex:1;min-width:0}
  .rrow .fdel{padding:6px 10px;font-size:13px;border:0;border-radius:6px;background:#ff3b30;color:#fff;flex-shrink:0}
  #map{height:48vh;min-height:280px}
  #info{padding:8px 10px;font-size:13px;line-height:1.45}
  .opts{padding:6px 10px 12px;display:flex;flex-wrap:wrap;gap:8px;align-items:flex-end}
  .opts label{font-size:13px;color:#444;display:flex;flex-direction:column}
  .opts input[type=number],.opts input[type=text]{width:88px;padding:8px;font-size:15px;border:1px solid #ccc;border-radius:6px;margin-top:2px}
  .opts label.wide{flex:1 1 240px}
  .opts label.wide input{width:auto;min-width:180px}
  .opts label.check{flex-direction:row;align-items:center;gap:6px;padding:8px 4px}
  .opts label.check input{width:auto;margin:0}
  #savebtn{padding:11px 20px;font-size:16px;border:0;border-radius:8px;background:#34c759;color:#fff;font-weight:600}
  #restorebtn{padding:11px 16px;font-size:15px;border:0;border-radius:8px;background:#8e8e93;color:#fff}
  #favadd,#favlistbtn{padding:11px 14px;font-size:15px;border:0;border-radius:8px;background:#5856d6;color:#fff}
  .toast{position:fixed;bottom:16px;left:50%;transform:translateX(-50%);max-width:88vw;
    background:rgba(0,0,0,.85);color:#fff;padding:10px 16px;border-radius:8px;
    font-size:14px;opacity:0;transition:opacity .3s;pointer-events:none;z-index:9999;text-align:center}
  .toast.show{opacity:1}
</style>
</head>
<body>
<div class="bar">
  <input id="q" placeholder="搜地名，回车列出候选（只预览，不改定位）">
  <button id="locatebtn" disabled>当前位置</button>
  <button id="btn">搜</button>
</div>
<div class="bar">
  <input id="ipq" placeholder="输入 IPv4 / IPv6，例如 8.8.8.8" autocapitalize="off" autocomplete="off" spellcheck="false">
  <button id="ippreviewbtn" disabled>IP 查询预览</button>
  <button id="ipapplybtn" disabled>IP 查询并写入</button>
</div>
<div class="attribution">本工具使用 <a href="https://www.ip2location.io" target="_blank" rel="noopener noreferrer">IP2Location.io IP geolocation</a> web service。IP 定位只是快捷方式；API 不可用、无额度或超时时，<b>不会影响下面的手动地图定位</b>。</div>
<div class="modebox" id="modebox"><b>定位模式：</b><span id="modetext">加载中…</span><button id="manualmodebtn" type="button">切换手动地图定位</button></div>
<div class="ipmeta" id="ipmeta"></div>
<div class="results" id="results"></div>
<div id="map"></div>
<div id="info">加载中…</div>
<div class="opts">
  <label>latitude<input id="latmanual" type="number" inputmode="decimal" step="any"></label>
  <label>longitude<input id="lngmanual" type="number" inputmode="decimal" step="any"></label>
  <button id="coordbtn" class="coordbtn" type="button">应用经纬度</button>
  <label class="wide">address<input id="address" type="text" placeholder="IP 查询后自动填充，也可手动修改"></label>
  <label>海拔 altitude(米)<input id="alt" type="number" inputmode="numeric"></label>
  <label>水平精度 horizontalAccuracy<input id="hacc" type="number" inputmode="numeric"></label>
  <label>垂直精度 verticalAccuracy<input id="vacc" type="number" inputmode="numeric"></label>
  <label class="check"><input id="failopen" type="checkbox"> failOpen</label>
  <label class="check"><input id="debug" type="checkbox"> debug</label>
  <button id="savebtn">保存定位</button>
  <button id="restorebtn">恢复真实定位</button>
  <button id="favadd">收藏此点</button>
  <button id="favlistbtn">我的收藏</button>
</div>
<div class="results" id="favs"></div>
<div class="toast" id="toast"></div>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
var token = new URLSearchParams(location.search).get("token") || "";

var GCJ = (function(){
  var PI = Math.PI, a = 6378245.0, ee = 0.00669342162296594323;
  function outOfChina(lat,lng){return (lng<72.004||lng>137.8347)||(lat<0.8293||lat>55.8271);}
  function tLat(x,y){
    var r=-100.0+2.0*x+3.0*y+0.2*y*y+0.1*x*y+0.2*Math.sqrt(Math.abs(x));
    r+=(20.0*Math.sin(6.0*x*PI)+20.0*Math.sin(2.0*x*PI))*2.0/3.0;
    r+=(20.0*Math.sin(y*PI)+40.0*Math.sin(y/3.0*PI))*2.0/3.0;
    r+=(160.0*Math.sin(y/12.0*PI)+320*Math.sin(y*PI/30.0))*2.0/3.0;return r;
  }
  function tLng(x,y){
    var r=300.0+x+2.0*y+0.1*x*x+0.1*x*y+0.1*Math.sqrt(Math.abs(x));
    r+=(20.0*Math.sin(6.0*x*PI)+20.0*Math.sin(2.0*x*PI))*2.0/3.0;
    r+=(20.0*Math.sin(x*PI)+40.0*Math.sin(x/3.0*PI))*2.0/3.0;
    r+=(150.0*Math.sin(x/12.0*PI)+300.0*Math.sin(x/30.0*PI))*2.0/3.0;return r;
  }
  function wgs2gcj(lat,lng){
    if(outOfChina(lat,lng))return [lat,lng];
    var dLat=tLat(lng-105.0,lat-35.0), dLng=tLng(lng-105.0,lat-35.0);
    var radLat=lat/180.0*PI, m=Math.sin(radLat); m=1-ee*m*m; var sm=Math.sqrt(m);
    dLat=(dLat*180.0)/((a*(1-ee))/(m*sm)*PI);
    dLng=(dLng*180.0)/(a/sm*Math.cos(radLat)*PI);
    return [lat+dLat,lng+dLng];
  }
  function gcj2wgs(lat,lng){
    if(outOfChina(lat,lng))return [lat,lng];
    var wlat=lat, wlng=lng;
    for(var i=0;i<3;i++){var g=wgs2gcj(wlat,wlng);wlat+=lat-g[0];wlng+=lng-g[1];}
    return [wlat,wlng];
  }
  return {wgs2gcj:wgs2gcj,gcj2wgs:gcj2wgs};
})();

var map, marker;
var WGS={lat:0,lng:0};
var datum="gcj";
var saved=true;
var enabledState=true;
var locationMode="manual";
var lastIpError="";

function $(id){return document.getElementById(id);}
function toast(t){var e=$("toast");e.textContent=t;e.classList.add("show");setTimeout(function(){e.classList.remove("show");},2200);}
function numOrNull(id){var v=$(id).value.trim();return v===""?null:Number(v);}
function wrapLng(lng){return ((((Number(lng)+180)%360)+360)%360)-180;}

function syncCoordInputs(){
  if(Number.isFinite(WGS.lat))$("latmanual").value=Number(WGS.lat).toFixed(6);
  if(Number.isFinite(WGS.lng))$("lngmanual").value=Number(WGS.lng).toFixed(6);
}

function setMode(mode,message,severity){
  locationMode=mode||"manual";
  var box=$("modebox"), text=$("modetext");
  box.className="modebox"+(severity?" "+severity:(locationMode==="manual"?" manual":""));
  text.textContent=message||(locationMode==="ip"?"IP2Location 快捷定位":"手动地图定位");
  if(map&&map.getContainer){
    if(locationMode==="manual")map.getContainer().classList.add("manual-focus");
    else map.getContainer().classList.remove("manual-focus");
  }
}

function enterManualFallback(message){
  lastIpError=String(message||"IP2Location 暂时不可用");
  setMode("manual",lastIpError+"；已自动切换为手动地图定位。可搜索地点、点击地图、拖动图钉或直接输入经纬度，然后保存。","error");
  try{$("q").focus();}catch(e){}
}

function enterManualMode(message){
  setMode("manual",message||"手动地图定位：搜索地点后点地图放置图钉，或拖动图钉 / 直接填写经纬度。","manual");
}

function setLocateBusy(busy){
  var b=$("locatebtn");
  b.disabled=!!busy;
  b.textContent=busy?"定位中…":"当前位置";
}

function setIpBusy(busy){
  var p=$("ippreviewbtn"), a=$("ipapplybtn");
  p.disabled=!!busy;a.disabled=!!busy;
  p.textContent=busy?"查询中…":"IP 查询预览";
  a.textContent=busy?"处理中…":"IP 查询并写入";
}

function geolocationErrorMessage(err){
  if(err&&err.code===1)return "定位权限被拒绝，请在 Safari 设置中允许定位";
  if(err&&err.code===2)return "暂时无法获取当前位置";
  if(err&&err.code===3)return "获取当前位置超时，请到开阔处重试";
  return "获取当前位置失败";
}

var FAV_KEY="lp_favs_v1";
var FAV_MAX=12;
function loadFavs(){
  try{var raw=localStorage.getItem(FAV_KEY);var a=raw?JSON.parse(raw):[];return Array.isArray(a)?a:[];}catch(e){return [];}
}
function saveFavs(list){try{localStorage.setItem(FAV_KEY,JSON.stringify(list.slice(0,FAV_MAX)));}catch(e){}}
function applyFavorite(it){
  var lat=Number(it.lat),lng=wrapLng(it.lng);
  if(!Number.isFinite(lat)||!Number.isFinite(lng)){toast("收藏坐标无效");return;}
  WGS={lat:lat,lng:lng};saved=false;syncCoordInputs();enterManualMode("已加载收藏定位点，可继续在地图上手动微调后保存。");
  if(it.alt!=null&&it.alt!=="")$("alt").value=it.alt;
  if(it.hacc!=null&&it.hacc!=="")$("hacc").value=it.hacc;
  if(it.vacc!=null&&it.vacc!=="")$("vacc").value=it.vacc;
  if(it.address!=null)$("address").value=String(it.address);
  if(it.failOpen!=null)$("failopen").checked=it.failOpen!==false;
  if(it.debug!=null)$("debug").checked=it.debug===true;
  var p=dispPos();marker.setLatLng(p);map.setView(p,15);info();toast("已加载收藏，确认后保存");
}
function renderFavs(){
  var box=$("favs"),list=loadFavs();box.innerHTML="";
  if(!list.length){box.classList.remove("show");return;}
  list.forEach(function(it,idx){
    var row=document.createElement("div");row.className="rrow";
    var name=document.createElement("span");name.className="fname";name.textContent=it.name||(Number(it.lat).toFixed(4)+","+Number(it.lng).toFixed(4));
    name.addEventListener("click",function(){$("results").classList.remove("show");applyFavorite(it);});
    var del=document.createElement("button");del.className="fdel";del.type="button";del.textContent="删";
    del.addEventListener("click",function(e){e.stopPropagation();var next=loadFavs();next.splice(idx,1);saveFavs(next);if(next.length)renderFavs();else{box.innerHTML="";box.classList.remove("show");}toast("已删除收藏");});
    row.appendChild(name);row.appendChild(del);box.appendChild(row);
  });
  box.classList.add("show");
}
function addFavorite(){
  if(!Number.isFinite(WGS.lat)||!Number.isFinite(WGS.lng)){toast("当前坐标无效");return;}
  var def=$("address").value.trim()||$("q").value.trim()||(WGS.lat.toFixed(4)+","+WGS.lng.toFixed(4));
  var name=window.prompt("收藏名称",def);if(name===null)return;name=String(name).trim()||def;
  var list=loadFavs().filter(function(it){return Math.abs(Number(it.lat)-WGS.lat)>1e-5||Math.abs(Number(it.lng)-WGS.lng)>1e-5;});
  list.unshift({name:name,lat:WGS.lat,lng:WGS.lng,address:$("address").value.trim(),alt:numOrNull("alt"),hacc:numOrNull("hacc"),vacc:numOrNull("vacc"),failOpen:$("failopen").checked,debug:$("debug").checked,ts:Date.now()});
  saveFavs(list);renderFavs();toast("已收藏");
}
function toggleFavs(){
  var box=$("favs");if(box.classList.contains("show")){box.classList.remove("show");return;}
  $("results").classList.remove("show");if(!loadFavs().length){toast("暂无收藏");return;}renderFavs();
}

function info(){
  if(!enabledState){$("info").innerHTML="<b style='color:#ff9500'>已恢复真实定位 · 脚本放行不修改</b>　（关开定位后生效）";return;}
  var tag=saved?"已保存 ✓":"未保存 · 点“保存定位”生效";
  $("info").innerHTML="<b style='color:"+(saved?"#34c759":"#ff9500")+"'>"+tag+"</b>　WGS-84 "+WGS.lat.toFixed(5)+", "+WGS.lng.toFixed(5)+"　海拔 "+($("alt").value||"?")+"m　模式 "+(locationMode==="ip"?"IP":"手动");
}

function updateEnabledUI(){
  var b=$("restorebtn");
  if(enabledState){b.textContent="恢复真实定位";b.style.background="#8e8e93";}
  else{b.textContent="● 重新开启伪造";b.style.background="#ff9500";}
  info();
}

function toggleEnabled(){
  var want=!enabledState;
  fetch("/enable?token="+encodeURIComponent(token),{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({enabled:want})})
    .then(function(r){if(r.ok){enabledState=want;updateEnabledUI();toast(want?"已开启伪造，记得关开定位生效":"已恢复真实定位，记得关开定位生效");}else toast("切换失败 "+r.status);})
    .catch(function(){toast("网络错误");});
}

function dispPos(){return datum==="gcj"?GCJ.wgs2gcj(WGS.lat,WGS.lng):[WGS.lat,WGS.lng];}
function toWgs(lat,lng){lng=wrapLng(lng);return datum==="gcj"?GCJ.gcj2wgs(lat,lng):[lat,lng];}

function fetchElevation(lat,lng){
  lng=wrapLng(lng);
  return fetch("https://api.open-meteo.com/v1/elevation?latitude="+lat+"&longitude="+lng)
    .then(function(r){return r.json();})
    .then(function(d){return(d&&d.elevation&&d.elevation.length)?d.elevation[0]:null;})
    .catch(function(){return null;});
}

function movePin(dispLat,dispLng){
  dispLng=wrapLng(dispLng);var w=toWgs(dispLat,dispLng);WGS={lat:w[0],lng:wrapLng(w[1])};saved=false;
  $("address").value="";syncCoordInputs();enterManualMode("手动地图定位：图钉已移动，确认参数后点击保存定位。");
  marker.setLatLng([dispLat,dispLng]);info();
  fetchElevation(WGS.lat,WGS.lng).then(function(el){if(el!==null)$("alt").value=Math.round(el);info();});
}

function buildPayload(){
  return {
    lat:WGS.lat,
    lng:WGS.lng,
    address:$("address").value.trim(),
    altitude:numOrNull("alt"),
    horizontalAccuracy:numOrNull("hacc"),
    verticalAccuracy:numOrNull("vacc"),
    failOpen:$("failopen").checked,
    debug:$("debug").checked,
    source:locationMode==="ip"?"ip-preview-manual-save":"manual-map"
  };
}

function commit(options){
  options=options||{};
  return fetch("/set?token="+encodeURIComponent(token),{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(buildPayload())})
    .then(function(r){
      return r.text().then(function(text){
        var data={};try{data=text?JSON.parse(text):{};}catch(e){}
        if(!r.ok)throw new Error(data.message||data.error||("HTTP "+r.status));
        return data;
      });
    })
    .then(function(data){
      saved=true;enabledState=true;updateEnabledUI();
      if(!options.quiet)toast("已保存 ✓ 记得关开定位生效");
      return data;
    })
    .catch(function(err){
      if(!options.quiet)toast("保存失败："+err.message);
      throw err;
    });
}

function applyIpLookup(data, wasSaved){
  var loc=data.location||data;
  var lat=Number(loc.latitude),lng=wrapLng(loc.longitude);
  if(!Number.isFinite(lat)||!Number.isFinite(lng))throw new Error("IP 查询没有返回有效坐标");
  WGS={lat:lat,lng:lng};saved=!!wasSaved;syncCoordInputs();
  setMode("ip",wasSaved?"IP2Location 定位已写入；仍可在地图上手动微调后再次保存。":"IP2Location 查询预览；可继续手动微调图钉后保存。","");
  $("address").value=loc.address||"";
  if(loc.horizontalAccuracy!==undefined&&loc.horizontalAccuracy!==null)$("hacc").value=loc.horizontalAccuracy;
  if(loc.verticalAccuracy!==undefined&&loc.verticalAccuracy!==null)$("vacc").value=loc.verticalAccuracy;
  if(loc.altitude!==undefined&&loc.altitude!==null&&Number.isFinite(Number(loc.altitude)))$("alt").value=Math.round(Number(loc.altitude));
  $("failopen").checked=loc.failOpen!==false;
  $("debug").checked=loc.debug===true;
  if(wasSaved)enabledState=true;
  var p=dispPos();marker.setLatLng(p);map.setView(p,12);updateEnabledUI();info();
}

function renderIpMeta(data){
  var box=$("ipmeta"), m=data.lookup||data.meta||{};
  var parts=[];
  if(m.ip)parts.push("<b>IP</b> "+m.ip);
  if(m.countryName)parts.push("<b>国家</b> "+m.countryName);
  if(m.regionName)parts.push("<b>地区</b> "+m.regionName);
  if(m.cityName)parts.push("<b>城市</b> "+m.cityName);
  if(m.timeZone)parts.push("<b>时区</b> "+m.timeZone);
  if(m.asn)parts.push("<b>ASN</b> "+m.asn+(m.asName?" / "+m.asName:""));
  if(m.isProxy===true)parts.push("<b>代理标记</b> 是（取决于当前 IP2Location 套餐字段能力）");
  if(m.cacheHit===true)parts.push("<b>缓存</b> 命中");
  else if(m.cacheHit===false)parts.push("<b>缓存</b> 未命中");
  box.innerHTML=parts.join("　");
  if(parts.length)box.classList.add("show");else box.classList.remove("show");
}

function requestIpLookup(apply){
  var ip=$("ipq").value.trim();
  if(!ip){toast("请先输入 IPv4 或 IPv6 地址");return;}
  setIpBusy(true);
  fetch("/ip-lookup?token="+encodeURIComponent(token),{
    method:"POST",headers:{"Content-Type":"application/json"},
    body:JSON.stringify({ip:ip,apply:!!apply})
  })
    .then(function(r){return r.text().then(function(text){var data={};try{data=text?JSON.parse(text):{};}catch(e){}if(!r.ok)throw new Error(data.message||data.error||("HTTP "+r.status));return data;});})
    .then(function(data){
      applyIpLookup(data,data.saved===true);renderIpMeta(data);
      var loc=data.location||{};var where=loc.address?"（"+loc.address+"）":"";
      toast(apply?"IP 查询完成并已原子写入 loc.json "+where:"IP 查询完成，当前仅预览，确认后可保存");
    })
    .then(function(){setIpBusy(false);},function(err){
      setIpBusy(false);
      enterManualFallback("IP2Location 无法正常调用："+err.message);
      toast("IP 查询失败，已自动切换手动地图定位");
    });
}

function applyManualCoords(){
  var lat=Number($("latmanual").value),lng=Number($("lngmanual").value);
  if(!Number.isFinite(lat)||lat<-90||lat>90||!Number.isFinite(lng)||lng<-180||lng>180){
    toast("经纬度格式无效：纬度 -90~90，经度 -180~180");return;
  }
  WGS={lat:lat,lng:wrapLng(lng)};saved=false;$("address").value="";syncCoordInputs();
  enterManualMode("手动经纬度已应用，可在地图上继续微调后保存。");
  var p=dispPos();marker.setLatLng(p);map.setView(p,15);info();
  fetchElevation(WGS.lat,WGS.lng).then(function(el){if(el!==null)$("alt").value=Math.round(el);info();});
}

function locateCurrent(){
  if(enabledState){toast("请先恢复真实定位并刷新定位服务");return;}
  if(!navigator.geolocation){toast("当前浏览器不支持定位");return;}
  setLocateBusy(true);
  navigator.geolocation.getCurrentPosition(
    function(pos){
      var lat=Number(pos&&pos.coords&&pos.coords.latitude),lng=wrapLng(pos&&pos.coords&&pos.coords.longitude);
      if(!Number.isFinite(lat)||!Number.isFinite(lng)){toast("获取当前位置失败");setLocateBusy(false);return;}
      WGS={lat:lat,lng:lng};saved=false;$("address").value="";syncCoordInputs();
      enterManualMode("已获取浏览器真实位置作为手动定位点，确认后保存。");
      var p=dispPos();marker.setLatLng(p);map.setView(p,16);info();
      fetchElevation(WGS.lat,WGS.lng).then(function(el){if(el!==null)$("alt").value=Math.round(el);info();});
      toast("已定位到当前位置，请确认后保存");setLocateBusy(false);
    },
    function(err){toast(geolocationErrorMessage(err));setLocateBusy(false);},
    {enableHighAccuracy:true,maximumAge:0,timeout:12000}
  );
}

function search(){
  var q=$("q").value.trim();if(!q)return;
  enterManualMode("正在使用原始地址搜索；选择候选后在地图上点击放置图钉。");
  fetch("https://nominatim.openstreetmap.org/search?format=json&addressdetails=0&limit=8&q="+encodeURIComponent(q))
    .then(function(r){return r.json();})
    .then(function(a){
      var box=$("results");box.innerHTML="";
      if(!a||!a.length){box.classList.remove("show");toast("没找到");return;}
      a.forEach(function(it){
        var row=document.createElement("div");row.className="rrow";row.textContent=it.display_name;
        row.addEventListener("click",function(){
          box.classList.remove("show");box.innerHTML="";var la=+it.lat,lo=+it.lon;var p=datum==="gcj"?GCJ.wgs2gcj(la,lo):[la,lo];
          map.setView(p,15);toast("已定位视野，在地图上点一下放置图钉");
        });
        box.appendChild(row);
      });
      box.classList.add("show");
    })
    .catch(function(){
      enterManualMode("地址搜索服务暂时不可用；仍可直接点击地图、拖动图钉或填写经纬度定位。");
      toast("地址搜索失败，地图点选/拖图钉/经纬度仍可使用");
    });
}

function load(){
  fetch("/loc.json?token="+encodeURIComponent(token)).then(function(r){return r.json();}).then(function(d){
    WGS={lat:Number(d.latitude),lng:Number(d.longitude)};saved=true;enabledState=d.enabled!==false;syncCoordInputs();
    $("address").value=d.address||"";
    $("alt").value=d.altitude!==undefined?d.altitude:"";
    $("hacc").value=d.horizontalAccuracy!==undefined?d.horizontalAccuracy:39;
    $("vacc").value=d.verticalAccuracy!==undefined?d.verticalAccuracy:1000;
    $("failopen").checked=d.failOpen!==false;
    $("debug").checked=d.debug===true;

    var amapVec=L.tileLayer("https://wprd0{s}.is.autonavi.com/appmaptile?x={x}&y={y}&z={z}&lang=zh_cn&size=1&scl=1&style=7",{subdomains:"1234",maxZoom:18,attribution:"高德地图"});
    amapVec.datum="gcj";
    var amapSat=L.layerGroup([
      L.tileLayer("https://webst0{s}.is.autonavi.com/appmaptile?style=6&x={x}&y={y}&z={z}",{subdomains:"1234",maxZoom:18}),
      L.tileLayer("https://wprd0{s}.is.autonavi.com/appmaptile?x={x}&y={y}&z={z}&lang=zh_cn&size=1&scl=1&style=8",{subdomains:"1234",maxZoom:18})
    ]);amapSat.datum="gcj";
    var osm=L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",{maxZoom:19,attribution:"© OpenStreetMap"});osm.datum="wgs";

    map=L.map("map");amapVec.addTo(map);datum="gcj";map.setView(dispPos(),13);
    L.control.layers({"高德地图":amapVec,"高德卫星":amapSat,"国外 OSM":osm},null,{collapsed:false}).addTo(map);
    marker=L.marker(dispPos(),{draggable:true}).addTo(map);
    updateEnabledUI();setLocateBusy(false);setIpBusy(false);
    enterManualMode("手动地图定位始终可用；IP2Location 仅用于自动填充快捷定位。");

    map.on("baselayerchange",function(e){datum=e.layer.datum||"wgs";var p=dispPos();marker.setLatLng(p);map.setView(p,map.getZoom());info();});
    map.on("click",function(e){movePin(e.latlng.lat,e.latlng.lng);});
    marker.on("dragend",function(){var p=marker.getLatLng();movePin(p.lat,p.lng);});
  }).catch(function(){$("info").textContent="加载失败，检查 token 是否正确";});
}

$("btn").addEventListener("click",search);
$("q").addEventListener("keydown",function(e){if(e.key==="Enter")search();});
$("ippreviewbtn").addEventListener("click",function(){requestIpLookup(false);});
$("ipapplybtn").addEventListener("click",function(){requestIpLookup(true);});
$("ipq").addEventListener("keydown",function(e){if(e.key==="Enter")requestIpLookup(false);});
$("manualmodebtn").addEventListener("click",function(){enterManualMode();});
$("coordbtn").addEventListener("click",applyManualCoords);
$("latmanual").addEventListener("keydown",function(e){if(e.key==="Enter")applyManualCoords();});
$("lngmanual").addEventListener("keydown",function(e){if(e.key==="Enter")applyManualCoords();});
$("locatebtn").addEventListener("click",locateCurrent);
$("savebtn").addEventListener("click",function(){commit().catch(function(){});});
$("restorebtn").addEventListener("click",toggleEnabled);
$("favadd").addEventListener("click",addFavorite);
$("favlistbtn").addEventListener("click",toggleFavs);
load();
</script>
</body>
</html>`;


if (require.main === module) start();
module.exports = { handler, start, readLoc, writeLoc, normalizeLoc, isSpecialIp, ipCircuitState };
